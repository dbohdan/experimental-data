#!/usr/bin/env python3

import sys
from collections import defaultdict

# Piece definitions: (row, col) offsets for each state (0-3)
PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)]
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)]
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)]
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)]
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)]
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)]
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)]
    ]
}

# Board dimensions
BOARD_WIDTH = 10
BOARD_HEIGHT = 20

# Score table for clearing lines
SCORE_TABLE = {
    1: 100,
    2: 300,
    3: 500,
    4: 800
}

class Tetris:
    def __init__(self):
        self.board = [['.' for _ in range(BOARD_WIDTH)] for _ in range(BOARD_HEIGHT)]
        self.current_piece = None
        self.current_piece_type = None
        self.current_piece_state = 0
        self.current_piece_row = 0
        self.current_piece_col = 3
        self.piece_sequence = []
        self.score = 0
        self.lines_cleared = 0
        self.game_over = False
        self.game_done = False

    def spawn_piece(self):
        if not self.piece_sequence:
            self.game_done = True
            return False

        self.current_piece_type = self.piece_sequence.pop(0)
        self.current_piece_state = 0
        self.current_piece_row = 0
        self.current_piece_col = 3

        if not self._fits():
            self.game_over = True
            return False

        self.current_piece = self._get_piece_blocks()
        return True

    def _get_piece_blocks(self):
        offsets = PIECES[self.current_piece_type][self.current_piece_state]
        return [(self.current_piece_row + r, self.current_piece_col + c) for r, c in offsets]

    def _fits(self, row=None, col=None, state=None):
        if row is None:
            row = self.current_piece_row
        if col is None:
            col = self.current_piece_col
        if state is None:
            state = self.current_piece_state

        offsets = PIECES[self.current_piece_type][state]
        for r, c in offsets:
            board_row, board_col = row + r, col + c
            if (board_row < 0 or board_row >= BOARD_HEIGHT or 
                board_col < 0 or board_col >= BOARD_WIDTH or
                (board_row >= 0 and board_col >= 0 and self.board[board_row][board_col] != '.')):
                return False
        return True

    def move_left(self):
        if not self.current_piece:
            return
        if self._fits(col=self.current_piece_col - 1):
            self.current_piece_col -= 1
            self.current_piece = self._get_piece_blocks()

    def move_right(self):
        if not self.current_piece:
            return
        if self._fits(col=self.current_piece_col + 1):
            self.current_piece_col += 1
            self.current_piece = self._get_piece_blocks()

    def move_down(self):
        if not self.current_piece:
            return
        if self._fits(row=self.current_piece_row + 1):
            self.current_piece_row += 1
            self.current_piece = self._get_piece_blocks()
            self.score += 1
        else:
            self.lock_piece()

    def hard_drop(self):
        if not self.current_piece:
            return
        max_drop = 0
        while self._fits(row=self.current_piece_row + max_drop + 1):
            max_drop += 1

        self.current_piece_row += max_drop
        self.score += 2 * max_drop
        self.lock_piece()

    def rotate_clockwise(self):
        if not self.current_piece:
            return

        new_state = (self.current_piece_state + 1) % 4
        if self._fits(state=new_state):
            self.current_piece_state = new_state
            self.current_piece = self._get_piece_blocks()
            return

        # Try shifting left/right if rotation doesn't fit
        for col_offset in [-1, 1, -2, 2]:
            if self._fits(col=self.current_piece_col + col_offset, state=new_state):
                self.current_piece_col += col_offset
                self.current_piece_state = new_state
                self.current_piece = self._get_piece_blocks()
                return

    def rotate_counter_clockwise(self):
        if not self.current_piece:
            return

        new_state = (self.current_piece_state + 3) % 4
        if self._fits(state=new_state):
            self.current_piece_state = new_state
            self.current_piece = self._get_piece_blocks()
            return

        # Try shifting left/right if rotation doesn't fit
        for col_offset in [-1, 1, -2, 2]:
            if self._fits(col=self.current_piece_col + col_offset, state=new_state):
                self.current_piece_col += col_offset
                self.current_piece_state = new_state
                self.current_piece = self._get_piece_blocks()
                return

    def lock_piece(self):
        if not self.current_piece:
            return

        for r, c in self.current_piece:
            self.board[r][c] = self.current_piece_type

        self.clear_lines()
        self.current_piece = None
        self.spawn_piece()

    def clear_lines(self):
        lines_to_clear = []
        for row in range(BOARD_HEIGHT):
            if all(cell != '.' for cell in self.board[row]):
                lines_to_clear.append(row)

        if not lines_to_clear:
            return

        # Remove cleared lines
        for row in sorted(lines_to_clear, reverse=True):
            del self.board[row]
            self.board.insert(0, ['.' for _ in range(BOARD_WIDTH)])

        # Update score and lines cleared
        num_lines = len(lines_to_clear)
        self.score += SCORE_TABLE[num_lines]
        self.lines_cleared += num_lines

    def print_board(self):
        board_to_print = [row.copy() for row in self.board]
        if self.current_piece:
            for r, c in self.current_piece:
                board_to_print[r][c] = self.current_piece_type.lower()

        for row in board_to_print:
            print(''.join(row))

        state = 'PLAYING' if not self.game_over and not self.game_done else 'OVER' if self.game_over else 'DONE'
        print(f"SCORE {self.score} LINES {self.lines_cleared} {state}")

    def process_command(self, command):
        if self.game_over or (self.game_done and not command == 'P'):
            return

        if command == 'L':
            self.move_left()
        elif command == 'R':
            self.move_right()
        elif command == 'D':
            self.move_down()
        elif command == 'H':
            self.hard_drop()
        elif command == 'CW':
            self.rotate_clockwise()
        elif command == 'CCW':
            self.rotate_counter_clockwise()
        elif command == 'P':
            self.print_board()
        else:
            print(f"error: unknown command {command}", file=sys.stderr)


def main():
    if len(sys.argv) != 1:
        print("Usage: python3 tetris.py < game.txt", file=sys.stderr)
        sys.exit(1)

    tetris = Tetris()
    
    # Read piece sequence
    piece_sequence = sys.stdin.readline().strip()
    tetris.piece_sequence = list(piece_sequence)

    # Spawn the first piece
    tetris.spawn_piece()

    # Process commands
    for line in sys.stdin:
        commands = line.strip().split()
        for cmd in commands:
            tetris.process_command(cmd)

    # Print final board state
    tetris.print_board()


if __name__ == "__main__":
    main()