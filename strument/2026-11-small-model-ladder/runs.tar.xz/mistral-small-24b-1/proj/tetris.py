# tetris.py

import sys

# Constants
COLS = 10
ROWS = 20
PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)]
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)]
    ] * 4,
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)]
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)]
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)]
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)]
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)]
    ]
}

# Game state
board = [["." for _ in range(COLS)] for _ in range(ROWS)]
score = 0
lines_cleared = 0
current_piece = None
current_state = 0
current_row = 0
current_col = 3
piece_sequence = []
game_state = "PLAYING"

# Read input
input_lines = sys.stdin.readlines()
piece_sequence = list(input_lines[0].strip())
commands = []
for line in input_lines[1:]
    commands.extend(line.strip().split())

# Helper functions
def print_board():
    for row in range(ROWS):
        print("'.join(board[row])")
    print(f"SCORE {score} LINES {lines_cleared} {game_state}")

def clear_lines():
    global score, lines_cleared, board
    lines_to_clear = [row for row in range(ROWS) if all(cell != "." for cell in board[row])]
    for row in lines_to_clear:
        board.pop(row)
        board.insert(0, ["." for _ in range(COLS)])
    lines_cleared += len(lines_to_clear)
    if lines_cleared == 1:
        score += 100
    elif lines_cleared == 2:
        score += 300
    elif lines_cleared == 3:
        score += 500
    elif lines_cleared >= 4:
        score += 800

def place_piece():
    global board, current_piece, current_state, current_row, current_col, game_state, score
    if not current_piece:
        return
    for offset in PIECES[current_piece][current_state]:
        r, c = current_row + offset[0], current_col + offset[1]
        if 0 <= r < ROWS and 0 <= c < COLS:
            board[r][c] = current_piece.lower()
    clear_lines()
    current_piece = None

def try_place_piece():
    global current_piece, current_state, current_row, current_col
    if not current_piece:
        return False
    for offset in PIECES[current_piece][current_state]:
        r, c = current_row + offset[0], current_col + offset[1]
        if not (0 <= r < ROWS and 0 <= c < COLS) or board[r][c] != ".":
            return False
    return True
def move_piece(dr, dc):
    global current_row, current_col
    current_row += dr
    current_col += dc
    if not try_place_piece():
        current_row -= dr
        current_col -= dc

def rotate_piece(clockwise=True):
    global current_state
    original_state = current_state
    for shift in [0, -1, 1, -2, 2]:
        new_state = (current_state + shift) % 4
        current_state = new_state
        if try_place_piece():
            return
        current_state = original_state

# Main game loop
for command in commands:
    if game_state != "PLAYING":
        continue
    if not current_piece:
        if not piece_sequence:
            game_state = "DONE"
            break
        current_piece = piece_sequence.pop(0)
        current_state = 0
        current_row = 0
        current_col = 3
        if not try_place_piece():
            game_state = "OVER"
            break
    if command == "L":
        move_piece(0, -1)
    elif command == "R":
        move_piece(0, 1)
    elif command == "D":
        move_piece(1, 0)
        score += 1
    elif command == "H":
        while try_place_piece():
            move_piece(1, 0)
        score += 2
        place_piece()
    elif command == "CW":
        rotate_piece(clockwise=True)
    elif command == "CCW":
        rotate_piece(clockwise=False)
    elif command == "P":
        print_board()
    else:
        print(f"error: unknown command {command}", file=sys.stderr)

# Final print
print_board()