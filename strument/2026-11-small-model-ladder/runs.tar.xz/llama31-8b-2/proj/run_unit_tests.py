from glob import glob
from ls import ls
from read import read
from read_text import read_text
from grep import grep

def run_unit_tests():
    test_files = glob('samples/unit_tests/*.py') + glob('samples/unit_tests/*/*.py')
    test_output = {file: run_test_file(file) for file in test_files} if test_files else {}
    return test_output

def run_test_file(file):
    command = f'pytest {file} -sv --junit-xml=result.xml --capture=no'
    output = read(f'./{file}', 100) if '.' in file else read_text(f'./{file}', 0)
    return output

# Run unit tests
unit_test_results = run_unit_tests()
# Print results
for file, output in unit_test_results.items():
    print(f'Testing file {file} produced the following output:')
    print(output)