import pygame

class Piece:
    def __init__(self, shape, color):
        self.shape = shape
        self.color = color

class Tetris:
    def __init__(self, width=10, height=20):
        self.width = width
        self.height = height
        self.board = [[0 for _ in range(width)] for _ in range(height)]

    def is_valid_move(self, x, y):
        return 0 <= x < self.width and 0 <= y < self.height

    def can_drop_piece(self, piece):
        for x, y in piece:
            if not self.is_valid_move(x, y):
                return False
        return True

    def drop_piece(self, piece):
        for x, y in piece:
            self.board[y][x] = 1

    def draw_board(self):
        pygame.init()
        screen = pygame.display.set_mode((self.width*20, self.height*20))
        clock = pygame.time.Clock()
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
            screen.fill((0,0,0))
            for y in range(self.height):
                for x in range(self.width):
                    if self.board[y][x] == 1:
                        pygame.draw.rect(screen, (255,0,0), (x*20, y*20, 20, 20))
            pygame.display.flip()
            clock.tick(60)

# Initialize the game
board = Tetris(width=10, height=20)
#board.drop_piece([(0, 0), (1, 0), (2, 0), (3, 0)])
#board.draw_board()