#!/usr/bin/env python3
"""Headless Tetris - plays from input commands."""

# Piece definitions: (state 0, state 1, state 2, state 3)
# Each state is a list of (row, col) offsets in the 4x4 box
PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)],
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)],
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)],
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)],
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)],
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)],
    ],
}

# Scoring for clearing rows
CLEAR_SCORES = {1: 100, 2: 300, 3: 500, 4: 800}

# Board dimensions
BOARD_WIDTH = 10
BOARD_HEIGHT = 20

# Spawn position (top row, column 3)
SPAWN_ROW = 0
SPAWN_COL = 3


def get_piece_blocks(piece_type, state):
    """Get the blocks of a piece at a given state."""
    return PIECES[piece_type][state]


def piece_fits(blocks, row, col, board):
    """Check if a piece fits at the given position on the board."""
    for dr, dc in blocks:
        r, c = row + dr, col + dc
        # Outside board counts as occupied
        if r < 0 or r >= BOARD_HEIGHT or c < 0 or c >= BOARD_WIDTH:
            return False
        # Check if cell is already occupied
        if board[r][c] != '.':
            return False
    return True


def clear_rows(board):
    """Clear full rows and return the number of rows cleared."""
    rows_to_clear = []
    for r in range(BOARD_HEIGHT):
        if all(board[r][c] != '.' for c in range(BOARD_WIDTH)):
            rows_to_clear.append(r)
    
    if not rows_to_clear:
        return 0
    
    # Remove cleared rows and shift down
    rows_above = sum(1 for r in range(BOARD_HEIGHT) if r not in rows_to_clear)
    new_board = []
    for r in range(BOARD_HEIGHT):
        if r not in rows_to_clear:
            new_board.append(board[r][:])
    
    # Fill top with empty rows
    for _ in range(rows_above):
        new_board.insert(0, ['.'] * BOARD_WIDTH)
    
    return len(rows_to_clear)


def try_rotate(piece_type, row, col, board):
    """Try to rotate the piece clockwise, returning the new state or None."""
    new_state = (piece_state + 1) % 4
    
    # Try rotation at current position
    if piece_fits(get_piece_blocks(piece_type, new_state), row, col, board):
        return new_state
    
    # Try rotation with column shifts: -1, +1, -2, +2
    for shift in [-1, 1, -2, 2]:
        if piece_fits(get_piece_blocks(piece_type, new_state), row, col + shift, board):
            return new_state
    
    return None


def try_rotate_ccw(piece_type, row, col, board):
    """Try to rotate the piece counterclockwise, returning the new state or None."""
    new_state = (piece_state + 3) % 4
    
    # Try rotation at current position
    if piece_fits(get_piece_blocks(piece_type, new_state), row, col, board):
        return new_state
    
    # Try rotation with column shifts: -1, +1, -2, +2
    for shift in [-1, 1, -2, 2]:
        if piece_fits(get_piece_blocks(piece_type, new_state), row, col + shift, board):
            return new_state
    
    return None


def move_left(piece_type, row, col, board):
    """Move piece one column left if it fits."""
    blocks = get_piece_blocks(piece_type, 0)
    if piece_fits(blocks, row, col - 1, board):
        return True
    return False


def move_right(piece_type, row, col, board):
    """Move piece one column right if it fits."""
    blocks = get_piece_blocks(piece_type, 0)
    if piece_fits(blocks, row, col + 1, board):
        return True
    return False


def move_down(piece_type, row, col, board):
    """Move piece one row down if it fits."""
    blocks = get_piece_blocks(piece_type, 0)
    if piece_fits(blocks, row + 1, col, board):
        return True
    return False


def hard_drop(piece_type, row, col, board):
    """Hard drop the piece, moving it down as much as possible."""
    blocks = get_piece_blocks(piece_type, 0)
    rows_moved = 0
    while piece_fits(blocks, row + 1, col, board):
        rows_moved += 1
        row += 1
    return rows_moved


def print_board(board):
    """Print the board to stdout."""
    for row in board:
        print(''.join(row))


def main():
    # Read input from stdin
    import sys
    lines = sys.stdin.read().splitlines()
    
    # First line is the piece sequence
    piece_sequence = lines[0]
    
    # Rest are commands
    commands = lines[1:]
    # Split by whitespace and filter out empty strings
    commands = [c for c in ' '.join(commands).split() if c]
    
    # Initialize board
    board = [['.' for _ in range(BOARD_WIDTH)] for _ in range(BOARD_HEIGHT)]
    
    # Track state
    current_piece = None  # (piece_type, state, row, col) or None
    current_state = 0
    current_row = SPAWN_ROW
    current_col = SPAWN_COL
    score = 0
    lines_cleared = 0
    piece_index = 0
    game_over = False
    game_done = False
    
    # Spawn the first piece before processing commands
    if piece_sequence:
        piece_type = piece_sequence[0]
        if not piece_fits(get_piece_blocks(piece_type, 0), current_row, current_col, board):
            # Game over - piece doesn't fit at spawn position
            game_over = True
            current_piece = None
        else:
            current_piece = (piece_type, 0, current_row, current_col)
    else:
        game_done = True
    
    # Process commands
    for cmd in commands:
        if game_done or (not game_over and not current_piece):
            # No piece in play, ignore commands except P
            if cmd == 'P':
                print_board(board)
                print(f"SCORE {score} LINES {lines_cleared} {state_str}")
            continue
        
        if cmd == 'L':
            if move_left(current_piece[0], current_piece[2], current_piece[3], board):
                current_piece = (current_piece[0], current_piece[1], current_piece[2], current_piece[3] - 1)
        elif cmd == 'R':
            if move_right(current_piece[0], current_piece[2], current_piece[3], board):
                current_piece = (current_piece[0], current_piece[1], current_piece[2], current_piece[3] + 1)
        elif cmd == 'D':
            if move_down(current_piece[0], current_piece[2], current_piece[3], board):
                current_piece = (current_piece[0], current_piece[1], current_piece[2] + 1, current_piece[3])
                score += 1
            else:
                # Lock the piece
                lock_piece(board, current_piece)
        elif cmd == 'H':
            rows_moved = hard_drop(current_piece[0], current_piece[2], current_piece[3], board)
            current_row += rows_moved
            score += 2 * rows_moved
            lock_piece(board, current_piece)
        elif cmd == 'CW':
            new_state = try_rotate(current_piece[0], current_piece[2], current_piece[3], board)
            if new_state is not None:
                current_piece = (current_piece[0], new_state, current_piece[2], current_piece[3])
        elif cmd == 'CCW':
            new_state = try_rotate_ccw(current_piece[0], current_piece[2], current_piece[3], board)
            if new_state is not None:
                current_piece = (current_piece[0], new_state, current_piece[2], current_piece[3])
        elif cmd == 'P':
            print_board(board)
            print(f"SCORE {score} LINES {lines_cleared} {state_str}")
        else:
            print(f"error: unknown command {cmd}", file=__import__('sys').stderr)
    
    # Print final state
    if game_over:
        state_str = "OVER"
    elif game_done:
        state_str = "DONE"
    else:
        state_str = "PLAYING"
    
    print_board(board)
    print(f"SCORE {score} LINES {lines_cleared} {state_str}")


def lock_piece(board, current_piece):
    """Lock the current piece onto the board and handle clearing."""
    global score, lines_cleared, piece_index, game_done, game_over, piece_sequence, current_row, current_col
    piece_type, piece_state, row, col = current_piece
    blocks = get_piece_blocks(piece_type, piece_state)
    for dr, dc in blocks:
        board[row + dr][col + dc] = piece_type
    
    # Clear full rows
    rows_cleared = clear_rows(board)
    score += CLEAR_SCORES.get(rows_cleared, 0)
    lines_cleared += rows_cleared
    
    # Spawn next piece if available
    if piece_index < len(piece_sequence):
        piece_type = piece_sequence[piece_index]
        if not piece_fits(get_piece_blocks(piece_type, 0), current_row, current_col, board):
            game_over = True
            current_piece = None
        else:
            current_piece = (piece_type, 0, current_row, current_col)
        piece_index += 1
    else:
        game_done = True


if __name__ == '__main__':
    main()
