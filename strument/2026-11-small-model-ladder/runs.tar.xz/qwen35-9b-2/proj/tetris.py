#!/usr/bin/env python3
"""Headless Tetris - plays a game from stdin and prints output to stdout."""

import sys

# Piece definitions as (r,c) offsets for each box state
PIECES = {
    'I': [
        [(1,0),(1,1),(1,2),(1,3)],  # state 0
        [(0,2),(1,2),(2,2),(3,2)],  # state 1
        [(2,0),(2,1),(2,2),(2,3)],  # state 2
        [(0,1),(1,1),(2,1),(3,1)],  # state 3
    ],
    'O': [
        [(0,1),(0,2),(1,1),(1,2)],  # all states same
        [(0,1),(0,2),(1,1),(1,2)],
        [(0,1),(0,2),(1,1),(1,2)],
        [(0,1),(0,2),(1,1),(1,2)],
    ],
    'T': [
        [(0,1),(1,0),(1,1),(1,2)],  # state 0
        [(0,1),(1,1),(1,2),(2,1)],  # state 1
        [(1,0),(1,1),(1,2),(2,1)],  # state 2
        [(0,1),(1,0),(1,1),(2,1)],  # state 3
    ],
    'S': [
        [(0,1),(0,2),(1,0),(1,1)],  # state 0
        [(0,1),(1,1),(1,2),(2,2)],  # state 1
        [(1,1),(1,2),(2,0),(2,1)],  # state 2
        [(0,0),(1,0),(1,1),(2,1)],  # state 3
    ],
    'Z': [
        [(0,0),(0,1),(1,1),(1,2)],  # state 0
        [(0,2),(1,1),(1,2),(2,1)],  # state 1
        [(1,0),(1,1),(2,1),(2,2)],  # state 2
        [(0,1),(1,0),(1,1),(2,0)],  # state 3
    ],
    'J': [
        [(0,0),(1,0),(1,1),(1,2)],  # state 0
        [(0,1),(0,2),(1,1),(2,1)],  # state 1
        [(1,0),(1,1),(1,2),(2,2)],  # state 2
        [(0,1),(1,1),(2,0),(2,1)],  # state 3
    ],
    'L': [
        [(0,2),(1,0),(1,1),(1,2)],  # state 0
        [(0,1),(1,1),(2,1),(2,2)],  # state 1
        [(1,0),(1,1),(1,2),(2,0)],  # state 2
        [(0,0),(0,1),(1,1),(2,1)],  # state 3
    ],
}


class Game:
    ROWS, COLS = 20, 10
    
    def __init__(self):
        self.board = [['.'] * self.COLS for _ in range(self.ROWS)]
        self.piece = None
        self.next_pieces = ''
        self.next_idx = 0
        self.score = 0
        self.lines = 0
        self.state = 'PLAYING'
    
    def get_blocks_for_piece(self, ptype, row, col, state):
        result = []
        if ptype == 'O':
            brlist = PIECES[ptype][state]
        else:
            brlist = PIECES[ptype][(state + 1) % 4]
        for br, bc in brlist:
            result.append((row + br, col + bc))
        return result
    
    def fit_check(self, ptype, row, col, state):
        blocks = self.get_blocks_for_piece(ptype, row, col, state)
        for r, c in blocks:
            if not (0 <= r < self.ROWS and 0 <= c < self.COLS):
                return False
            if self.board[r][c] != '.':
                return False
        return True
    
    def spawn_next_piece(self):
        if self.state != 'PLAYING':
            return False
        
        ptype = self.next_pieces[self.next_idx]
        self.next_idx += 1
        
        if self.next_idx >= len(self.next_pieces):
            self.state = 'DONE'
            return True
        
        self.piece = {'type': ptype, 'state': 0, 'row': 0, 'col': 3}
        
        if not self.fit_check(ptype, 0, 3, 0):
            self.state = 'OVER'
            self.piece = None
            return False
        
        return True
    
    def left_fits(self):
        if self.state != 'PLAYING' or self.piece is None:
            return False
        test_col = self.piece['col'] - 1
        return self.fit_check(self.piece['type'], self.piece['row'], test_col, self.piece['state'])
    
    def right_fits(self):
        if self.state != 'PLAYING' or self.piece is None:
            return False
        test_col = self.piece['col'] + 1
        return self.fit_check(self.piece['type'], self.piece['row'], test_col, self.piece['state'])
    
    def down_fits(self):
        if self.state != 'PLAYING' or self.piece is None:
            return False
        test_row = self.piece['row'] + 1
        return self.fit_check(self.piece['type'], test_row, self.piece['col'], self.piece['state'])
    
    def rotate_cw(self):
        if self.state != 'PLAYING' or self.piece is None:
            return False
        new_state = (self.piece['state'] + 1) % 4
        base_row, base_col = self.piece['row'], self.piece['col']
        target_type = self.piece['type']
        
        deltas = [-1, +1, -2, +2]
        for dc in deltas:
            if self.fit_check(target_type, base_row, base_col + dc, new_state):
                self.piece['state'] = new_state
                self.piece['col'] = base_col + dc
                return True
        return False
    
    def rotate_ccw(self):
        if self.state != 'PLAYING' or self.piece is None:
            return False
        new_state = (self.piece['state'] + 3) % 4
        base_row, base_col = self.piece['row'], self.piece['col']
        target_type = self.piece['type']
        
        deltas = [-1, +1, -2, +2]
        for dc in deltas:
            if self.fit_check(target_type, base_row, base_col + dc, new_state):
                self.piece['state'] = new_state
                self.piece['col'] = base_col + dc
                return True
        return False
    
    def lock_current_piece(self):
        assert self.state == 'PLAYING'
        assert self.piece is not None
        
        pt = self.piece['type']
        st = self.piece['state']
        bb = self.get_blocks_for_piece(pt, self.piece['row'], self.piece['col'], st)
        
        for r, c in bb:
            if self.board[r][c] == '.':
                self.board[r][c] = pt
        
        self._clear_full_lines()
        self.piece = None
        self.state = 'OVER'
    
    def _clear_full_lines(self):
        filled_rows = [i for i in range(self.ROWS) if '.' not in self.board[i]]
        n_cleared = len(filled_rows)
        
        if n_cleared == 1:
            self.score += 100
        elif n_cleared == 2:
            self.score += 300
        elif n_cleared == 3:
            self.score += 500
        else:
            self.score += 800
        
        self.lines += n_cleared
        
        non_filled = [[c for c in self.board[i]] for i in range(self.ROWS) if i not in filled_rows]
        
        if len(non_filled) < self.ROWS:
            while len(non_filled) < self.ROWS:
                non_filled.insert(0, ['.'] * self.COLS)
        
        self.board = non_filled
    
    def move_down_one(self):
        if self.state != 'PLAYING' or self.piece is None:
            return False
        if self.down_fits():
            self.piece['row'] += 1
            return True
        self.lock_current_piece()
        return True
    
    def hard_drop(self):
        if self.state != 'PLAYING' or self.piece is None:
            return False
        
        drops = 0
        while True:
            self.piece['row'] += 1
            test_row = self.piece['row']
            if not self.fit_check(self.piece['type'], test_row, self.piece['col'], self.piece['state']):
                self.piece['row'] -= 1
                break
            drops += 1
        
        self.score += 2 * drops
        self.lock_current_piece()
    
    def apply_command(self, cmd):
        if cmd == 'L':
            if self.left_fits():
                self.piece['col'] -= 1
        elif cmd == 'R':
            if self.right_fits():
                self.piece['col'] += 1
        elif cmd == 'D':
            self.move_down_one()
        elif cmd == 'H':
            self.hard_drop()
        elif cmd == 'CW':
            self.rotate_cw()
        elif cmd == 'CCW':
            self.rotate_ccw()
        elif cmd == 'P':
            pass
        else:
            print(f"error: unknown command {cmd}", file=sys.stderr)
    
    def format_board(self):
        lines = []
        for r in range(self.ROWS):
            lines.append(''.join(self.board[r]))
        return lines
    
    def print_status_line(self):
        suffix = self.state
        print(f'SCORE {self.score} LINES {self.lines} {suffix}')
    
    def run(self, piece_seq, cmds_str):
        tokens = cmds_str.split()
        processed_anything = False
        
        # Spawn first piece
        self.spawn_next_piece()
        
        if self.state == 'OVER':
            self.print_final('OVER')
            return
        
        # Process each command
        for token in tokens:
            processed_anything = True
            if self.state == 'OVER':
                self.print_final('OVER')
                break
            elif self.state == 'DONE':
                self.print_final('DONE')
                break
            
            self.apply_command(token)
            
            # Check if we should spawn next piece
            if self.state == 'PLAYING':
                self.spawn_next_piece()
                if self.state == 'OVER':
                    self.print_final('OVER')
                    break
        
        # Print final state if no P was given
        if not processed_anything:
            self.print_final('DONE')
        elif self.state == 'PLAYING' and self.next_idx >= len(piece_seq):
            # Need one more print since we've used all pieces but no P
            self.print_final(self.state)
        elif self.state == 'OVER':
            self.print_final('OVER')
        elif self.state == 'DONE':
            self.print_final('DONE')
    
    def print_final(self, final_suffix=None):
        lines = self.format_board()
        for line in lines:
            print(line)
        if final_suffix is None:
            final_suffix = self.state
        print(f'SCORE {self.score} LINES {self.lines} {final_suffix}')


def main():
    data = sys.stdin.read().strip()
    lines = data.split('\n')
    
    piece_seq = lines[0].strip() if len(lines) > 0 else ''
    cmds_str = '\n'.join(lines[1:]) if len(lines) > 1 else ''
    
    game = Game()
    game.next_pieces = piece_seq
    game.run(piece_seq, cmds_str)


if __name__ == '__main__':
    main()
