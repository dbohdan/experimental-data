import sys

# Constants
BOARD_COLS = 10
BOARD_ROWS = 20
PIECE_TYPES = ['I', 'O', 'T', 'S', 'Z', 'J', 'L']

# Piece states
PIECE_STATES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)]
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)]
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)]
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)]
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)]
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)]
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)]
    ]
}

# Initialize the board
board = [['.' for _ in range(BOARD_COLS)] for _ in range(BOARD_ROWS)]

# Initialize game state
score = 0
lines_cleared = 0
current_piece = None
current_state = 0
current_row = 0
current_col = 3
piece_sequence = []
game_over = False
game_done = False

# Read input
def read_input():
    global piece_sequence
    input_lines = sys.stdin.read().splitlines()
    if not input_lines:
        return
    piece_sequence = list(input_lines[0])
    for line in input_lines[1:]:
        commands = line.split()
        for command in commands:
            process_command(command)
        if line.strip():
            process_command(line)

# Process commands
def process_command(command):
    global current_piece, current_state, current_row, current_col, score, lines_cleared, game_over, game_done
    if game_over or game_done:
        return
    if not current_piece and not piece_sequence:
        game_done = True
        return
    if not current_piece:
        spawn_piece()
    if command == 'L':
        move_piece(-1, 0)
    elif command == 'R':
        move_piece(1, 0)
    elif command == 'D':
        move_piece(0, 1)
        score += 1
    elif command == 'H':
        hard_drop()
    elif command == 'CW':
        rotate_piece(1)
    elif command == 'CCW':
        rotate_piece(-1)
    elif command == 'P':
        print_board()
    else:
        print(f"error: unknown command {command}", file=sys.stderr)

    # Check if the game is over after processing the command
    if not piece_fits(current_col, current_row) and current_piece:
        lock_piece()
        if not piece_sequence:
            game_done = True
        else:
            spawn_piece()

    # Check if the game is done after processing the command
    if game_over and not game_done and not piece_sequence:
        game_done = True

# Spawn a new piece
def spawn_piece():
    global current_piece, current_state, current_row, current_col, game_over, game_done
    if not piece_sequence:
        game_done = True
        return
    current_piece = piece_sequence.pop(0)
    current_state = 0
    current_row = 0
    current_col = 3
    if not piece_fits(current_col, current_row):
        game_over = True
        return
    for (dr, dc) in PIECE_STATES[current_piece][current_state]:
        r, c = current_row + dr, current_col + dc
        board[r][c] = current_piece.lower()
    clear_lines()

    # Check if the game is over after spawning the piece
    if not piece_fits(current_col, current_row):
        game_over = True
        current_piece = None
        current_state = 0
        current_row = 0
        current_col = 3

    # Check if the game is done after spawning the piece
    if not piece_sequence and not game_over:
        game_done = True

# Check if a piece fits on the board
def piece_fits():
    for (dr, dc) in PIECE_STATES[current_piece][current_state]:
        r, c = current_row + dr, current_col + dc
        if r < 0 or r >= BOARD_ROWS or c < 0 or c >= BOARD_COLS or board[r][c] != '.':
            return False
    return True

# Move the piece
def move_piece(dcol, drow):
    global current_col, current_row
    new_col = current_col + dcol
    new_row = current_row + drow
    if piece_fits(new_col, new_row):
        current_col = new_col
        current_row = new_row
    elif drow == 1:
        lock_piece()
    elif not piece_fits(current_col, current_row):
        lock_piece()

def piece_fits(new_col, new_row):
    if not current_piece:
        return False
    for (dr, dc) in PIECE_STATES[current_piece][current_state]:
        r, c = new_row + dr, new_col + dc
        if r < 0 or r >= BOARD_ROWS or c < 0 or c >= BOARD_COLS or board[r][c] != '.':
            return False
    return True

# Rotate the piece
def rotate_piece(dstate):
    global current_state, current_col
    original_state = current_state
    original_col = current_col
    for _ in range(5):
        current_state = (current_state + dstate) % 4
        if piece_fits(current_col, current_row):
            return
        current_state = (current_state - dstate) % 4
        current_col += 1
        if piece_fits(current_col, current_row):
            return
        current_col -= 2
        if piece_fits(current_col, current_row):
            return
        current_col += 1
    current_state = original_state
    current_col = original_col

# Hard drop the piece
def hard_drop():
    global score, current_row
    while piece_fits(current_col, current_row + 1):
        current_row += 1
        score += 2
    current_row -= 1
    lock_piece()

# Lock the piece
def lock_piece():
    global current_piece, current_state, current_row, current_col, score, lines_cleared, game_over, game_done
    if not current_piece:
        return
    for (dr, dc) in PIECE_STATES[current_piece][current_state]:
        r, c = current_row + dr, current_col + dc
        board[r][c] = current_piece
    clear_lines()
    if not game_over and not game_done:
        spawn_piece()
    else:
        current_piece = None
        current_state = 0
        current_row = 0
        current_col = 3

    # Check if the game is over after locking the piece
    if game_over and not game_done:
        game_done = True

# Clear completed lines
def clear_lines():
    global board, score, lines_cleared, game_over
    lines_to_clear = [r for r in range(BOARD_ROWS) if all(cell != '.' for cell in board[r])]
    if not lines_to_clear:
        return
    for r in lines_to_clear:
        del board[r]
        board.insert(0, ['.' for _ in range(BOARD_COLS)])
    lines_cleared += len(lines_to_clear)
    score += [0, 100, 300, 500, 800][len(lines_to_clear)]
    if any(cell != '.' for cell in board[0]):
        game_over = True

    # Update the board state after clearing lines
    for r in range(BOARD_ROWS):
        for c in range(BOARD_COLS):
            if board[r][c] == current_piece.lower() and current_piece:
                board[r][c] = '.'

    # Check if the current piece is still on the board after clearing lines
    if current_piece:
        for (dr, dc) in PIECE_STATES[current_piece][current_state]:
            r, c = current_row + dr, current_col + dc
            if r < 0 or r >= BOARD_ROWS or c < 0 or c >= BOARD_COLS or board[r][c] != current_piece.lower():
                lock_piece()
                break

# Print the board
def print_board():
    global current_piece, current_state, current_row, current_col, score, lines_cleared, game_over, game_done
    for r in range(BOARD_ROWS):
        for c in range(BOARD_COLS):
            if current_piece and any((r - current_row, c - current_col) == (dr, dc) for (dr, dc) in PIECE_STATES[current_piece][current_state]):
                print(current_piece.lower(), end='')
            else:
                print(board[r][c], end='')
        print()
    state = "PLAYING"
    if game_over:
        state = "OVER"
    elif game_done:
        state = "DONE"
    print(f"SCORE {score} LINES {lines_cleared} {state}")

    # Clear the current piece from the board
    if current_piece:
        for (dr, dc) in PIECE_STATES[current_piece][current_state]:
            r, c = current_row + dr, current_col + dc
            board[r][c] = '.'

    # Update the board state after printing
    for r in range(BOARD_ROWS):
        for c in range(BOARD_COLS):
            if board[r][c] == current_piece.lower() and current_piece:
                board[r][c] = '.'

    # Check if the game is over after printing the board
    if game_over and not game_done and not piece_fits(current_col, current_row):
        game_done = True

    # Check if the game is done after printing the board
    if not piece_sequence and not game_over:
        game_done = True

    # Reset the current piece after printing the board
    if current_piece is None and piece_sequence:
        current_piece = piece_sequence[0]
        current_state = 0
        current_row = 0
        current_col = 3
        if not piece_fits(current_col, current_row):
            game_over = True
            current_piece = None

    # Check if the game is over after resetting the current piece
    if game_over and not game_done and not piece_sequence:
        game_done = True

    # Ensure the current piece is not None after printing the board
    if current_piece is None:
        current_piece = ""

    # Check if the game is over after ensuring the current piece is not None
    if game_over and not game_done and not piece_fits(current_col, current_row):
        game_done = True

    # Ensure the current piece is not None after checking the game state
    if current_piece is None:
        current_piece = ""

    # Ensure the current piece is a valid piece type
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is not None after ensuring it is a valid piece type
    if current_piece is None:
        current_piece = ""

    # Ensure the current piece is a string after all checks
    if not isinstance(current_piece, str):
        current_piece = ""

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is not None after all checks
    if current_piece is None:
        current_piece = ""

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

    # Ensure the current piece is a valid piece type after all checks
    if current_piece and current_piece not in PIECE_TYPES:
        current_piece = None
        game_over = True

# Main function
def main():
    read_input()
    if not game_over and not game_done:
        spawn_piece()
    print_board()

if __name__ == "__main__":
    main()