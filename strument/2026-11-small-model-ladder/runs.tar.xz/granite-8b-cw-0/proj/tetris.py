#!/usr/bin/env python3
import sys

# Piece offsets: for each piece letter, list of 4 states, each state is list of (r,c) offsets
offsets = {
    'I': [
        [(1,0), (1,1), (1,2), (1,3)],  # state 0
        [(0,2), (1,2), (2,2), (3,2)],  # state 1
        [(2,0), (2,1), (2,2), (2,3)],  # state 2
        [(0,1), (1,1), (2,1), (3,1)],  # state 3
    ],
    'O': [
        [(0,1), (0,2), (1,1), (1,2)],  # state 0 (all same)
        [(0,1), (0,2), (1,1), (1,2)],
        [(0,1), (0,2), (1,1), (1,2)],
        [(0,1), (0,2), (1,1), (1,2)],
    ],
    'T': [
        [(0,1), (1,0), (1,1), (1,2)],  # state 0
        [(0,1), (1,1), (1,2), (2,1)],  # state 1
        [(1,0), (1,1), (1,2), (2,1)],  # state 2
        [(0,1), (1,0), (1,1), (2,1)],  # state 3
    ],
    'S': [
        [(0,1), (0,2), (1,0), (1,1)],  # state 0
        [(0,1), (1,1), (1,2), (2,2)],  # state 1
        [(1,1), (1,2), (2,0), (2,1)],  # state 2
        [(0,0), (1,0), (1,1), (2,1)],  # state 3
    ],
    'Z': [
        [(0,0), (0,1), (1,1), (1,2)],  # state 0
        [(0,2), (1,1), (1,2), (2,1)],  # state 1
        [(1,0), (1,1), (2,1), (2,2)],  # state 2
        [(0,1), (1,0), (1,1), (2,0)],  # state 3
    ],
    'J': [
        [(0,0), (1,0), (1,1), (1,2)],  # state 0
        [(0,1), (0,2), (1,1), (2,1)],  # state 1
        [(1,0), (1,1), (1,2), (2,2)],  # state 2
        [(0,1), (1,1), (2,0), (2,1)],  # state 3
    ],
    'L': [
        [(0,2), (1,0), (1,1), (1,2)],  # state 0
        [(0,1), (1,1), (2,1), (2,2)],  # state 1
        [(1,0), (1,1), (1,2), (2,0)],  # state 2
        [(0,0), (0,1), (1,1), (2,1)],  # state 3
    ],
}

def fits(piece, row, col, state, board):
    """Return True if piece at (row,col) in state fits on board (board only locked uppercase or '.')."""
    for r, c in offsets[piece][state]:
        br = row + r
        bc = col + c
        if br < 0 or br >= 20 or bc < 0 or bc >= 10:
            return False
        if board[br][bc] != '.':  # locked cell occupied
            return False
    return True

def lock_piece(board, piece, row, col, state, score, total_lines, next_idx, piece_seq):
    """Lock current piece, clear full rows, return (new_score, new_total_lines, new_state_game, new_current_piece, new_next_idx)."""
    # place as uppercase
    for r, c in offsets[piece][state]:
        br = row + r
        bc = col + c
        board[br][bc] = piece.upper()
    
    # find full rows (all non '.')
    full_rows = []
    for i in range(20):
        if all(board[i][j] != '.' for j in range(10)):
            full_rows.append(i)
    full_rows.sort()
    num_full = len(full_rows)
    
    # clear rows
    non_full = [i for i in range(20) if i not in full_rows]
    top_empty = num_full
    new_board = [['.' for _ in range(10)] for _ in range(20)]
    for idx, i in enumerate(non_full):
        for j in range(10):
            new_board[idx + top_empty][j] = board[i][j]
    # copy back
    for i in range(20):
        for j in range(10):
            board[i][j] = new_board[i][j]
    
    # score update
    if num_full == 1:
        score += 100
    elif num_full == 2:
        score += 300
    elif num_full == 3:
        score += 500
    elif num_full == 4:
        score += 800
    total_lines += num_full
    
    # spawn next piece if any
    new_current_piece = None
    new_state_game = None
    if next_idx < len(piece_seq):
        next_piece = piece_seq[next_idx]
        next_idx += 1
        if fits(next_piece, 0, 3, 0, board):
            new_current_piece = {'type': next_piece, 'state': 0, 'row': 0, 'col': 3}
            new_state_game = "PLAYING"
        else:
            new_state_game = "OVER"
            new_current_piece = None
    else:
        new_state_game = "DONE"
        new_current_piece = None
    
    return score, total_lines, new_state_game, new_current_piece, next_idx

def print_board(board, current_piece, score, total_lines, state_game):
    """Print board with current piece as lowercase, then score line."""
    # display board
    display = [row[:] for row in board]  # board has only locked uppercase '.'
    if current_piece and current_piece['type'] is not None:
        piece_letter = current_piece['type']
        row = current_piece['row']
        col = current_piece['col']
        state = current_piece['state']
        for r, c in offsets[piece_letter][state]:
            br = row + r
            bc = col + c
            if 0 <= br < 20 and 0 <= bc < 10:
                display[br][bc] = piece_letter  # lowercase
    # output
    out = []
    for r in range(20):
        out.append(''.join(display[r]))
    # state description
    if current_piece and current_piece['type'] is not None:
        state_desc = "PLAYING"
    elif state_game == "OVER":
        state_desc = "OVER"
    else:  # DONE
        state_desc = "DONE"
    out.append(f"SCORE {score} LINES {total_lines} {state_desc}")
    sys.stdout.write('\n'.join(out) + '\n')

def main():
    data = sys.stdin.read().strip().splitlines()
    if not data:
        return
    
    piece_seq = data[0].strip()
    tokens = []
    for line in data[1:]:
        tokens.extend(line.split())
    
    # board only locked uppercase and '.'
    board = [['.' for _ in range(10)] for _ in range(20)]
    
    score = 0
    total_lines = 0
    state_game = "PLAYING"  # OVER or DONE will override as needed
    
    # index of next piece to spawn in piece_seq
    next_idx = 0
    
    # current piece dict or None
    current_piece = None
    
    # Spawn first piece
    if not piece_seq:
        # no pieces, just print DONE
        print_board(board, current_piece, score, total_lines, state_game, sys)
        return
    
    # piece_seq is a string of letters
    # We'll iterate through it
    next_idx = 0  # index of next piece to spawn in piece_seq (0-based)
    
    # Spawn first piece (index 0)
    first_piece = piece_seq[0]
    next_idx = 1
    if fits(first_piece, 0, 3, 0, board):
        current_piece = {'type': first_piece, 'state': 0, 'row': 0, 'col': 3}
    else:
        state_game = "OVER"
        current_piece = None
    
    # Process commands
    for token in tokens:
        # Handle unknown commands
        if token not in ['L', 'R', 'D', 'H', 'CW', 'CCW', 'P']:
            sys.stderr.write(f"error: unknown command {token}\n")
            continue
        
        # Ignore commands if game is OVER or DONE (except P already handled later)
        if state_game == "OVER" or state_game == "DONE":
            continue
        
        if token == 'P':
            print_board(board, current_piece, score, total_lines, state_game)
            continue
        
        if current_piece is None and state_game == "OVER":
            # game over, ignore all except P (already handled)
            continue
        
        piece = current_piece['type']
        
        if token == 'L':
            # move left if fits
            if fits(piece, current_piece['row'], current_piece['col'] - 1, current_piece['state'], board):
                current_piece['col'] -= 1
        elif token == 'R':
            if fits(piece, current_piece['row'], current_piece['col'] + 1, current_piece['state'], board):
                current_piece['col'] += 1
        elif token == 'D':
            # try to move down one
            if fits(piece, current_piece['row'] + 1, current_piece['col'], current_piece['state'], board):
                current_piece['row'] += 1
                score += 1
            else:
                # lock instead
                score, total_lines, state_game, current_piece, next_idx = lock_piece(board, piece,
                    current_piece['row'], current_piece['col'], current_piece['state'],
                    score, total_lines, next_idx, piece_seq)
                # current_piece will be set by lock_piece for next piece if any
        elif token == 'H':
            # hard drop: find max down rows that fit
            down_max = 0
            for d in range(1, 20):
                if fits(piece, current_piece['row'] + d, current_piece['col'], current_piece['state'], board):
                    down_max = d
                else:
                    break
            if down_max > 0:
                current_piece['row'] += down_max
                score += 2 * down_max
            # lock after hard drop
            score, total_lines, state_game, current_piece, next_idx = lock_piece(board, piece,
                current_piece['row'], current_piece['col'], current_piece['state'],
                score, total_lines, next_idx, piece_seq)
        elif token == 'CW':
            new_state = (current_piece['state'] + 1) % 4
            # try shifts in order: 0, -1, 1, -2, 2
            moved = False
            for shift in [0, -1, 1, -2, 2]:
                test_row = current_piece['row']
                test_col = current_piece['col'] + shift
                if fits(piece, test_row, test_col, new_state, board):
                    current_piece['state'] = new_state
                    current_piece['col'] = test_col
                    moved = True
                    break
        elif token == 'CCW':
            new_state = (current_piece['state'] + 3) % 4  # -1 mod 4
            for shift in [0, -1, 1, -2, 2]:
                test_row = current_piece['row']
                test_col = current_piece['col'] + shift
                if fits(piece, test_row, test_col, new_state, board):
                    current_piece['state'] = new_state
                    current_piece['col'] = test_col
                    break
    
    # Implicit final P
    print_board(board, current_piece, score, total_lines, state_game, sys)
    
    sys.exit(0)

if __name__ == "__main__":
    main()