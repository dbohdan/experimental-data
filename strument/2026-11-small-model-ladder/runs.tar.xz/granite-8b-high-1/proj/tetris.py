#!/usr/bin/env python3

import sys

OFFSETS = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)],
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)],
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)],
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)],
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)],
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)],
    ],
}


def fits(piece_type, state, row, col, locked):
    """Check if piece fits at (row, col) in given state."""
    offsets = OFFSETS[piece_type][state]
    for r_off, c_off in offsets:
        rr = row + r_off
        cc = col + c_off
        if rr < 0 or rr >= 20 or cc < 0 or cc >= 10:
            return False
        if locked[rr][cc] != '.':
            return False
    return True


def place_piece(piece_type, row, col, state, locked):
    """Place the piece (uppercase) into locked grid."""
    offsets = OFFSETS[piece_type][state]
    for r_off, c_off in offsets:
        rr = row + r_off
        cc = col + c_off
        locked[rr][cc] = piece_type.upper()


def render(locked, piece_type, row, col, state):
    """Render board with 20 lines of 10 chars."""
    board = [list(row) for row in locked]
    offsets = OFFSETS[piece_type][state]
    for r_off, c_off in offsets:
        rr = row + r_off
        cc = col + c_off
        if board[rr][cc] == '.':
            board[rr][cc] = piece_type.lower()
    return [''.join(row) for row in board]


def main():
    data = sys.stdin.read().strip().split()
    if not data:
        return
    
    piece_sequence = data[0]
    commands = data[1:]
    
    locked = [['.' for _ in range(10)] for _ in range(20)]
    score = 0
    lines_cleared_last = 0
    
    game_state = None  # "PLAYING", "OVER", "DONE"
    current_piece = None  # {'type': str, 'row': int, 'col': int, 'state': int}
    
    # Spawn first piece
    first_type = piece_sequence[0]
    if fits(first_type, 0, 0, 3, locked):
        game_state = "PLAYING"
        current_piece = {'type': first_type, 'row': 0, 'col': 3, 'state': 0}
    else:
        game_state = "OVER"
    
    piece_idx = 0  # index in piece_sequence of current piece (0 = first spawned)
    
    # Helper to lock the current piece
    def lock():
        nonlocal locked, score, lines_cleared_last, game_state, current_piece, piece_idx
        # Place uppercase
        place_piece(current_piece['type'], current_piece['row'], current_piece['col'],
                    current_piece['state'], locked)
        # Clear full rows
        full_rows = []
        for i in range(20):
            if all(locked[i][j] != '.' for j in range(10)):
                full_rows.append(i)
        full_rows.sort(reverse=True)  # remove from bottom first
        score_inc = 0
        if len(full_rows) == 1:
            score_inc = 100
        elif len(full_rows) == 2:
            score_inc = 300
        elif len(full_rows) == 3:
            score_inc = 500
        elif len(full_rows) == 4:
            score_inc = 800
        # Remove full rows
        new_locked = [['.' for _ in range(10)] for _ in range(20)]
        src_row = 19
        for i in range(20):
            if i in full_rows:
                continue
            for j in range(10):
                new_locked[src_row][j] = locked[i][j]
            src_row -= 1
        for i in range(20):
            locked[i] = new_locked[i]
        score += score_inc
        lines_cleared_last = len(full_rows)
        # Spawn next piece
        piece_idx += 1
        if piece_idx < len(piece_sequence):
            next_type = piece_sequence[piece_idx]
            if fits(next_type, 0, 0, 3, locked):
                game_state = "PLAYING"
                current_piece = {'type': next_type, 'row': 0, 'col': 3, 'state': 0}
            else:
                game_state = "OVER"
                current_piece = None
        else:
            game_state = "DONE"
            current_piece = None
    
    # Process commands
    for cmd in commands:
        if game_state == "OVER" or game_state == "DONE":
            # Only P prints; ignore other commands
            if cmd == "P":
                # Will print after loop or inside loop; just continue
                pass
            continue
        
        if cmd == "P":
            # Print current game
            if game_state == "PLAYING" and current_piece is not None:
                lines = render(locked, current_piece['type'], current_piece['row'],
                               current_piece['col'], current_piece['state'])
                for line in lines:
                    sys.stdout.write(line + '\n')
                if game_state == "PLAYING":
                    state_str = "PLAYING"
                else:
                    state_str = game_state
                sys.stdout.write(f"SCORE {score} LINES {lines_cleared_last} {state_str}\n")
            else:
                # No piece in play
                lines = [''.join(row) for row in locked]
                for line in lines:
                    sys.stdout.write(line + '\n')
                if game_state == "PLAYING":
                    state_str = "PLAYING"
                else:
                    state_str = game_state
                sys.stdout.write(f"SCORE {score} LINES {lines_cleared_last} {state_str}\n")
            continue
        
        # Unknown command
        if cmd not in ("L", "R", "D", "H", "CW", "CCW", "P"):
            sys.stderr.write(f"error: unknown command {cmd}\n")
            continue
        
        # Only process if game_state == "PLAYING" and current_piece exists
        if game_state != "PLAYING" or current_piece is None:
            continue
        
        cur_piece = current_piece
        cur_type = cur_piece['type']
        cur_row = cur_piece['row']
        cur_col = cur_piece['col']
        cur_state = cur_piece['state']
        
        if cmd == "L":
            if fits(cur_type, cur_state, cur_row, cur_col - 1, locked):
                cur_piece['col'] -= 1
        elif cmd == "R":
            if fits(cur_type, cur_state, cur_row, cur_col + 1, locked):
                cur_piece['col'] += 1
        elif cmd == "D":
            if fits(cur_type, cur_state, cur_row + 1, cur_col, locked):
                cur_piece['row'] += 1
                score += 1
            else:
                lock()  # lock instead, no score for this D
        elif cmd == "H":
            # Find max k >= 0 such that fits at (cur_row + k, cur_col)
            max_k = 0
            for k in range(1, 20):
                if fits(cur_type, cur_state, cur_row + k, cur_col, locked):
                    max_k = k
                else:
                    break
            # Move to bottom-most fitting position
            cur_piece['row'] = cur_row + max_k
            score += 2 * max_k
            lock()  # lock after hard drop
        elif cmd == "CW":
            new_state = (cur_state + 1) % 4
            # Try at current position
            if fits(cur_type, new_state, cur_row, cur_col, locked):
                cur_piece['state'] = new_state
                continue
            # col-1
            if fits(cur_type, new_state, cur_row, cur_col - 1, locked):
                cur_piece['col'] -= 1
                cur_piece['state'] = new_state
                continue
            # col+1
            if fits(cur_type, new_state, cur_row, cur_col + 1, locked):
                cur_piece['col'] += 1
                cur_piece['state'] = new_state
                continue
            # col-2
            if fits(cur_type, new_state, cur_row, cur_col - 2, locked):
                cur_piece['col'] -= 2
                cur_piece['state'] = new_state
                continue
            # col+2
            if fits(cur_type, new_state, cur_row, cur_col + 2, locked):
                cur_piece['col'] += 2
                cur_piece['state'] = new_state
                continue
        elif cmd == "CCW":
            new_state = (cur_state + 3) % 4
            # Try at current position
            if fits(cur_type, new_state, cur_row, cur_col, locked):
                cur_piece['state'] = new_state
                continue
            # col-1
            if fits(cur_type, new_state, cur_row, cur_col - 1, locked):
                cur_piece['col'] -= 1
                cur_piece['state'] = new_state
                continue
            # col+1
            if fits(cur_type, new_state, cur_row, cur_col + 1, locked):
                cur_piece['col'] += 1
                cur_piece['state'] = new_state
                continue
            # col-2
            if fits(cur_type, new_state, cur_row, cur_col - 2, locked):
                cur_piece['col'] -= 2
                cur_piece['state'] = new_state
                continue
            # col+2
            if fits(cur_type, new_state, cur_row, cur_col + 2, locked):
                cur_piece['col'] += 2
                cur_piece['state'] = new_state
                continue
    
    # End of input: print board once more
    if game_state == "PLAYING" and current_piece is not None:
        lines = render(locked, current_piece['type'], current_piece['row'],
                       current_piece['col'], current_piece['state'])
        for line in lines:
            sys.stdout.write(line + '\n')
        if game_state == "PLAYING":
            state_str = "PLAYING"
        else:
            state_str = game_state
        sys.stdout.write(f"SCORE {score} LINES {lines_cleared_last} {state_str}\n")
    else:
        lines = [''.join(row) for row in locked]
        for line in lines:
            sys.stdout.write(line + '\n')
        if game_state == "PLAYING":
            state_str = "PLAYING"
        else:
            state_str = game_state
        sys.stdout.write(f"SCORE {score} LINES {lines_cleared_last} {state_str}\n")


if __name__ == "__main__":
    main()
