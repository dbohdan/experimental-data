import sys

PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)],
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)],
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)],
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)],
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)],
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)],
    ],
}

class Tetris:
    def __init__(self, piece_sequence):
        self.rows = 20
        self.cols = 10
        self.board = [['.' for _ in range(self.cols)] for _ in range(self.rows)]
        self.piece_sequence = list(piece_sequence)
        self.score = 0
        self.lines_cleared = 0
        self.state = 'PLAYING'  # PLAYING, OVER, DONE
        self.current_piece = None
        self.current_piece_type = None
        self.current_piece_state = 0
        self.current_piece_pos = (0, 0) # (row, col)

        if self.piece_sequence:
            self._spawn_piece()
        else:
            self.state = 'DONE'

    def _spawn_piece(self):
        if not self.piece_sequence:
            self.state = 'DONE'
            self.current_piece = None
            return

        self.current_piece_type = self.piece_sequence.pop(0)
        self.current_piece_state = 0
        self.current_piece_pos = (0, 3)

        if not self._fits(self.current_piece_type, self.current_piece_state, self.current_piece_pos):
            self.state = 'OVER'
            self.current_piece = None
        else:
            self.current_piece = self.current_piece_type

    def _fits(self, piece_type, state, pos):
        for dr, dc in PIECES[piece_type][state]:
            r, c = pos[0] + dr, pos[1] + dc
            if not (0 <= r < self.rows and 0 <= c < self.cols) or self.board[r][c] != '.':
                return False
        return True

    def move_left(self):
        if self.state != 'PLAYING' or self.current_piece is None:
            return
        new_pos = (self.current_piece_pos[0], self.current_piece_pos[1] - 1)
        if self._fits(self.current_piece_type, self.current_piece_state, new_pos):
            self.current_piece_pos = new_pos

    def move_right(self):
        if self.state != 'PLAYING' or self.current_piece is None:
            return
        new_pos = (self.current_piece_pos[0], self.current_piece_pos[1] + 1)
        if self._fits(self.current_piece_type, self.current_piece_state, new_pos):
            self.current_piece_pos = new_pos

    def move_down(self):
        if self.state != 'PLAYING' or self.current_piece is None:
            return
        new_pos = (self.current_piece_pos[0] + 1, self.current_piece_pos[1])
        if self._fits(self.current_piece_type, self.current_piece_state, new_pos):
            self.current_piece_pos = new_pos
            self.score += 1
        else:
            self._lock_piece()

    def hard_drop(self):
        if self.state != 'PLAYING' or self.current_piece is None:
            return
        
        rows_moved = 0
        while True:
            new_pos = (self.current_piece_pos[0] + 1, self.current_piece_pos[1])
            if self._fits(self.current_piece_type, self.current_piece_state, new_pos):
                self.current_piece_pos = new_pos
                rows_moved += 1
            else:
                break
        
        self.score += 2 * rows_moved
        self._lock_piece()

    def rotate_cw(self):
        if self.state != 'PLAYING' or self.current_piece is None:
            return
        new_state = (self.current_piece_state + 1) % 4
        
        # Try current position, then shifts
        for dc in [0, -1, 1, -2, 2]:
            new_pos = (self.current_piece_pos[0], self.current_piece_pos[1] + dc)
            if self._fits(self.current_piece_type, new_state, new_pos):
                self.current_piece_state = new_state
                self.current_piece_pos = new_pos
                return

    def rotate_ccw(self):
        if self.state != 'PLAYING' or self.current_piece is None:
            return
        new_state = (self.current_piece_state + 3) % 4
        
        # Try current position, then shifts
        for dc in [0, -1, 1, -2, 2]:
            new_pos = (self.current_piece_pos[0], self.current_piece_pos[1] + dc)
            if self._fits(self.current_piece_type, new_state, new_pos):
                self.current_piece_state = new_state
                self.current_piece_pos = new_pos
                return

    def _lock_piece(self):
        # Lock the piece
        for dr, dc in PIECES[self.current_piece_type][self.current_piece_state]:
            r, c = self.current_piece_pos[0] + dr, self.current_piece_pos[1] + dc
            self.board[r][c] = self.current_piece_type

        # Clear lines
        cleared = 0
        new_board = []
        for row in self.board:
            if all(cell != '.' for cell in row):
                cleared += 1
            else:
                new_board.append(row)
        
        while len(new_board) < self.rows:
            new_board.insert(0, ['.' for _ in range(self.cols)])
        
        self.board = new_board
        
        # Update score and lines
        if cleared > 0:
            points = {1: 100, 2: 300, 3: 500, 4: 800}
            self.score += points.get(cleared, 0)
            self.lines_cleared += cleared

        # Spawn next piece
        self.current_piece = None
        self._spawn_piece()

    def print_game(self):
        # Create a copy of the board with the current piece
        display_board = [row[:] for row in self.board]
        if self.current_piece is not None:
            for dr, dc in PIECES[self.current_piece_type][self.current_piece_state]:
                r, c = self.current_piece_pos[0] + dr, self.current_piece_pos[1] + dc
                # If it's within board boundaries
                if 0 <= r < self.rows and 0 <= c < self.cols:
                    display_board[r][c] = self.current_piece_type.lower()

        for row in display_board:
            print("".join(row))
        print(f"SCORE {self.score} LINES {self.lines_cleared} {self.state}")

def main():
    # Read piece sequence
    first_line = sys.stdin.readline()
    if not first_line:
        return
    piece_sequence = first_line.strip()

    # Read commands
    commands_text = sys.stdin.read()
    commands = commands_text.split()

    game = Tetris(piece_sequence)

    for cmd in commands:
        if cmd == 'L':
            game.move_left()
        elif cmd == 'R':
            game.move_right()
        elif cmd == 'D':
            game.move_down()
        elif cmd == 'H':
            game.hard_drop()
        elif cmd == 'CW':
            game.rotate_cw()
        elif cmd == 'CCW':
            game.rotate_ccw()
        elif cmd == 'P':
            game.print_game()
        else:
            sys.stderr.write(f"error: unknown command {cmd}\\n")

    game.print_game()

if __name__ == "__main__":
    main()
