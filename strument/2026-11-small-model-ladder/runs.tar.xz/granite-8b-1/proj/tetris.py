#!/usr/bin/env python3
import sys

SHAPES = {
    'I': [
        [(1,0), (1,1), (1,2), (1,3)],
        [(0,2), (1,2), (2,2), (3,2)],
        [(2,0), (2,1), (2,2), (2,3)],
        [(0,1), (1,1), (2,1), (3,1)],
    ],
    'O': [
        [(0,1), (0,2), (1,1), (1,2)],
    ],
    'T': [
        [(0,1), (1,0), (1,1), (1,2)],
        [(0,1), (1,1), (1,2), (2,1)],
        [(1,0), (1,1), (1,2), (2,1)],
        [(0,1), (1,0), (1,1), (2,1)],
    ],
    'S': [
        [(0,1), (0,2), (1,0), (1,1)],
        [(0,1), (1,1), (1,2), (2,2)],
        [(1,1), (1,2), (2,0), (2,1)],
        [(0,0), (1,0), (1,1), (2,1)],
    ],
    'Z': [
        [(0,0), (0,1), (1,1), (1,2)],
        [(0,2), (1,1), (1,2), (2,1)],
        [(1,0), (1,1), (2,1), (2,2)],
        [(0,1), (1,0), (1,1), (2,0)],
    ],
    'J': [
        [(0,0), (1,0), (1,1), (1,2)],
        [(0,1), (0,2), (1,1), (2,1)],
        [(1,0), (1,1), (1,2), (2,2)],
        [(0,1), (1,1), (2,0), (2,1)],
    ],
    'L': [
        [(0,2), (1,0), (1,1), (1,2)],
        [(0,1), (1,1), (2,1), (2,2)],
        [(1,0), (1,1), (1,2), (2,0)],
        [(0,0), (0,1), (1,1), (2,1)],
    ],
}

CLEAR_POINTS = {1: 100, 2: 300, 3: 500, 4: 800}

def fits(board, piece, state_idx, row, col):
    offsets = SHAPES[piece][state_idx]
    for dr, dc in offsets:
        br, bc = row + dr, col + dc
        if br < 0 or br >= 20 or bc < 0 or bc >= 10:
            return False
        cell = board[br][bc]
        if cell != '.' and cell.isupper():
            return False
    return True

def place_lower(board, piece, state_idx, row, col):
    offsets = SHAPES[piece][state_idx]
    for dr, dc in offsets:
        br, bc = row + dr, col + dc
        board[br][bc] = piece.lower()

def remove_lower(board, piece, state_idx, row, col):
    offsets = SHAPES[piece][state_idx]
    for dr, dc in offsets:
        br, bc = row + dr, col + dc
        board[br][bc] = '.'

def lock_piece(board, piece, state_idx, row, col):
    offsets = SHAPES[piece][state_idx]
    for dr, dc in offsets:
        br, bc = row + dr, col + dc
        board[br][bc] = piece.upper()
    full_rows = []
    for r in range(20):
        if all(board[r][c] != '.' for c in range(10)):
            full_rows.append(r)
    if not full_rows:
        rows_cleared = 0
        points = 0
        return board, rows_cleared, points
    full_rows.sort()
    num_rows = len(full_rows)
    points = CLEAR_POINTS.get(num_rows, 0) if num_rows <= 4 else 800
    new_board = [['.' for _ in range(10)] for _ in range(20)]
    nxt = 0
    for orig_r in range(20):
        if orig_r in full_rows:
            continue
        for c in range(10):
            ch = board[orig_r][c]
            if ch != '.':
                new_board[nxt][c] = ch
        nxt += 1
    return new_board, num_rows, points

def spawn_piece(board, piece):
    if fits(board, piece, 0, 0, 3):
        place_lower(board, piece, 0, 0, 3)
        return True
    return False

def rotate_cw(board, piece, state_idx, row, col):
    candidates = [((state_idx + 1) % 4, row, col), ((state_idx + 1) % 4, row, col - 1),
                  ((state_idx + 1) % 4, row, col + 1), ((state_idx + 1) % 4, row, col - 2),
                  ((state_idx + 1) % 4, row, col + 2)]
    for ns, nr, nc in candidates:
        if fits(board, piece, ns, nr, nc):
            return ns, nr, nc
    return None, None, None

def rotate_ccw(board, piece, state_idx, row, col):
    candidates = [((state_idx + 3) % 4, row, col), ((state_idx + 3) % 4, row, col - 1),
                  ((state_idx + 3) % 4, row, col + 1), ((state_idx + 3) % 4, row, col - 2),
                  ((state_idx + 3) % 4, row, col + 2)]
    for ns, nr, nc in candidates:
        if fits(board, piece, ns, nr, nc):
            return ns, nr, nc
    return None, None, None

def main():
    data = sys.stdin.read().strip().splitlines()
    if not data:
        return
    
    seq = data[0].strip()
    cmd_tokens = []
    for line in data[1:]:
        parts = line.split()
        for tok in parts:
            if tok:
                cmd_tokens.append(tok)
    
    board = [['.' for _ in range(10)] for _ in range(20)]
    piece_idx = 0
    current_piece = None
    current_state = None
    current_row = None
    current_col = None
    score = 0
    rows_cleared_last = 0
    game_state = 'PLAYING'  # PLAYING, OVER, DONE
    
    if piece_idx < len(seq):
        piece = seq[piece_idx]
        if piece not in SHAPES:
            print(f"error: unknown piece {piece}", file=sys.stderr)
            return
        piece_idx += 1
        if spawn_piece(board, piece):
            current_piece = piece
            current_state = 0
            current_row = 0
            current_col = 3
        else:
            game_state = 'OVER'
    
    def print_game():
        for r in range(20):
            print(''.join(board[r]))
        if game_state == 'PLAYING':
            st = 'PLAYING'
        elif game_state == 'OVER':
            st = 'OVER'
        else:
            st = 'DONE'
        print(f"SCORE {score} LINES {rows_cleared_last} {st}")
    
    for token in cmd_tokens:
        if game_state == 'OVER':
            continue
        if token == 'P':
            print_game()
            continue
        if token in ('L', 'R', 'D', 'H', 'CW', 'CCW', 'P'):
            if current_piece is None:
                continue
            if token == 'L':
                if fits(board, current_piece, current_state, current_row, current_col - 1):
                    remove_lower(board, current_piece, current_state, current_row, current_col)
                    current_col -= 1
                    place_lower(board, current_piece, current_state, current_row, current_col)
            elif token == 'R':
                if fits(board, current_piece, current_state, current_row, current_col + 1):
                    remove_lower(board, current_piece, current_state, current_row, current_col)
                    current_col += 1
                    place_lower(board, current_piece, current_state, current_row, current_col)
            elif token == 'D':
                if fits(board, current_piece, current_state, current_row + 1, current_col):
                    remove_lower(board, current_piece, current_state, current_row, current_col)
                    current_row += 1
                    place_lower(board, current_piece, current_state, current_row, current_col)
                    score += 1
                else:
                    new_board, rows_cleared, points = lock_piece(board, current_piece, current_state, current_row, current_col)
                    board = new_board
                    rows_cleared_last = rows_cleared
                    score += points
                    # spawn next piece
                    if piece_idx < len(seq):
                        piece = seq[piece_idx]
                        piece_idx += 1
                        if spawn_piece(board, piece):
                            current_piece = piece
                            current_state = 0
                            current_row = 0
                            current_col = 3
                        else:
                            game_state = 'OVER'
                    else:
                        game_state = 'DONE'
            elif token == 'H':
                # find max down
                max_down = 0
                for dr in range(1, 21):
                    if fits(board, current_piece, current_state, current_row + dr, current_col):
                        max_down = dr
                    else:
                        break
                if max_down > 0:
                    remove_lower(board, current_piece, current_state, current_row, current_col)
                    current_row += max_down
                    place_lower(board, current_piece, current_state, current_row, current_col)
                new_board, rows_cleared, points = lock_piece(board, current_piece, current_state, current_row, current_col)
                board = new_board
                rows_cleared_last = rows_cleared
                score += 2 * max_down
                # spawn next piece
                if piece_idx < len(seq):
                    piece = seq[piece_idx]
                    piece_idx += 1
                    if spawn_piece(board, piece):
                        current_piece = piece
                        current_state = 0
                        current_row = 0
                        current_col = 3
                    else:
                        game_state = 'OVER'
                else:
                    game_state = 'DONE'
            elif token == 'CW':
                ns, nr, nc = rotate_cw(board, current_piece, current_state, current_row, current_col)
                if ns is not None:
                    remove_lower(board, current_piece, current_state, current_row, current_col)
                    current_state = ns
                    current_row, current_col = nr, nc
                    place_lower(board, current_piece, current_state, current_row, current_col)
            elif token == 'CCW':
                ns, nr, nc = rotate_ccw(board, current_piece, current_state, current_row, current_col)
                if ns is not None:
                    remove_lower(board, current_piece, current_state, current_row, current_col)
                    current_state = ns
                    current_row, current_col = nr, nc
                    place_lower(board, current_piece, current_state, current_row, current_col)
        else:
            print(f"error: unknown command {token}", file=sys.stderr)
    
    # final print
    print_game()

if __name__ == '__main__':
    main()
