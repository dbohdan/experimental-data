import sys

SHAPES = {
    'I': [
        [(1,0),(1,1),(1,2),(1,3)],
        [(0,2),(1,2),(2,2),(3,2)],
        [(2,0),(2,1),(2,2),(2,3)],
        [(0,1),(1,1),(2,1),(3,1)],
    ],
    'O': [
        [(0,1),(0,2),(1,1),(1,2)],
        [(0,1),(0,2),(1,1),(1,2)],
        [(0,1),(0,2),(1,1),(1,2)],
        [(0,1),(0,2),(1,1),(1,2)],
    ],
    'T': [
        [(0,1),(1,0),(1,1),(1,2)],
        [(0,1),(1,1),(1,2),(2,1)],
        [(1,0),(1,1),(1,2),(2,1)],
        [(0,1),(1,0),(1,1),(2,1)],
    ],
    'S': [
        [(0,1),(0,2),(1,0),(1,1)],
        [(0,1),(1,1),(1,2),(2,2)],
        [(1,1),(1,2),(2,0),(2,1)],
        [(0,0),(1,0),(1,1),(2,1)],
    ],
    'Z': [
        [(0,0),(0,1),(1,1),(1,2)],
        [(0,2),(1,1),(1,2),(2,1)],
        [(1,0),(1,1),(2,1),(2,2)],
        [(0,1),(1,0),(1,1),(2,0)],
    ],
    'J': [
        [(0,0),(1,0),(1,1),(1,2)],
        [(0,1),(0,2),(1,1),(2,1)],
        [(1,0),(1,1),(1,2),(2,2)],
        [(0,1),(1,1),(2,0),(2,1)],
    ],
    'L': [
        [(0,2),(1,0),(1,1),(1,2)],
        [(0,1),(1,1),(2,1),(2,2)],
        [(1,0),(1,1),(1,2),(2,0)],
        [(0,0),(0,1),(1,1),(2,1)],
    ],
}

COLS = 10
ROWS = 20

def fits(board, piece, state, row, col):
    for r, c in SHAPES[piece][state]:
        rr, cc = row + r, col + c
        if rr < 0 or rr >= ROWS or cc < 0 or cc >= COLS:
            return False
        if board[rr][cc] != '.':
            return False
    return True

def main():
    data = sys.stdin.read().split('\n', 1)
    seq_line = data[0].strip() if data else ''
    rest = data[1] if len(data) > 1 else ''
    tokens = rest.split()

    board = [['.'] * COLS for _ in range(ROWS)]
    score = 0
    lines = 0
    seq = list(seq_line.strip())
    idx = 0
    piece = None
    state = 0
    row = 0
    col = 3
    over = False
    done = False

    out = []

    def spawn():
        nonlocal piece, state, row, col, over, done, idx
        if idx >= len(seq):
            done = True
            piece = None
            return
        piece = seq[idx]
        state = 0
        row, col = 0, 3
        if not fits(board, piece, state, row, col):
            over = True
            piece = None
            return
        idx += 1

    def print_game():
        for r in range(ROWS):
            line = []
            for c in range(COLS):
                ch = board[r][c]
                if piece is not None and (r, c) in [(row+rr, col+cc) for rr, cc in SHAPES[piece][state]]:
                    line.append(piece.lower())
                else:
                    line.append(ch)
            out.append(''.join(line))
        status = 'PLAYING' if piece is not None else ('OVER' if over else 'DONE')
        out.append(f'SCORE {score} LINES {lines} {status}')

    def clear_rows():
        nonlocal score, lines
        new_board = [row for row in board if any(ch == '.' for ch in row)]
        removed = ROWS - len(new_board)
        if removed:
            board[:] = [['.'] * COLS for _ in range(ROWS - len(new_board))] + new_board
            score += [0, 100, 300, 500, 800][removed]
            lines += removed

    def lock():
        nonlocal piece
        nonlocal idx
        nonlocal over, done
        for r, c in SHAPES[piece][state]:
            rr, cc = row + r, col + c
            if 0 <= rr < ROWS and 0 <= cc < COLS:
                board[rr][cc] = piece
        piece = None
        clear_rows()
        # spawn next
        if idx >= len(seq):
            done = True
        else:
            spawn()
        # spawn may set over/done

    def hard_drop():
        nonlocal score
        nonlocal row
        moved = 0
        while fits(board, piece, state, row + 1, col):
            row += 1
            moved += 1
        score += 2 * moved
        lock()

    spawn()

    for tok in tokens:
        if tok == 'P':
            print_game()
            continue
        if piece is None:
            continue
        if tok == 'L':
            if fits(board, piece, state, row, col - 1):
                col -= 1
        elif tok == 'R':
            if fits(board, piece, state, row, col + 1):
                col += 1
        elif tok == 'D':
            if fits(board, piece, state, row + 1, col):
                row += 1
                score += 1
            else:
                lock()
        elif tok == 'H':
            hard_drop()
        elif tok == 'CW':
            new_state = (state + 1) % 4
            for dc in (0, -1, 1, -2, 2):
                if fits(board, piece, new_state, row, col + dc):
                    state = new_state
                    col += dc
                    break
        elif tok == 'CCW':
            new_state = (state + 3) % 4
            for dc in (0, -1, 1, -2, 2):
                if fits(board, piece, new_state, row, col + dc):
                    state = new_state
                    col += dc
                    break
        else:
            print(f'error: unknown command {tok}', file=sys.stderr)

    print_game()
    sys.stdout.write('\n'.join(out) + '\n')

if __name__ == '__main__':
    main()
