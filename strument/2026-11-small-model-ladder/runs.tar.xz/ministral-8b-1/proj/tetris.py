#!/usr/bin/env python3

import sys

# Define piece shapes as (r, c) offsets for each state
PIECES = {
    "I": [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)]
    ],
    "O": [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)]
    ],
    "T": [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)]
    ],
    "S": [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)]
    ],
    "Z": [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)]
    ],
    "J": [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)]
    ],
    "L": [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)]
    ],
}

# Initialize the board
BOARD_ROWS = 20
BOARD_COLS = 10

# Score table
SCORE_TABLE = {1: 100, 2: 300, 3: 500, 4: 800}

def create_board():
    return [['.' for _ in range(BOARD_COLS)] for _ in range(BOARD_ROWS)]

def fits(board, piece, pos, state, offset_col=0):
    for offset in PIECES[piece][state]:
        row, col = pos[0] + offset[0], pos[1] + offset[1] + offset_col
        if row < 0 or row >= BOARD_ROWS or col < 0 or col >= BOARD_COLS or board[row][col] != '.':
            return False
    return True

def rotate_piece(board, piece, pos, state):
    new_state = (state + 1) % 4
    for offset_col in [-2, -1, 0, 1, 2]:
        if fits(board, piece, pos, new_state, offset_col):
            return new_state, offset_col
    return state, 0

def lock_piece(board, piece, pos, state):
    for offset in PIECES[piece][state]:
        row, col = pos[0] + offset[0], pos[1] + offset[1]
        if 0 <= row < BOARD_ROWS and 0 <= col < BOARD_COLS:
            board[row][col] = piece

def clear_lines(board):
    lines_cleared = 0
    new_board = [row[:] for row in board]
    for row in range(BOARD_ROWS):
        if all(cell != '.' for cell in board[row]):
            lines_cleared += 1
            for r in range(row, 0, -1):
                new_board[r] = new_board[r - 1][:]
            new_board[0] = ['.' for _ in range(BOARD_COLS)]
    return new_board, lines_cleared

def print_board(board, piece=None, piece_pos=(0, 0), piece_state=0):
    output = []
    for row in range(BOARD_ROWS):
        line = []
        for col in range(BOARD_COLS):
            if piece and any(row == piece_pos[0] + offset[0] and col == piece_pos[1] + offset[1] for offset in PIECES[piece][piece_state]):
                line.append(piece.lower())
            else:
                line.append(board[row][col])
        output.append(''.join(line))
    return output

def main():
    board = create_board()
    piece_sequence = sys.stdin.readline().strip()
    commands = sys.stdin.read().split()
    
    # Game state
    current_piece = None
    piece_pos = (0, 3)
    piece_state = 0
    score = 0
    lines_cleared = 0
    game_over = False
    game_done = False
    
    # Spawn the first piece
    if piece_sequence:
        current_piece = piece_sequence[0]
        piece_pos = (0, 3)
        if not fits(board, current_piece, piece_pos, 0):
            game_over = True
        piece_sequence = piece_sequence[1:]
    
    # Process commands
    cmd_idx = 0
    while cmd_idx < len(commands) and not game_over and not game_done:
        cmd = commands[cmd_idx]
        
        if not current_piece:
            cmd_idx += 1
            continue
            
        if cmd == 'L':
            if fits(board, current_piece, (piece_pos[0], piece_pos[1] - 1), piece_state):
                piece_pos = (piece_pos[0], piece_pos[1] - 1)
            cmd_idx += 1
        elif cmd == 'R':
            if fits(board, current_piece, (piece_pos[0], piece_pos[1] + 1), piece_state):
                piece_pos = (piece_pos[0], piece_pos[1] + 1)
            cmd_idx += 1
        elif cmd == 'D':
            if fits(board, current_piece, (piece_pos[0] + 1, piece_pos[1]), piece_state):
                piece_pos = (piece_pos[0] + 1, piece_pos[1])
                score += 1
            else:
                lock_piece(board, current_piece, piece_pos, piece_state)
            board, lines = clear_lines(board)
                score += SCORE_TABLE.get(lines, 0)
                lines_cleared += lines
                
                # Spawn next piece
                if piece_sequence:
                    current_piece = piece_sequence[0]
                    piece_pos = (0, 3)
                    if not fits(board, current_piece, piece_pos, 0):
                        game_over = True
                    piece_sequence = piece_sequence[1:]
                else:
                    game_done = True
            cmd_idx += 1
        elif cmd == 'H':
            rows_dropped = 0
            while fits(board, current_piece, (piece_pos[0] + rows_dropped + 1, piece_pos[1]), piece_state):
                rows_dropped += 1
            if rows_dropped > 0:
                piece_pos = (piece_pos[0] + rows_dropped, piece_pos[1])
                score += 2 * rows_dropped
            lock_piece(board, current_piece, piece_pos, piece_state)
            board, lines = clear_lines(board)
                score += SCORE_TABLE.get(lines, 0)
                lines_cleared += lines
                
                # Spawn next piece
                if piece_sequence:
                    current_piece = piece_sequence[0]
                    piece_pos = (0, 3)
                    if not fits(board, current_piece, piece_pos, 0):
                        game_over = True
                    piece_sequence = piece_sequence[1:]
                else:
                    game_done = True
            cmd_idx += 1
        elif cmd == 'CW':
            new_state, offset_col = rotate_piece(board, current_piece, piece_pos, piece_state)
            if new_state != piece_state:
                piece_state = new_state
                piece_pos = (piece_pos[0], piece_pos[1] + offset_col)
            cmd_idx += 1
        elif cmd == 'CCW':
            new_state, offset_col = rotate_piece(board, current_piece, piece_pos, (piece_state + 3) % 4)
            if new_state != piece_state:
                piece_state = new_state
                piece_pos = (piece_pos[0], piece_pos[1] + offset_col)
            cmd_idx += 1
        elif cmd == 'P':
            output = print_board(board, current_piece, piece_pos, piece_state)
            output.append(f"SCORE {score} LINES {lines_cleared} {'PLAYING' if current_piece else 'OVER' if game_over else 'DONE'}")
            print("\n".join(output))
            cmd_idx += 1
        else:
            print(f"error: unknown command {cmd}", file=sys.stderr)
            cmd_idx += 1

    # Print final board
    output = print_board(board, current_piece, piece_pos, piece_state)
    output.append(f"SCORE {score} LINES {lines_cleared} {'PLAYING' if current_piece else 'OVER' if game_over else 'DONE'}")
    print('
'.join(output))

if __name__ == "__main__":
    main()