#!/usr/bin/env python3
"""Headless Tetris - plays from stdin, prints to stdout."""

import sys

# Piece shapes: (r, c) offsets in 4x4 box for each state (0..3)
PIECE_SHAPES = {
    'I': [
        (1, 0), (1, 1), (1, 2), (1, 3),
        (0, 2), (1, 2), (2, 2), (3, 2),
        (2, 0), (2, 1), (2, 2), (2, 3),
        (0, 1), (1, 1), (2, 1), (3, 1),
    ],
    'O': [
        (0, 1), (0, 2), (1, 1), (1, 2),
        (0, 1), (0, 2), (1, 1), (1, 2),
        (0, 1), (0, 2), (1, 1), (1, 2),
        (0, 1), (0, 2), (1, 1), (1, 2),
    ],
    'T': [
        (0, 1), (1, 0), (1, 1), (1, 2),
        (0, 1), (1, 1), (1, 2), (2, 1),
        (1, 0), (1, 1), (1, 2), (2, 1),
        (0, 1), (1, 0), (1, 1), (2, 1),
    ],
    'S': [
        (0, 1), (0, 2), (1, 0), (1, 1),
        (0, 1), (1, 1), (1, 2), (2, 2),
        (1, 1), (1, 2), (2, 0), (2, 1),
        (0, 0), (1, 0), (1, 1), (2, 1),
    ],
    'Z': [
        (0, 0), (0, 1), (1, 1), (1, 2),
        (0, 2), (1, 1), (1, 2), (2, 1),
        (1, 0), (1, 1), (2, 1), (2, 2),
        (0, 1), (1, 0), (1, 1), (2, 0),
    ],
    'J': [
        (0, 0), (1, 0), (1, 1), (1, 2),
        (0, 1), (0, 2), (1, 1), (2, 1),
        (1, 0), (1, 1), (1, 2), (2, 2),
        (0, 1), (1, 1), (2, 0), (2, 1),
    ],
    'L': [
        (0, 2), (1, 0), (1, 1), (1, 2),
        (0, 1), (1, 1), (2, 1), (2, 2),
        (1, 0), (1, 1), (1, 2), (2, 0),
        (0, 0), (0, 1), (1, 1), (2, 1),
    ],
}

PIECE_TYPES = list(PIECE_SHAPES.keys())


def main():
    data = sys.stdin.read().split('\n')

    # First line is piece sequence
    piece_seq = data[0].strip()

    # Remaining lines are commands (whitespace-separated)
    commands_text = ' '.join(data[1:])
    commands = commands_text.split()

    # Board: 10 columns x 20 rows
    ROWS = 20
    COLS = 10
    board = [['.' for _ in range(COLS)] for _ in range(ROWS)]

    score = 0
    lines_cleared = 0
    piece_seq_idx = 0
    state = 0
    row = 0
    col = 3
    current_piece = None
    game_state = 'PLAYING'  # 'PLAYING', 'OVER', or 'DONE'
    game_over = False

    def try_spawn():
        nonlocal current_piece, piece_seq_idx, game_state, game_over

        if piece_seq_idx >= len(piece_seq):
            # No more pieces to spawn; game is done
            game_state = 'DONE'
            return

        piece_type = piece_seq[piece_seq_idx]
        piece_seq_idx += 1

        # Try to place at (0, 3) state 0
        if not fits(piece_type, 0, 0, 3):
            # Game over: piece doesn't fit at spawn position
            game_state = 'OVER'
            return

        # Place the piece
        current_piece = piece_type
        state = 0
        row = 0
        col = 3
        # Add the piece's blocks to the board
        for r, c in PIECE_SHAPES[piece_type][0]:
            board[r][c] = piece_type

    def fits(piece_type, state, r, c):
        """Check if the piece fits at (r, c) with given state."""
        for br, bc in PIECE_SHAPES[piece_type][state]:
            nr = r + br
            nc = c + bc
            if nr < 0 or nr >= ROWS or nc < 0 or nc >= COLS:
                return False
            if board[nr][nc] != '.':
                return False
        return True

    def place_piece():
        nonlocal current_piece, state, row, col
        for br, bc in PIECE_SHAPES[current_piece][state]:
            board[row + br][col + bc] = current_piece

    def clear_rows():
        nonlocal score, lines_cleared

        # Find full rows
        full_rows = []
        for r in range(ROWS):
            if all(board[r][c] != '.' for c in range(COLS)):
                full_rows.append(r)

        if not full_rows:
            return

        # Score: 100 per row, 300 for 2, 500 for 3, 800 for 4
        score += len(full_rows) * [100, 300, 500, 800][len(full_rows) - 1]
        lines_cleared += len(full_rows)

        # Remove full rows, shift down, add empty rows at top
        # We'll rebuild the board
        new_board = [['.' for _ in range(COLS)] for _ in range(ROWS)]
        for r in range(ROWS):
            if r in full_rows:
                continue
            dest = r - len(full_rows)
            if dest >= 0:
                for c in range(COLS):
                    new_board[dest][c] = board[r][c]

        board = new_board

    def handle_command(cmd):
        nonlocal current_piece, state, row, col, game_state

        if current_piece is None:
            # No piece in play; only P prints
            return

        if cmd == 'L':
            if fits(current_piece, state, row, col - 1):
                col -= 1
        elif cmd == 'R':
            if fits(current_piece, state, row, col + 1):
                col += 1
        elif cmd == 'D':
            if fits(current_piece, state, row + 1, col):
                row += 1
                score += 1
            else:
                place_piece()
        elif cmd == 'H':
            rows_moved = 0
            while fits(current_piece, state, row + rows_moved + 1, col):
                rows_moved += 1
            if rows_moved > 0:
                score += rows_moved * 2
                row += rows_moved
                place_piece()
        elif cmd == 'CW':
            new_state = (state + 1) % 4
            if fits(current_piece, new_state, row, col):
                state = new_state
            # If doesn't fit, nothing happens
        elif cmd == 'CCW':
            new_state = (state + 3) % 4
            if fits(current_piece, new_state, row, col):
                state = new_state
            # If doesn't fit, nothing happens
        elif cmd == 'P':
            pass
        else:
            print(f'error: unknown command {cmd}', file=sys.stderr)

    def print_board():
        for r in range(ROWS):
            print(''.join(board[r]))

    # Spawn the first piece
    try_spawn()

    # Process commands
    for cmd in commands:
        if game_state == 'OVER':
            break
        if cmd == 'P':
            print_board()
        else:
            handle_command(cmd)
            # Check if game is over (no piece in play)
            if current_piece is None and cmd != 'P':
                game_state = 'DONE'

    # Final print
    if game_state == 'OVER':
        # No final print needed - the game ended because the piece didn't spawn
        # But if a piece was in play and then game over happened... actually
        # The spec says: if piece spawns and doesn't fit, game over.
        # But the game can also end when the sequence runs out (DONE).
        # When OVER, we don't print anything else.
        pass
    elif game_state == 'DONE':
        pass

    # Output
    print_board()
    print(f'SCORE {score} LINES {lines_cleared} {game_state}')


if __name__ == '__main__':
    main()
