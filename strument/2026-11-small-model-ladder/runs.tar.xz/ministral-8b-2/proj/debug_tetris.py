#!/usr/bin/env python3

import sys

# Define piece shapes and their rotations
PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)]
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
    ] * 4,
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)]
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)]
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)]
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)]
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)]
    ],
}

# Initialize the board
BOARD_WIDTH = 10
BOARD_HEIGHT = 20
board = [['.' for _ in range(BOARD_WIDTH)] for _ in range(BOARD_HEIGHT)]

# Game state
score = 0
lines_cleared = 0
game_state = "PLAYING"
current_piece_type = None
current_piece_state = 0
current_piece_position = (0, 3)
piece_sequence = []

# Score multiplier for lines cleared
SCORE_MULTIPLIER = [0, 100, 300, 500, 800]

def is_valid_position(piece_type, state, position, board):
    """Check if the piece fits at the given position and state."""
    offsets = PIECES[piece_type][state]
    row, col = position
    for offset_row, offset_col in offsets:
        board_row = row + offset_row
        board_col = col + offset_col
        if (board_row < 0 or board_row >= BOARD_HEIGHT or 
            board_col < 0 or board_col >= BOARD_WIDTH or
            (board_row >= 0 and board_col >= 0 and board[board_row][board_col] != '.')):
            return False
    return True

def lock_piece():
    """Lock the current piece onto the board."""
    global score, lines_cleared, game_state, current_piece_type
    if current_piece_type is None:
        return
    
    piece_type = current_piece_type
    state = current_piece_state
    position = current_piece_position
    offsets = PIECES[piece_type][state]
    
    # Place the piece on the board
    for offset_row, offset_col in offsets:
        board_row = position[0] + offset_row
        board_col = position[1] + offset_col
        if board_row >= 0 and board_col >= 0:
            board[board_row][board_col] = piece_type.upper()
    
    # Check for cleared lines
    cleared_lines = []
    for row in range(BOARD_HEIGHT):
        if all(cell != '.' for cell in board[row]):
            cleared_lines.append(row)
    
    # Remove cleared lines
    for line in sorted(cleared_lines, reverse=True):
        del board[line]
        board.insert(0, ['.' for _ in range(BOARD_WIDTH)])
    
    # Update score and lines cleared
    if cleared_lines:
        lines_cleared += len(cleared_lines)
        score += SCORE_MULTIPLIER[len(cleared_lines)]
    
    # Spawn next piece
    if piece_sequence:
        current_piece_type = piece_sequence.pop(0)
        current_piece_state = 0
        current_piece_position = (0, 3)
        if not is_valid_position(current_piece_type, current_piece_state, current_piece_position, board):
            game_state = "OVER"
    else:
        game_state = "DONE"
    
    print(f"Locked piece {piece_type}, score: {score}, lines: {lines_cleared}, state: {game_state}")
    print_board()

def rotate_piece(direction):
    """Rotate the current piece."""
    global current_piece_state, current_piece_position
    if current_piece_type is None:
        return False
    
    if direction == "CW":
        new_state = (current_piece_state + 1) % 4
    elif direction == "CCW":
        new_state = (current_piece_state - 1) % 4
    else:
        return False
    
    # Try to rotate at current position
    if is_valid_position(current_piece_type, new_state, current_piece_position, board):
        current_piece_state = new_state
        print(f"Rotated {direction}, state: {current_piece_state}")
        return True
    
    # Try shifting columns to fit
    for shift in [-1, 1, -2, 2]:
        new_col = current_piece_position[1] + shift
        if is_valid_position(current_piece_type, new_state, (current_piece_position[0], new_col), board):
            current_piece_position = (current_piece_position[0], new_col)
            current_piece_state = new_state
            print(f"Rotated {direction} with shift {shift}, state: {current_piece_state}")
            return True
    
    print(f"Failed to rotate {direction}")
    return False

def move_piece(direction):
    """Move the current piece in the specified direction."""
    global current_piece_position
    if current_piece_type is None:
        return False
    
    row, col = current_piece_position
    if direction == "L":
        new_col = col - 1
        if is_valid_position(current_piece_type, current_piece_state, (row, new_col), board):
            current_piece_position = (row, new_col)
            print(f"Moved left to {current_piece_position}")
            return True
    elif direction == "R":
        new_col = col + 1
        if is_valid_position(current_piece_type, current_piece_state, (row, new_col), board):
            current_piece_position = (row, new_col)
            print(f"Moved right to {current_piece_position}")
            return True
    elif direction == "D":
        new_row = row + 1
        if is_valid_position(current_piece_type, current_piece_state, (new_row, col), board):
            current_piece_position = (new_row, col)
            print(f"Moved down to {current_piece_position}")
            return True
        else:
            lock_piece()
            return False
    return False

def hard_drop():
    """Move the current piece down as far as possible."""
    global score, current_piece_position
    if current_piece_type is None:
        return False
    
    row, col = current_piece_position
    rows_moved = 0
    while True:
        if is_valid_position(current_piece_type, current_piece_state, (row + rows_moved + 1, col), board):
            rows_moved += 1
        else:
            break
    
    if rows_moved > 0:
        current_piece_position = (row + rows_moved, col)
        score += 2 * rows_moved
        print(f"Hard drop moved {rows_moved} rows, score: {score}")
    
    lock_piece()
    return True

def print_board():
    """Print the board with the current piece in place."""
    temp_board = [row[:] for row in board]
    if current_piece_type is not None:
        piece_type = current_piece_type
        state = current_piece_state
        position = current_piece_position
        offsets = PIECES[piece_type][state]
        for offset_row, offset_col in offsets:
            board_row = position[0] + offset_row
            board_col = position[1] + offset_col
            if 0 <= board_row < BOARD_HEIGHT and 0 <= board_col < BOARD_WIDTH:
                temp_board[board_row][board_col] = piece_type.lower()
    
    for row in temp_board:
        print(''.join(row))
    
    print(f"SCORE {score} LINES {lines_cleared} {game_state}")

def main():
    global piece_sequence, game_state
    
    # Read input
    input_lines = sys.stdin.read().splitlines()
    if not input_lines:
        return
    
    piece_sequence = list(input_lines[0])
    commands = input_lines[1:]
    
    # Spawn the first piece
    if piece_sequence:
        current_piece_type = piece_sequence.pop(0)
        current_piece_state = 0
        current_piece_position = (0, 3)
        if not is_valid_position(current_piece_type, current_piece_state, current_piece_position, board):
            game_state = "OVER"
            print(f"Game over on spawn, state: {game_state}")
    
    print_board()
    
    # Process commands
    for cmd in ' '.join(commands).split():
        if game_state == "OVER" or game_state == "DONE":
            if cmd == "P":
                print_board()
            continue
        
        print(f"Executing command: {cmd}")
        if cmd == "L":
            move_piece("L")
        elif cmd == "R":
            move_piece("R")
        elif cmd == "D":
            move_piece("D")
        elif cmd == "H":
            hard_drop()
        elif cmd == "CW":
            rotate_piece("CW")
        elif cmd == "CCW":
            rotate_piece("CCW")
        elif cmd == "P":
            print_board()
        else:
            print(f"error: unknown command {cmd}", file=sys.stderr)
    
    # Print final board
    print_board()

if __name__ == "__main__":
    main()