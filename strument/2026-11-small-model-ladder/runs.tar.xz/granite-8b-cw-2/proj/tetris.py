#!/usr/bin/env python3
"""Headless Tetris according to SPEC.md"""

import sys

# Piece shapes as list of (r, c) offsets for each state (0-3)
PIECE_SHAPES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],  # state 0
        [(0, 2), (1, 2), (2, 2), (3, 2)],  # state 1
        [(2, 0), (2, 1), (2, 2), (2, 3)],  # state 2
        [(0, 1), (1, 1), (2, 1), (3, 1)],  # state 3
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)],
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)],
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)],
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)],
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)],
    ],
}


def fits(piece, state, row, col, locked):
    """Return True if piece at (row, col) state fits on locked board."""
    offsets = PIECE_SHAPES[piece][state]
    for r_off, c_off in offsets:
        r = row + r_off
        c = col + c_off
        if r < 0 or r >= 20 or c < 0 or c >= 10:
            return False
        if locked[r][c] != '.':
            return False
    return True


def try_rotate(piece, state, row, col, locked, direction):
    """
    direction = 1 for CW, -1 for CCW.
    Search shifts: [0, -1, 1, -2, 2]
    """
    new_state = (state + 1) % 4 if direction == 1 else (state + 3) % 4
    shifts = [0, -1, 1, -2, 2]
    for shift in shifts:
        cand_row = row
        cand_col = col + shift
        offsets = PIECE_SHAPES[piece][new_state]
        fit = True
        for r_off, c_off in offsets:
            r = cand_row + r_off
            c = cand_col + c_off
            if r < 0 or r >= 20 or c < 0 or c >= 10:
                fit = False
                break
            if locked[r][c] != '.':
                fit = False
                break
        if fit:
            return (cand_row, cand_col, new_state)
    return None


def lock_piece(piece, row, col, state, locked):
    """
    Lock the current piece into locked board as uppercase.
    Perform row clearing. Return (score_inc, rows_cleared).
    """
    # Place piece as uppercase
    offsets = PIECE_SHAPES[piece][state]
    for r_off, c_off in offsets:
        r = row + r_off
        c = col + c_off
        if 0 <= r < 20 and 0 <= c < 10:
            locked[r][c] = piece
    
    # Find full rows (all 10 cells are not '.')
    full_rows = []
    for r in range(20):
        full = True
        for c in range(10):
            if locked[r][c] == '.':
                full = False
                break
        if full:
            full_rows.append(r)
    
    if not full_rows:
        return 0, 0
    
    full_rows.sort(reverse=True)
    rows_cleared = len(full_rows)
    # Score increment
    if rows_cleared == 1:
        score_inc = 100
    elif rows_cleared == 2:
        score_inc = 300
    elif rows_cleared == 3:
        score_inc = 500
    elif rows_cleared == 4:
        score_inc = 800
    else:
        score_inc = 0
    
    # Remove full rows
    new_locked = [['.' for _ in range(10)] for _ in range(20)]
    idx = 0
    for r in range(20):
        if r in full_rows:
            continue
        for c in range(10):
            new_locked[idx][c] = locked[r][c]
        idx += 1
    for r in range(20):
        for c in range(10):
            locked[r][c] = new_locked[r][c]
    
    return score_inc, rows_cleared


def main():
    data = sys.stdin.read().strip().split()
    if not data:
        return
    
    piece_seq = data[0]
    commands = data[1:]
    
    locked = [['.' for _ in range(10)] for _ in range(20)]
    score = 0
    STATE_PLAYING = "PLAYING"
    STATE_OVER = "OVER"
    STATE_DONE = "DONE"
    current_state = STATE_PLAYING
    
    # Piece index in sequence
    piece_idx = 0
    
    # Current piece info (None if game over)
    current = None
    last_rows_cleared = 0
    
    # Spawn first piece
    piece_idx = 0
    current = None
    for piece_letter in piece_seq:
        row, col = 0, 3
        state = 0
        offsets = PIECE_SHAPES[piece_letter][state]
        blocks = [(row + r_off, col + c_off) for r_off, c_off in offsets]
        ok = True
        for r, c in blocks:
            if locked[r][c] != '.':
                ok = False
                break
        if not ok:
            current_state = STATE_OVER
            break
        current = (piece_letter, row, col, state)
        piece_idx += 1
        # Spawn next piece after current locks? No, first piece spawns before first command
        # We'll keep current and continue loop for all pieces? No, pieces are spawned one by one as needed
        # Actually we only spawn when piece locks or when starting
        # For simplicity, we'll just spawn the first piece and when it locks, spawn next
        # So we only need to spawn the first piece now
        # Break after first piece
        break
    
    # Helper to print board
    def print_board():
        for r in range(20):
            line = []
            for c in range(10):
                if locked[r][c] != '.':
                    line.append(locked[r][c])
                else:
                    line.append('.')
            if current is not None:
                _, row_cur, col_cur, state_cur = current
                piece_letter_cur = current[0]
                offsets = PIECE_SHAPES[piece_letter_cur][state_cur]
                for r_off, c_off in offsets:
                    rr = row_cur + r_off
                    cc = col_cur + c_off
                    if 0 <= rr < 20 and 0 <= cc < 10:
                        if locked[rr][cc] == '.':
                            line[cc] = piece_letter_cur.lower()
            sys.stdout.write(''.join(line) + '\n')
    
    # Process commands
    for cmd in commands:
        if current_state == STATE_OVER or current_state == STATE_DONE:
            if cmd == 'P':
                continue
            continue
        
        if cmd == 'L':
            if current is not None:
                piece_letter, row, col, state = current
                if fits(piece_letter, state, row, col - 1, locked):
                    current = (piece_letter, row, col - 1, state)
            continue
        elif cmd == 'R':
            if current is not None:
                piece_letter, row, col, state = current
                if fits(piece_letter, state, row, col + 1, locked):
                    current = (piece_letter, row, col + 1, state)
            continue
        elif cmd == 'D':
            if current is not None:
                piece_letter, row, col, state = current
                if fits(piece_letter, state, row + 1, col, locked):
                    current = (piece_letter, row + 1, col, state)
                    score += 1
                else:
                    # Lock instead, no score for this D
                    score_inc, rows_cleared = lock_piece(piece_letter, row, col, state, locked)
                    last_rows_cleared = rows_cleared
                    score += score_inc
                    # Spawn next piece
                    # Advance piece_idx if there is next
                    if piece_idx < len(piece_seq):
                        piece_letter_next = piece_seq[piece_idx]
                        row_next, col_next = 0, 3
                        state_next = 0
                        offsets = PIECE_SHAPES[piece_letter_next][state_next]
                        blocks = [(row_next + r_off, col_next + c_off) for r_off, c_off in offsets]
                        ok = True
                        for r, c in blocks:
                            if locked[r][c] != '.':
                                ok = False
                                break
                        if ok:
                            current = (piece_letter_next, row_next, col_next, state_next)
                            piece_idx += 1
                        else:
                            current_state = STATE_OVER
                    else:
                        current_state = STATE_DONE
            continue
        elif cmd == 'H':
            if current is not None:
                piece_letter, row, col, state = current
                max_down = 0
                for dr in range(1, 20 - row + 1):
                    if fits(piece_letter, state, row + dr, col, locked):
                        max_down = dr
                    else:
                        break
                if max_down > 0:
                    current = (piece_letter, row + max_down, col, state)
                    score += 2 * max_down
                    # Lock now
                    score_inc, rows_cleared = lock_piece(piece_letter, row + max_down, col, state, locked)
                    last_rows_cleared = rows_cleared
                    score += score_inc
                else:
                    score_inc, rows_cleared = lock_piece(piece_letter, row, col, state, locked)
                    last_rows_cleared = rows_cleared
                    score += score_inc
                # Spawn next piece
                if piece_idx < len(piece_seq):
                    piece_letter_next = piece_seq[piece_idx]
                    row_next, col_next = 0, 3
                    state_next = 0
                    offsets = PIECE_SHAPES[piece_letter_next][state_next]
                    blocks = [(row_next + r_off, col_next + c_off) for r_off, c_off in offsets]
                    ok = True
                    for r, c in blocks:
                        if locked[r][c] != '.':
                            ok = False
                            break
                    if ok:
                        current = (piece_letter_next, row_next, col_next, state_next)
                        piece_idx += 1
                    else:
                        current_state = STATE_OVER
                else:
                    current_state = STATE_DONE
            continue
        elif cmd == 'CW':
            if current is not None:
                piece_letter, row, col, state = current
                result = try_rotate(piece_letter, state, row, col, locked, 1)
                if result is not None:
                    r, c, s = result
                    current = (piece_letter, r, c, s)
            continue
        elif cmd == 'CCW':
            if current is not None:
                piece_letter, row, col, state = current
                result = try_rotate(piece_letter, state, row, col, locked, -1)
                if result is not None:
                    r, c, s = result
                    current = (piece_letter, r, c, s)
            continue
        elif cmd == 'P':
            print_board()
            if current_state == STATE_PLAYING:
                sys.stdout.write(f"SCORE {score} LINES {last_rows_cleared} {STATE_PLAYING}\n")
            elif current_state == STATE_OVER:
                sys.stdout.write(f"SCORE {score} LINES {last_rows_cleared} {STATE_OVER}\n")
            elif current_state == STATE_DONE:
                sys.stdout.write(f"SCORE {score} LINES {last_rows_cleared} {STATE_DONE}\n")
            continue
        else:
            sys.stderr.write(f"error: unknown command {cmd}\n")
    
    # Final output
    print_board()
    if current_state == STATE_PLAYING:
        sys.stdout.write(f"SCORE {score} LINES {last_rows_cleared} {STATE_PLAYING}\n")
    elif current_state == STATE_OVER:
        sys.stdout.write(f"SCORE {score} LINES {last_rows_cleared} {STATE_OVER}\n")
    elif current_state == STATE_DONE:
        sys.stdout.write(f"SCORE {score} LINES {last_rows_cleared} {STATE_DONE}\n")


if __name__ == "__main__":
    main()