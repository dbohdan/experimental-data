"""Headless Tetris, per SPEC.md.

Plays the game described in SPEC.md from commands on standard input and
prints the board to standard output.  Run as:

    python3 tetris.py < game.txt
"""

import sys

BOARD_COLS = 10
BOARD_ROWS = 20

# Blocks of each piece state as (row, col) offsets in a 4x4 box.
PIECES = {
    "I": [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)],
    ],
    "O": [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
    ],
    "T": [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)],
    ],
    "S": [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)],
    ],
    "Z": [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)],
    ],
    "J": [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)],
    ],
    "L": [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)],
    ],
}

# Points for the number of rows cleared at once.
CLEAR_POINTS = {1: 100, 2: 300, 3: 500, 4: 800}

# Rotation offsets for the four column shifts, in order.
ROTATION_SHIFTS = [0, -1, 1, -2, 2]


def blocks(piece, state, row, col):
    """Return the list of (row, col) board cells occupied by the piece."""
    return [(row + r, col + c) for r, c in PIECES[piece][state]]


def max_block_row(piece, state):
    """Largest row offset among the piece's blocks in the given state."""
    return max(r for r, _ in PIECES[piece][state])


def max_block_col(piece, state):
    """Largest column offset among the piece's blocks in the given state."""
    return max(c for _, c in PIECES[piece][state])


def fits(piece, state, row, col, board):
    """True when the piece fits at (row, col) with the given state.

    A block outside the board counts as occupied, so the piece does not fit.
    """
    for r, c in blocks(piece, state, row, col):
        if r < 0 or r >= BOARD_ROWS or c < 0 or c >= BOARD_COLS:
            return False
        if board[r][c] is not None:
            return False
    return True


def print_board(board):
    """Print the 20 rows of the board, top row first, 10 chars each."""
    out = []
    for row in range(BOARD_ROWS - 1, -1, -1):
        line = "".join(
            board[row][col] if board[row][col] is not None else "."
            for col in range(BOARD_COLS)
        )
        out.append(line)
    return out


def clear_rows(board, rows_cleared):
    """Remove the given rows, moving the rows above down and empty rows in at top."""
    surviving = [
        [board[row][col] for col in range(BOARD_COLS)]
        for row in range(BOARD_ROWS)
        if not all(board[row][col] is not None for col in range(BOARD_COLS))
    ]
    for row in range(BOARD_ROWS):
        for col in range(BOARD_COLS):
            board[row][col] = None
    for row, line in enumerate(surviving):
        for col in range(BOARD_COLS):
            board[row][col] = line[col]
    return rows_cleared


def lock(board, piece, state, letter, row, col):
    """Lock the piece at its current position and clear full rows."""
    for r, c in blocks(piece, state, row, col):
        board[r][c] = letter
    rows_cleared = 0
    for row in range(BOARD_ROWS):
        if all(board[row][col] is not None for col in range(BOARD_COLS)):
            rows_cleared += 1
    if rows_cleared:
        clear_rows(board, rows_cleared)
    return rows_cleared


def try_rotate(piece, state, board, row, col, new_state):
    """Try the new state and the column shifts, in order, keeping the row.

    Tries the new state at the current position, then with the column shifted
    by -1, +1, -2, +2.  Returns (new_state, col) if one fits, otherwise
    (state, col) so nothing happens.
    """
    for shift in ROTATION_SHIFTS:
        if fits(piece, new_state, row, col + shift, board):
            return new_state, col + shift
    return state, col


def main():
    data = sys.stdin.read().split()
    if not data:
        return
    sequence = data[0]
    commands = data[1:]

    board = [[None for _ in range(BOARD_COLS)] for _ in range(BOARD_ROWS)]
    score = 0
    lines_cleared = 0
    state = "PLAYING"
    piece = None
    piece_state = 0
    piece_row = 0
    piece_col = 3
    index = 0

    def spawn():
        nonlocal piece, piece_state, piece_row, piece_col, index
        if index < len(sequence):
            piece = sequence[index]
            piece_state = 0
            piece_row = 0
            piece_col = 3
            index += 1
            if not fits(piece, piece_state, piece_row, piece_col, board):
                state = "OVER"
                piece = None
                piece_row = 0
                piece_col = 0
            else:
                state = "PLAYING"
        else:
            state = "DONE"
            piece = None
            piece_row = 0
            piece_col = 0

    spawn()

    for cmd in commands:
        if state != "PLAYING" or piece is None:
            continue
        if cmd == "L":
            if fits(piece, piece_state, piece_row, piece_col - 1, board):
                piece_col -= 1
        elif cmd == "R":
            if fits(piece, piece_state, piece_row, piece_col + 1, board):
                piece_col += 1
        elif cmd == "D":
            if fits(piece, piece_state, piece_row + 1, piece_col, board):
                piece_row += 1
                score += 1
            else:
                rows_cleared = lock(board, piece, piece_state, piece, piece_row, piece_col)
                score += CLEAR_POINTS.get(rows_cleared, 0)
                lines_cleared += rows_cleared
        elif cmd == "H":
            max_row = BOARD_ROWS - 1 - max_block_row(piece, piece_state)
            row = piece_row
            while row + 1 <= max_row and fits(piece, piece_state, row + 1, piece_col, board):
                row += 1
            moved = row - piece_row
            piece_row = row
            score += 2 * moved
            lock(board, piece, piece_state, piece, piece_row, piece_col)
            lines_cleared += lock(board, piece, piece_state, piece, piece_row, piece_col)
        elif cmd == "CW":
            piece_state, piece_col = try_rotate(piece, piece_state, board, piece_row, piece_col, (piece_state + 1) % 4)
        elif cmd == "CCW":
            piece_state, piece_col = try_rotate(piece, piece_state, board, piece_row, piece_col, (piece_state + 3) % 4)
        elif cmd == "P":
            for line in print_board(board):
                sys.stdout.write(line + "\n")
        else:
            sys.stderr.write("error: unknown command %s\n" % cmd)

    # End of input prints the board and the state once more.
    for line in print_board(board):
        sys.stdout.write(line + "\n")
    sys.stdout.write("SCORE %d LINES %d %s\n" % (score, lines_cleared, state))


if __name__ == "__main__":
    main()
