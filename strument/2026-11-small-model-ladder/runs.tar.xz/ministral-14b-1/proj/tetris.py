#!/usr/bin/env python3

import sys

# Piece definitions: (r, c) offsets for each state (0-3)
PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)]
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)]
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)]
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)]
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)]
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)]
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)]
    ]
}

class Tetris:
    def __init__(self):
        self.board = [['.' for _ in range(10)] for _ in range(20)]
        self.score = 0
        self.lines_cleared = 0
        self.state = 'PLAYING'
        self.current_piece = None
        self.current_piece_type = None
        self.current_piece_state = 0
        self.current_piece_row = 0
        self.current_piece_col = 3
        self.piece_sequence = []
        self.piece_index = 0

    def spawn_piece(self):
        if self.piece_index >= len(self.piece_sequence):
            self.state = 'DONE'
            return False

        piece_type = self.piece_sequence[self.piece_index]
        self.current_piece_type = piece_type
        self.current_piece_state = 0
        self.current_piece_row = 0
        self.current_piece_col = 3

        if not self.is_valid_position():
            self.state = 'OVER'
            return False

        self.current_piece = PIECES[piece_type][self.current_piece_state]
        self.piece_index += 1
        return True

    def is_valid_position(self, row=None, col=None, state=None):
        if row is None:
            row = self.current_piece_row
        if col is None:
            col = self.current_piece_col
        if state is None:
            state = self.current_piece_state

        piece = PIECES[self.current_piece_type][state]
        for r, c in piece:
            board_row = row + r
            board_col = col + c
            if board_row < 0 or board_row >= 20 or board_col < 0 or board_col >= 10:
                return False
            if self.board[board_row][board_col] != '.':
                return False
        return True

    def move(self, row_offset, col_offset):
        if self.state != 'PLAYING':
            return False

        new_row = self.current_piece_row + row_offset
        new_col = self.current_piece_col + col_offset

        if self.is_valid_position(new_row, new_col):
            self.current_piece_row = new_row
            self.current_piece_col = new_col
            return True
        return False

    def rotate(self, clockwise=True):
        if self.state != 'PLAYING':
            return False

        new_state = (self.current_piece_state + (1 if clockwise else 3)) % 4
        piece = PIECES[self.current_piece_type][new_state]

        # Try rotating at current position
        if self.is_valid_position(state=new_state):
            self.current_piece_state = new_state
            return True

        # Try rotating with column adjustments
        for col_offset in [-1, 1, -2, 2]:
            if self.is_valid_position(self.current_piece_row, self.current_piece_col + col_offset, new_state):
                self.current_piece_col += col_offset
                self.current_piece_state = new_state
                return True

        return False

    def lock_piece(self):
        if self.state != 'PLAYING':
            return False

        # Lock the piece
        for r, c in self.current_piece:
            board_row = self.current_piece_row + r
            board_col = self.current_piece_col + c
            self.board[board_row][board_col] = self.current_piece_type

        # Clear lines and spawn the next piece
        rows_cleared = self.clear_lines()
        return self.spawn_piece()

    def clear_lines(self):
        lines_to_clear = []
        for row in range(20):
            if all(cell != '.' for cell in self.board[row]):
                lines_to_clear.append(row)

        if not lines_to_clear:
            return 0

        lines_to_clear.sort(reverse=True)
        rows_cleared = len(lines_to_clear)

        for row in lines_to_clear:
            del self.board[row]
            self.board.insert(0, ['.' for _ in range(10)])

        self.lines_cleared += rows_cleared
        self.score += [0, 100, 300, 500, 800][min(rows_cleared, 4)]
        return rows_cleared

    def hard_drop(self):
        if self.state != 'PLAYING':
            return False

        rows_moved = 0
        while self.move(1, 0):
            rows_moved += 1

        if rows_moved > 0:
            self.score += 2 * rows_moved
            self.lock_piece()
            return True
        return False

    def print_board(self):
        for row in self.board:
            print(''.join(row))
        print(f"SCORE {self.score} LINES {self.lines_cleared} {self.state}")

    def process_command(self, command):
        if self.state == 'OVER' and command != 'P':
            return
        if self.state == 'DONE' and command != 'P':
            return

        if command == 'L':
            self.move(0, -1)
        elif command == 'R':
            self.move(0, 1)
        elif command == 'D':
            if self.move(1, 0):
                self.score += 1
            else:
                self.lock_piece()
        elif command == 'H':
            self.hard_drop()
        elif command == 'CW':
            self.rotate(True)
        elif command == 'CCW':
            self.rotate(False)
        elif command == 'P':
            self.print_board()
        else:
            print(f"error: unknown command {command}", file=sys.stderr)


def main():
    if len(sys.argv) != 1:
        print("Usage: python3 tetris.py < game.txt", file=sys.stderr)
        sys.exit(1)

    game = Tetris()
    lines = [line.strip() for line in sys.stdin if line.strip()]

    if not lines:
        return

    game.piece_sequence = list(lines[0])
    game.spawn_piece()

    for line in lines[1:]:
        for token in line.split():
            game.process_command(token)

    game.print_board()


if __name__ == "__main__":
    main()