import sys

def main():
    data = sys.stdin.read().split()
    if not data:
        return
    
    piece_seq = data[0]
    commands = data[1:]
    
    # Piece offsets from spec
    offsets = {
        'I': [
            [(1, 0), (1, 1), (1, 2), (1, 3)],
            [(0, 2), (1, 2), (2, 2), (3, 2)],
            [(2, 0), (2, 1), (2, 2), (2, 3)],
            [(0, 1), (1, 1), (2, 1), (3, 1)],
        ],
        'O': [
            [(0, 1), (0, 2), (1, 1), (1, 2)],
            [(0, 1), (0, 2), (1, 1), (1, 2)],
            [(0, 1), (0, 2), (1, 1), (1, 2)],
            [(0, 1), (0, 2), (1, 1), (1, 2)],
        ],
        'T': [
            [(0, 1), (1, 0), (1, 1), (1, 2)],
            [(0, 1), (1, 1), (1, 2), (2, 1)],
            [(1, 0), (1, 1), (1, 2), (2, 1)],
            [(0, 1), (1, 0), (1, 1), (2, 1)],
        ],
        'S': [
            [(0, 1), (0, 2), (1, 0), (1, 1)],
            [(0, 1), (1, 1), (1, 2), (2, 2)],
            [(1, 1), (1, 2), (2, 0), (2, 1)],
            [(0, 0), (1, 0), (1, 1), (2, 1)],
        ],
        'Z': [
            [(0, 0), (0, 1), (1, 1), (1, 2)],
            [(0, 2), (1, 1), (1, 2), (2, 1)],
            [(1, 0), (1, 1), (2, 1), (2, 2)],
            [(0, 1), (1, 0), (1, 1), (2, 0)],
        ],
        'J': [
            [(0, 0), (1, 0), (1, 1), (1, 2)],
            [(0, 1), (0, 2), (1, 1), (2, 1)],
            [(1, 0), (1, 1), (1, 2), (2, 2)],
            [(0, 1), (1, 1), (2, 0), (2, 1)],
        ],
        'L': [
            [(0, 2), (1, 0), (1, 1), (1, 2)],
            [(0, 1), (1, 1), (2, 1), (2, 2)],
            [(1, 0), (1, 1), (1, 2), (2, 0)],
            [(0, 0), (0, 1), (1, 1), (2, 1)],
        ],
    }
    
    board = [['.' for _ in range(10)] for _ in range(20)]
    # current piece: (piece_type, state, row, col) where (row,col) is top-left of box
    current = None
    game_state = "PLAYING"  # PLAYING, OVER, DONE
    
    score = 0
    lines_cleared_last = 0  # rows cleared in the most recent lock
    
    piece_idx = 0  # next piece to spawn
    
    def fits(piece, state, row, col):
        if game_state == "OVER":
            return False
        for (r, c) in offsets[piece][state]:
            br, bc = row + r, col + c
            if br < 0 or br >= 20 or bc < 0 or bc >= 10:
                return False
            if board[br][bc] != '.':
                return False
        return True
    
    def lock_piece():
        nonlocal board, score, lines_cleared_last, current, game_state, piece_idx
        if current is None:
            return
        piece, state, row, col = current
        
        # Place locked cells (uppercase)
        for (r, c) in offsets[piece][state]:
            br, bc = row + r, col + c
            board[br][bc] = piece.upper()
        
        # Find full rows (all 10 cells are letters, i.e., not '.')
        full_rows = []
        for r in range(20):
            if all(board[r][c] != '.' for c in range(10)):
                full_rows.append(r)
        full_rows.sort(reverse=True)  # bottom to top
        
        rows_cleared = len(full_rows)
        if rows_cleared > 0:
            # Score points
            if rows_cleared == 1:
                score += 100
            elif rows_cleared == 2:
                score += 300
            elif rows_cleared == 3:
                score += 500
            elif rows_cleared == 4:
                score += 800
            lines_cleared_last = rows_cleared
        
        # Rebuild board: remove full rows, shift above rows down, insert empty rows at top
        kept = [r for r in range(20) if r not in full_rows]
        new_board = [['.' for _ in range(10)] for _ in range(20)]
        for i, r in enumerate(kept):
            for c in range(10):
                new_board[i][c] = board[r][c]
        board = new_board
        
        # Remove current piece from current
        current = None
        
        # Spawn next piece if any
        if piece_idx < len(piece_seq):
            piece_next = piece_seq[piece_idx]
            piece_idx += 1
            if not fits(piece_next, 0, 0, 3):
                game_state = "OVER"
            else:
                current = (piece_next, 0, 0, 3)
        else:
            game_state = "DONE"
    
    # Spawn first piece
    if piece_seq:
        piece_first = piece_seq[0]
        if not fits(piece_first, 0, 0, 3):
            game_state = "OVER"
            current = None
        else:
            current = (piece_first, 0, 0, 3)
            piece_idx = 1
    
    def print_board():
        # Display board with current piece lowercase
        display = [row[:] for row in board]  # copy
        if current is not None:
            piece, state, row, col = current
            for (r, c) in offsets[piece][state]:
                br, bc = row + r, col + c
                if 0 <= br < 20 and 0 <= bc < 10:
                    # Only show lowercase if that cell is empty (board '.'), else keep locked uppercase
                    if display[br][bc] == '.':
                        display[br][bc] = piece.lower()
        for r in range(20):
            print(''.join(display[r]))
    
    # Process commands in order; handle P outputs immediately
    for cmd in commands:
        if cmd == 'P':
            print_board()
            # State for output:
            if game_state == "OVER":
                state_str = "OVER"
            elif game_state == "DONE":
                state_str = "DONE"
            else:  # PLAYING or still PLAYING
                state_str = "PLAYING"
            # LINES should be lines_cleared_last (rows cleared in last lock)
            print(f"SCORE {score} LINES {lines_cleared_last} {state_str}")
            continue
        
        if game_state == "OVER" or current is None:
            # Ignore command except P already handled
            continue
        
        piece, state, row, col = current
        
        if cmd == 'L':
            if fits(piece, state, row, col - 1):
                current = (piece, state, row, col - 1)
        elif cmd == 'R':
            if fits(piece, state, row, col + 1):
                current = (piece, state, row, col + 1)
        elif cmd == 'D':
            if fits(piece, state, row + 1, col):
                current = (piece, state, row + 1, col)
                score += 1
            else:
                lock_piece()
        elif cmd == 'H':
            # Find max dr >=1 such that piece fits at (row+dr, col)
            max_dr = 0
            for dr in range(1, 21):
                if fits(piece, state, row + dr, col):
                    max_dr = dr
                else:
                    break
            # Move piece down by max_dr
            current = (piece, state, row + max_dr, col)
            # Add 2 points per row moved
            for dr in range(1, max_dr + 1):
                score += 2
            lock_piece()
        elif cmd == 'CW':
            new_state = (state + 1) % 4
            # Try positions in order: (row, col), (row, col-1), (row, col+1), (row, col-2), (row, col+2)
            candidates = [(row, col)] + [(row, col-1), (row, col+1), (row, col-2), (row, col+2)]
            taken = False
            for cr, cc in candidates:
                if fits(piece, new_state, cr, cc):
                    current = (piece, new_state, cr, cc)
                    taken = True
                    break
            # If none fits, nothing happens
        elif cmd == 'CCW':
            new_state = (state + 3) % 4
            candidates = [(row, col)] + [(row, col-1), (row, col+1), (row, col-2), (row, col+2)]
            taken = False
            for cr, cc in candidates:
                if fits(piece, new_state, cr, cc):
                    current = (piece, new_state, cr, cc)
                    taken = True
                    break
        else:
            # Unknown command
            print(f"error: unknown command {cmd}", file=sys.stderr)
    
    # Final print after all commands
    print_board()
    if game_state == "OVER":
        state_str = "OVER"
    elif game_state == "DONE":
        state_str = "DONE"
    else:
        state_str = "PLAYING"
    print(f"SCORE {score} LINES {lines_cleared_last} {state_str}")

if __name__ == "__main__":
    main()