#!/usr/bin/env python3
"""Headless Tetris per SPEC.md"""

import sys

ROWS = 20
COLS = 10

PIECE_BLOCKS = {
    'I': [
        [(1,0), (1,1), (1,2), (1,3)],  # state 0
        [(0,2), (1,2), (2,2), (3,2)], # state 1
        [(2,0), (2,1), (2,2), (2,3)], # state 2
        [(0,1), (1,1), (2,1), (3,1)]  # state 3
    ],
    'O': [
        [(0,1), (0,2), (1,1), (1,2)],
        [(0,1), (0,2), (1,1), (1,2)],
        [(0,1), (0,2), (1,1), (1,2)],
        [(0,1), (0,2), (1,1), (1,2)]
    ],
    'T': [
        [(0,1), (1,0), (1,1), (1,2)],  # state 0
        [(0,1), (1,1), (1,2), (2,1)], # state 1
        [(1,0), (1,1), (1,2), (2,1)], # state 2
        [(0,1), (1,0), (1,1), (2,1)]  # state 3
    ],
    'S': [
        [(0,1), (0,2), (1,0), (1,1)], # state 0
        [(0,1), (1,1), (1,2), (2,2)], # state 1
        [(1,1), (1,2), (2,0), (2,1)], # state 2
        [(0,0), (1,0), (1,1), (2,1)]  # state 3
    ],
    'Z': [
        [(0,0), (0,1), (1,1), (1,2)], # state 0
        [(0,2), (1,1), (1,2), (2,1)], # state 1
        [(1,0), (1,1), (2,1), (2,2)], # state 2
        [(0,1), (1,0), (1,1), (2,0)]  # state 3
    ],
    'J': [
        [(0,0), (1,0), (1,1), (1,2)], # state 0
        [(0,1), (0,2), (1,1), (2,1)], # state 1
        [(1,0), (1,1), (1,2), (2,2)], # state 2
        [(0,1), (1,1), (2,0), (2,1)]  # state 3
    ],
    'L': [
        [(0,2), (1,0), (1,1), (1,2)], # state 0
        [(0,1), (1,1), (2,1), (2,2)], # state 1
        [(1,0), (1,1), (1,2), (2,0)], # state 2
        [(0,0), (0,1), (1,1), (2,1)]  # state 3
    ]
}

def fits(locked, letter, state_idx, row, col):
    blocks = PIECE_BLOCKS[letter][state_idx]
    for dr, dc in blocks:
        r = row + dr
        c = col + dc
        if r < 0 or r >= ROWS or c < 0 or c >= COLS:
            return False
        if (r, c) in locked:
            return False
    return True

def render_board(locked, current):
    board = [['.' for _ in range(COLS)] for _ in range(ROWS)]
    for (r, c), letter in locked.items():
        board[r][c] = letter
    if current is not None:
        letter, state_idx, row, col = current
        blocks = PIECE_BLOCKS[letter][state_idx]
        for dr, dc in blocks:
            r = row + dr
            c = col + dc
            if 0 <= r < ROWS and 0 <= c < COLS:
                board[r][c] = letter.lower()
    return [''.join(row) for row in board]

def score_for_rows(rows_removed):
    if rows_removed == 1:
        return 100
    if rows_removed == 2:
        return 300
    if rows_removed == 3:
        return 500
    return 800  # rows_removed == 4

def find_full_rows(locked):
    full = set()
    for r in range(ROWS):
        full_row = True
        for c in range(COLS):
            if (r, c) not in locked:
                full_row = False
                break
        if full_row:
            full.add(r)
    return full

def clear_rows(locked, full_rows):
    full_set = set(full_rows)
    full_list = sorted(full_rows)
    new_locked = {}
    for r in range(ROWS):
        if r in full_set:
            continue
        cnt_less = 0
        for fr in full_list:
            if fr < r:
                cnt_less += 1
            else:
                break
        for c in range(COLS):
            if (r, c) in locked:
                new_r = r - cnt_less
                new_locked[(new_r, c)] = locked[(r, c)]
    rows_removed = len(full_rows)
    return new_locked, rows_removed

def spawn_piece(locked, piece_list):
    if not piece_list:
        return locked, None, 'DONE', []
    letter = piece_list[0]
    piece_list = piece_list[1:]
    if fits(locked, letter, 0, 0, 3):
        current = (letter, 0, 0, 3)
        return locked, current, 'PLAYING', piece_list
    else:
        return locked, None, 'OVER', piece_list

def lock_piece(locked, current, piece_list, score, lines_cleared):
    if current is None:
        return locked, None, 'DONE', score, lines_cleared, piece_list
    
    letter, state_idx, row, col = current
    blocks = PIECE_BLOCKS[letter][state_idx]
    new_locked = locked.copy()
    for dr, dc in blocks:
        r = row + dr
        c = col + dc
        if 0 <= r < ROWS and 0 <= c < COLS:
            new_locked[(r, c)] = letter
    
    full_rows = find_full_rows(new_locked)
    if full_rows:
        new_locked, rows_removed = clear_rows(new_locked, full_rows)
        points = score_for_rows(rows_removed)
        score += points
        lines_cleared += rows_removed
    
    if piece_list:
        locked, current, game_state, piece_list = spawn_piece(new_locked, piece_list)
        # game_state will be 'PLAYING' or 'OVER'
    else:
        current = None
        game_state = 'DONE'
    return new_locked, current, game_state, score, lines_cleared, piece_list

def rotate_piece(locked, letter, state_idx, row, col, cw):
    if cw:
        target_state = (state_idx + 1) % 4
    else:
        target_state = (state_idx + 3) % 4
    
    candidates = [
        (target_state, row, col),
        (target_state, row, col - 1),
        (target_state, row, col + 1),
        (target_state, row, col - 2),
        (target_state, row, col + 2),
    ]
    
    for state_c, row_c, col_c in candidates:
        if fits(locked, letter, state_c, row_c, col_c):
            return state_c, row_c, col_c
    return None, None, None

def main():
    data = sys.stdin.read().strip().splitlines()
    if not data:
        return
    
    piece_seq = data[0].strip()
    commands = []
    for line in data[1:]:
        for tok in line.split():
            commands.append(tok)
    
    locked = {}
    current = None
    piece_list = list(piece_seq)
    game_state = 'PLAYING'
    score = 0
    lines_cleared = 0
    
    locked, current, game_state, piece_list = spawn_piece(locked, piece_list)
    
    for cmd in commands:
        if game_state == 'OVER' or game_state == 'DONE':
            if cmd != 'P':
                sys.stderr.write(f"error: unknown command {cmd}\n")
            continue
        
        if cmd == 'P':
            board_lines = render_board(locked, current)
            state_word = 'PLAYING' if current is not None else game_state
            score_line = f"SCORE {score} LINES {lines_cleared} {state_word}"
            for line in board_lines:
                sys.stdout.write(line + '\n')
            sys.stdout.write(score_line + '\n')
            continue
        
        if game_state == 'OVER':
            if cmd != 'P':
                sys.stderr.write(f"error: unknown command {cmd}\n")
            continue
        
        if cmd in ('L', 'R', 'CW', 'CCW', 'P'):
            if current is None:
                continue
            letter, state_idx, row, col = current
            if cmd in ('CW', 'CCW'):
                cw = (cmd == 'CW')
                ns, nr, nc = rotate_piece(locked, letter, state_idx, row, col, cw)
                if ns is not None:
                    current = (letter, ns, nr, nc)
            elif cmd == 'L':
                if fits(locked, letter, state_idx, row, col - 1):
                    current = (letter, state_idx, row, col - 1)
            elif cmd == 'R':
                if fits(locked, letter, state_idx, row, col + 1):
                    current = (letter, state_idx, row, col + 1)
        elif cmd in ('D', 'H'):
            if current is None:
                continue
            letter, state_idx, row, col = current
            if cmd == 'D':
                if fits(locked, letter, state_idx, row + 1, col):
                    current = (letter, state_idx, row + 1, col)
                    score += 1  # add 1 point for D command
                else:
                    # Lock immediately (no score for D)
                    locked, current, game_state, score, lines_cleared, piece_list = lock_piece(locked, current, piece_list, score, lines_cleared)
            else:  # H
                max_drop = 0
                for dr in range(1, ROWS):
                    if fits(locked, letter, state_idx, row + dr, col):
                        max_drop = dr
                    else:
                        break
                if max_drop == 0:
                    # Already at bottom, lock immediately
                    locked, current, game_state, score, lines_cleared, piece_list = lock_piece(locked, current, piece_list, score, lines_cleared)
                else:
                    # Hard drop: move to row + max_drop, then lock with +2 per row
                    current = (letter, state_idx, row + max_drop, col)
                    # Lock immediately after hard drop
                    locked, current, game_state, score, lines_cleared, piece_list = lock_piece(locked, current, piece_list, score, lines_cleared)
                    score += 2 * max_drop
        else:
            sys.stderr.write(f"error: unknown command {cmd}\n")
    
    # Final print
    board_lines = render_board(locked, current)
    state_word = game_state
    score_line = f"SCORE {score} LINES {lines_cleared} {state_word}"
    for line in board_lines:
        sys.stdout.write(line + '\n')
    sys.stdout.write(score_line + '\n')

if __name__ == '__main__':
    main()
