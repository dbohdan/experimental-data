#!/usr/bin/env python3

import sys

# Define the piece shapes for each type and rotation state
PIECE_SHAPES = {
    'I': [
        {(1, 0), (1, 1), (1, 2), (1, 3)},  # State 0
        {(0, 2), (1, 2), (2, 2), (3, 2)},  # State 1
        {(2, 0), (2, 1), (2, 2), (2, 3)},  # State 2
        {(0, 1), (1, 1), (2, 1), (3, 1)},  # State 3
    ],
    'O': [
        {(0, 1), (0, 2), (1, 1), (1, 2)},  # All states are the same
        {(0, 1), (0, 2), (1, 1), (1, 2)},
        {(0, 1), (0, 2), (1, 1), (1, 2)},
        {(0, 1), (0, 2), (1, 1), (1, 2)},
    ],
    'T': [
        {(0, 1), (1, 0), (1, 1), (1, 2)},  # State 0
        {(0, 1), (1, 1), (1, 2), (2, 1)},  # State 1
        {(1, 0), (1, 1), (1, 2), (2, 1)},  # State 2
        {(0, 1), (1, 0), (1, 1), (2, 1)},  # State 3
    ],
    'S': [
        {(0, 1), (0, 2), (1, 0), (1, 1)},  # State 0
        {(0, 1), (1, 1), (1, 2), (2, 2)},  # State 1
        {(1, 1), (1, 2), (2, 0), (2, 1)},  # State 2
        {(0, 0), (1, 0), (1, 1), (2, 1)},  # State 3
    ],
    'Z': [
        {(0, 0), (0, 1), (1, 1), (1, 2)},  # State 0
        {(0, 2), (1, 1), (1, 2), (2, 1)},  # State 1
        {(1, 0), (1, 1), (2, 1), (2, 2)},  # State 2
        {(0, 1), (1, 0), (1, 1), (2, 0)},  # State 3
    ],
    'J': [
        {(0, 0), (1, 0), (1, 1), (1, 2)},  # State 0
        {(0, 1), (0, 2), (1, 1), (2, 1)},  # State 1
        {(1, 0), (1, 1), (1, 2), (2, 2)},  # State 2
        {(0, 1), (1, 1), (2, 0), (2, 1)},  # State 3
    ],
    'L': [
        {(0, 2), (1, 0), (1, 1), (1, 2)},  # State 0
        {(0, 1), (1, 1), (2, 1), (2, 2)},  # State 1
        {(1, 0), (1, 1), (1, 2), (2, 0)},  # State 2
        {(0, 0), (0, 1), (1, 1), (2, 1)},  # State 3
    ],
}

class TetrisGame:
    def __init__(self):
        self.board = [['.' for _ in range(10)] for _ in range(20)]
        self.score = 0
        self.lines_cleared = 0
        self.game_state = 'PLAYING'
        self.current_piece = None
        self.current_piece_type = None
        self.current_piece_state = 0
        self.current_piece_position = (0, 3)
        self.piece_sequence = []
        self.next_piece_index = 0

    def spawn_piece(self, piece_type):
        if self.game_state != 'PLAYING':
            return False
        self.current_piece_type = piece_type
        self.current_piece_state = 0
        self.current_piece_position = (0, 3)
        if not self._can_spawn_piece():
            self.game_state = 'OVER'
            return False
        return True

    def _can_spawn_piece(self):
        shape = PIECE_SHAPES[self.current_piece_type][self.current_piece_state]
        row, col = self.current_piece_position
        for offset_row, offset_col in shape:
            board_row, board_col = row + offset_row, col + offset_col
            if board_row >= 20 or board_col < 0 or board_col >= 10 or self.board[board_row][board_col] != '.':
                return False
        return True

    def _can_move_piece(self, row_offset, col_offset):
        if self.current_piece is None:
            return False
        shape = PIECE_SHAPES[self.current_piece_type][self.current_piece_state]
        row, col = self.current_piece_position
        for offset_row, offset_col in shape:
            board_row, board_col = row + offset_row + row_offset, col + offset_col + col_offset
            if board_row >= 20 or board_col < 0 or board_col >= 10:
                return False
            if self.board[board_row][board_col] != '.':
                return False
        return True

    def _can_rotate_piece(self, new_state):
        if self.current_piece is None:
            return False
        shape = PIECE_SHAPES[self.current_piece_type][new_state]
        row, col = self.current_piece_position
        for offset_row, offset_col in shape:
            board_row, board_col = row + offset_row, col + offset_col
            if board_row >= 20 or board_col < 0 or board_col >= 10:
                return False
            if self.board[board_row][board_col] != '.':
                return False
        return True

    def _try_rotate(self, new_state):
        # Try the new state at current position
        if self._can_rotate_piece(new_state):
            self.current_piece_state = new_state
            return True
        
        # Try shifting left by 1, 2, etc.
        for shift in [-1, 1, -2, 2]:
            if self._can_move_piece(0, shift):
                self.current_piece_position = (self.current_piece_position[0], self.current_piece_position[1] + shift)
                if self._can_rotate_piece(new_state):
                    self.current_piece_state = new_state
                    return True
                self.current_piece_position = (self.current_piece_position[0], self.current_piece_position[1] - shift)
        return False
        
    def _can_rotate_piece(self, new_state):
        shape = PIECE_SHAPES[self.current_piece_type][new_state]
        row, col = self.current_piece_position
        for offset_row, offset_col in shape:
            board_row, board_col = row + offset_row, col + offset_col
            if board_row >= 20 or board_col < 0 or board_col >= 10 or self.board[board_row][board_col] != '.':
                return False
        return True

    def lock_piece(self):
        if self.current_piece is None:
            return
        shape = PIECE_SHAPES[self.current_piece_type][self.current_piece_state]
        row, col = self.current_piece_position
        for offset_row, offset_col in shape:
            board_row, board_col = row + offset_row, col + offset_col
            if board_row < 20 and board_col >= 0 and board_col < 10:
                self.board[board_row][board_col] = self.current_piece_type

        self._clear_lines()
        self.current_piece = None
        if self.next_piece_index >= len(self.piece_sequence):
            self.game_state = 'DONE'
        else:
            self.game_state = 'PLAYING'

    def _clear_lines(self):
        lines_to_clear = []
        for i, row in enumerate(self.board):
            if all(cell != '.' for cell in row):
                lines_to_clear.append(i)
        
        if lines_to_clear:
            # Remove cleared lines
            for line in sorted(lines_to_clear, reverse=True):
                del self.board[line]
                self.board.insert(0, ['.' for _ in range(10)])
            
            # Update score and lines cleared
            self.lines_cleared += len(lines_to_clear)
            if len(lines_to_clear) == 1:
                self.score += 100
            elif len(lines_to_clear) == 2:
                self.score += 300
            elif len(lines_to_clear) == 3:
                self.score += 500
            elif len(lines_to_clear) == 4:
                self.score += 800
            print(f"Cleared {len(lines_to_clear)} lines, score: {self.score}, lines cleared: {self.lines_cleared}")

    def handle_command(self, command):
        if self.game_state != 'PLAYING' and command not in ['P']:
            return
        
        if command == 'L':
            if self._can_move_piece(0, -1):
                self.current_piece_position = (self.current_piece_position[0], self.current_piece_position[1] - 1)
        elif command == 'R':
            if self._can_move_piece(0, 1):
                self.current_piece_position = (self.current_piece_position[0], self.current_piece_position[1] + 1)
        elif command == 'D':
            if self._can_move_piece(1, 0):
                self.current_piece_position = (self.current_piece_position[0] + 1, self.current_piece_position[1])
                self.score += 1
            else:
                self.lock_piece()
        elif command == 'H':
            rows_moved = 0
            while self._can_move_piece(1, 0):
                self.current_piece_position = (self.current_piece_position[0] + 1, self.current_piece_position[1])
                rows_moved += 1
            self.score += 2 * rows_moved
            self.lock_piece()
        elif command == 'CW':
            new_state = (self.current_piece_state + 1) % 4
            if self._try_rotate(new_state):
                pass
        elif command == 'CCW':
            new_state = (self.current_piece_state + 3) % 4
            if self._try_rotate(new_state):
                pass
        elif command == 'P':
            self.print_board()

    def print_board(self):
        for row in self.board:
            print(''.join(row))
        print(f"SCORE {self.score} LINES {self.lines_cleared} {self.game_state}")

    def run(self, input_lines):
        # Parse input
        if not input_lines:
            return
        self.piece_sequence = input_lines[0].strip()
        commands = []
        for line in input_lines[1:]:
            commands.extend(line.strip().split())

        # Spawn first piece
        if self.piece_sequence:
            self.spawn_piece(self.piece_sequence[0])

        # Process commands
        for cmd in commands:
            if cmd == 'P':
                self.print_board()
            elif self.game_state == 'PLAYING':
                self.handle_command(cmd)
                if self.current_piece is None:
                    if self.next_piece_index < len(self.piece_sequence):
                        self.spawn_piece(self.piece_sequence[self.next_piece_index])
                        self.next_piece_index += 1
                    else:
                        self.game_state = 'DONE'

        # Print final board
        self.print_board()

def main():
    import sys
    input_lines = [line.strip() for line in sys.stdin if line.strip()]
    game = TetrisGame()
    game.run(input_lines)

if __name__ == '__main__':
    main()