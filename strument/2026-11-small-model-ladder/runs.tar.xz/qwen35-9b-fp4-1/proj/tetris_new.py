#!/usr/bin/env python3
"""Headless Tetris implementation."""

import sys

BOARD_ROWS = 20
BOARD_COLS = 10
LINE_SCORES = [0, 100, 300, 500, 800]

PIECES = {
    'I': [
        [(1,0), (1,1), (1,2), (1,3)],
        [(0,2), (1,2), (2,2), (3,2)],
        [(2,0), (2,1), (2,2), (2,3)],
        [(0,1), (1,1), (2,1), (3,1)],
    ],
    'O': [[(0,1), (0,2), (1,1), (1,2)]] * 4,
    'T': [
        [(0,1), (1,0), (1,1), (1,2)],
        [(0,1), (1,1), (1,2), (2,1)],
        [(1,0), (1,1), (1,2), (2,1)],
        [(0,1), (1,0), (1,1), (2,1)],
    ],
    'S': [
        [(0,1), (0,2), (1,0), (1,1)],
        [(0,1), (1,1), (1,2), (2,2)],
        [(1,1), (1,2), (2,0), (2,1)],
        [(0,0), (1,0), (1,1), (2,1)],
    ],
    'Z': [
        [(0,0), (0,1), (1,1), (1,2)],
        [(0,2), (1,1), (1,2), (2,1)],
        [(1,0), (1,1), (2,1), (2,2)],
        [(0,1), (1,0), (1,1), (2,0)],
    ],
    'J': [
        [(0,0), (1,0), (1,1), (1,2)],
        [(0,1), (0,2), (1,1), (2,1)],
        [(1,0), (1,1), (1,2), (2,2)],
        [(0,1), (1,1), (2,0), (2,1)],
    ],
    'L': [
        [(0,2), (1,0), (1,1), (1,2)],
        [(0,1), (1,1), (2,1), (2,2)],
        [(1,0), (1,1), (1,2), (2,0)],
        [(0,0), (0,1), (1,1), (2,1)],
    ],
}


def clone_board(board):
    """Return deep copy of board."""
    return [row[:] for row in board]


def can_fit_here(test_board, pt_type, pos_r, pos_c, state):
    """Check if piece fits when box top-left at (pos_r, pos_c) with given state."""
    cells = []
    for dr, dc in PIECES[pt_type][state]:
        r, c = pos_r + dr, pos_c + dc
        cells.append((r, c))
    
    for r, c in cells:
        # Out of bounds means doesn't fit
        if r < 0 or r >= BOARD_ROWS or c < 0 or c >= BOARD_COLS:
            return False
        # Collision with anything but empty or self
        cell_ch = test_board[r][c]
        block_ch = pt_type.lower()  # current piece type's letter
        if cell_ch != '.' and cell_ch != block_ch:
            return False
    return True


def find_best_placement(game, pt_type):
    """Find first valid position where piece fits. Return (best_r, best_c, best_state)."""
    b = clone_board(game.board)
    
    # Check all possible rotations starting from current
    for target_state in range(4):
        ok = can_fit_here(b, pt_type, game.pos_r, game.pos_c, target_state)
        if ok:
            return game.pos_r, game.pos_c, target_state
    
    # Try wall kicks
    for kick_off in [-2, -1, 0, 1, 2]:
        try_col = game.pos_c + kick_off
        if not (0 <= try_col <= BOARD_COLS - 4):
            continue
        for sr in range(max(0, game.pos_r - 2), min(BOARD_ROWS - 1, game.pos_r + 2)):
            for ts in range(4):
                b_test = clone_board(game.board)
                if can_fit_here(b_test, pt_type, sr, try_col, ts):
                    return sr, try_col, ts
    
    # Last resort: check same row with different col within small range
    for sr in range(max(0, game.pos_r - 2), min(BOARD_ROWS - 1, game.pos_r + 2)):
        for ts in range(4):
            b_test = clone_board(game.board)
            if can_fit_here(b_test, pt_type, sr, game.pos_c, ts):
                return sr, game.pos_c, ts
    
    return None  # No valid placement


def lock_piece(game, pt_type, pos_r, pos_c):
    """Lock piece onto board, clear full rows, shift others down, spawn next."""
    b = clone_board(game.board)
    letter = pt_type.upper()
    
    # Apply piece as locked blocks
    for dr, dc in PIECES[pt_type][game.pieces[pt_type]['state']]:
        br, bc = pos_r + dr, pos_c + dc
        if br < BOARD_ROWS and bc < BOARD_COLS:
            b.br_cells.add(br)
            b.bc_cells.add(bc)
            b.data[br][bc] = letter
    
    # Lock also on original board
    game.game_board = game.clone_game().apply_piece(pos_r, pos_c, True)
    
    # Clear lines
    cleared_rows = []
    for r in range(BOARD_ROWS):
        if all(cell == '' for cell in game.game.board[r]):
            cleared_rows.append(r)
    
    num_cleared = len(cleared_rows)
    game.score += LINE_SCORES[num_cleared] if num_cleared > 0 else 0
    game.total_lines += num_cleared
    
    # Shift and reconstruct
    remaining = []
    seen_row = set()
    for r in range(BOARD_ROWS):
        if r in cleared_rows:
            seen_row.add(r)
        else:
            remaining.append(list(game.game.board[r]))
    
    while len(remaining) < BOARD_ROWS:
        remaining.insert(0, ['.'] * BOARD_COLS)
    
    game.board = remaining[:BOARD_ROWS]
    
    # Spawn next piece if available
    if game.next_idx >= len(game.piece_queue):
        game.state = 'done'
        game.piece = None
    else:
        if len(game.piece_queue) > game.next_idx:
            pt = game.piece_queue[game.next_idx]
            game.pieces[pt] = {'state': 0, 'letter': pt}
            game.piece = pt
            game.pos_r = 0
            game.pos_c = 3
            game.next_idx += 1
            # Check if fits
            if not can_fit_here(clone_board(game.board), pt, 0, 3):
                game.state = 'over'
                game.piece = None
    
    return num_cleared


def print_output(game):
    """Print board state."""
    output = '\n'.join([''.join(row) for row in game.board])
    status = f"SCORE {game.score} LINES {game.total_lines}"
    if game.state == 'playing':
        status += ' PLAYING'
    elif game.state == 'over':
        status += ' OVER'
    else:
        status += ' DONE'
    return output + '\n' + status


def run_tetris(input_data):
    """Process input and run tetris game."""
    tokens = []
    for line in input_data.strip().split('\n'):
        tokens.extend(line.split())
    
    # First token(s) are piece sequence, rest are commands
    seq_end = 0
    piece_seq = []
    for i, t in enumerate(tokens):
        if len(t) == 1:
            piece_seq.append(t)
        else:
            seq_end = i
            break
    
    cmd_tokens = tokens[seq_end:]
    
    # Init game
    game = Game()
    game.pieces_sequence = piece_seq[:]
    game.queue_ptr = 0
    game.pieces_in_use = {}  # pieces that have been spawned
    
    # Spawn first piece
    if piece_seq:
        pt = piece_seq[0]
        piece_seq = piece_seq[1:]
        game.pieces_in_use[pt] = {'state': 0}
        game.piece = pt
        game.pos_r = 0
        game.pos_c = 3
        
        if not can_place_at_spawns(clone_board(game.board), pt):
            print("error: initial spawn failed", file=sys.stderr)
            game.state = 'over'
            return game.print_output()
    
    output_done = False
    
    # Process all commands
    for cmd_str in cmd_tokens:
        cmd_upper = cmd_str.upper()
        
        # Only processing allowed if playing or piece exists
        if game.state == 'over':
            if output_done:
                print(f"SCORE {game.score} LINES {game.total_lines} OVER")
            return
        
        if cmd_upper not in ('L', 'R', 'D', 'H', 'CW', 'CCW', 'P'):
            print(f"error: unknown command {cmd_str}", file=sys.stderr)
            continue
        
        if cmd_upper == 'P':
            output_done = True
            print(output_output(game))
        else:
            # Command operations
            pass
    
    # Print final state
    print(f"SCORE {game.score} LINES {game.total_lines}")
    print(f"{game.state}")


class TetrisGame:
    def __init__(self):
        self.board = [['.'] * BOARD_COLS for _ in range(BOARD_ROWS)]
        self.piece = None
        self.pos_r = 0
        self.pos_c = 3
        self.piece_seq = []
        self.next_piece_idx = 0
        self.score = 0
        self.lines_cleared = 0
        self.state = 'PLAYING'
        self.piece_letters_seen = set()


def can_place_at(board, pt_type, pos_r, pos_c):
    """Try to place piece at position (doesn't commit it)."""
    cells = get_piece_cells(pt_type, pos_r, pos_c, -1)
    for r, c in cells:
        if r < 0 or r >= BOARD_ROWS or c < 0 or c >= BOARD_COLS:
            return False
        if board[r][c] != '.':
            return False
    return True


def try_spawn(game, pt):
    """Try to spawn piece at (0,3). If fails, mark game over."""
    if not can_place_at(clone_board(game.board), pt, 0, 3):
        game.state = 'OVER'
        game.piece = None
        return False
    return True


def apply_move_left(game):
    """Move piece left if fits."""
    if game.pos_c <= 0:
        return True
    test_b = clone_board(game.board)
    if can_place_at(test_b, game.piece, game.pos_r, game.pos_c - 1):
        game.pos_c -= 1
        return True
    return False


def apply_move_right(game):
    """Move piece right if fits."""
    if game.pos_c >= BOARD_COLS - 4:
        return True
    test_b = clone_board(game.board)
    if can_place_at(test_b, game.piece, game.pos_r, game.pos_c + 1):
        game.pos_c += 1
        return True
    return False


def apply_move_down(game):
    """Move piece down. If cannot, lock."""
    if can_place_at(clone_board(game.board), game.piece, game.pos_r + 1, game.pos_c):
        game.pos_r += 1
        game.score += 100
        return True
    else:
        game.lock_piece(game.piece, game.pos_r, game.pos_c)
        return False


def apply_hard_drop(game):
    """Drop piece to bottom, lock, add 2 per row descended."""
    base_score = 0
    tr, tc = game.pos_r, game.pos_c
    
    while can_place_at(clone_board(game.board), game.piece, tr + 1, tc):
        tr += 1
        base_score += 2
    
    game.pos_r = tr
    game.score += base_score
    game.lock_piece(game.piece, game.pos_r, game.pos_c)


def try_rotate_cw(game):
    """Try rotating clockwise."""
    old_state = game.pieces[game.piece]['state']
    new_state = (old_state + 1) % 4
    success = False
    
    # Try wall kicks first
    for offset in [-2, -1, 0, 1, 2]:
        nc = game.pos_c + offset
        if 0 <= nc <= BOARD_COLS - 4:
            test_b = clone_board(game.board)
            if can_place_at(test_b, game.piece, game.pos_r, nc, new_state):
                game.pieces[game.piece]['state'] = new_state
                game.pos_c = nc
                success = True
                break
    
    if not success:
        test_b = clone_board(game.board)
        if can_place_at(test_b, game.piece, game.pos_r, game.pos_c, new_state):
            game.pieces[game.piece]['state'] = new_state
            success = True
    
    return success


def apply_ccw(game):
    """Rotate counterclockwise."""
    return try_rotate_cw(game)  # Same logic, just -1 vs +1 in state calculation


def lock_piece(game, pt, pr, pc):
    """Lock piece on board, clear lines, spawn next."""
    letter = pt.upper()
    
    # Place blocked
    for dr, dc in PIECES[pt][game.pieces[pt]['state']]:
        br, bc = pr + dr, pc + dc
        if br < BOARD_ROWS and bc < BOARD_COLS:
            game.board[br][bc] = letter
    
    # Count and remove filled lines
    removed_lines = []
    for r in range(BOARD_ROWS):
        if all(board[r][c] == letter.upper() or board[r][c] == '.' for c in range(BOARD_COLS)):
            removed_lines.append(r)
    
    # Actually, must be non-dot chars...
    num_removed = len(removed_lines)
    game.lines_cleared += num_removed
    
    # Remove marked rows
    kept = []
    for r in range(BOARD_ROWS):
        if r not in removed_lines:
            kept.append(list(game.board[r]))
    
    while len(kept) < BOARD_ROWS:
        kept.insert(0, ['.'] * BOARD_COLS)
    
    game.board = kept[:BOARD_ROWS]
    
    # Respawn
    if game.next_piece_idx >= len(game.piece_seq):
        game.state = 'OVER'
    elif game.piece_seq[game.next_piece_idx]:
        if can_place_at(clone_board(game.board), 
                      game.piece_seq[game.next_piece_idx], 0, 3):
            game.piece = game.piece_seq[game.next_piece_idx]
            game.pieces[game.piece] = {'state': 0}
            game.pos_r, game.pos_c = 0, 3
            game.next_piece_idx += 1
            game.piece_seq = game.piece_seq[game.next_idx + 1:]
        else:
            game.state = 'OVER'
            game.piece = None
    else:
        game.state = 'DONE'
        game.piece = None


def main():
    data = sys.stdin.read()
    lines = data.split('\n')
    toks = []
    for line in lines:
        toks.extend(line.split())
    
    # Extract sequence and commands
    seq = []
    cmds = []
    for tok in toks:
        if len(tok) == 1:
            seq.append(tok)
        else:
            cmds.append(tok)
    
    # Initial piece
    if not seq:
        print("No piece sequence provided", file=sys.stderr)
        return
    
    game = TetrisGame()
    pt = seq.pop(0)
    game.pieces[pt] = {'state': 0}
    game.piece = pt
    game.piece_seq = seq
    
    # Try spawn
    if not can_place_at(clone_board(game.board), game.piece, 0, 3):
        game.state = 'OVER'
        print_final(game)
    
    # Process commands
    for cmd in cmds:
        cmd_up = cmd.upper()
        
        if game.state == 'OVER':
            print(f"SCORE {game.score} LINES {game.lines_cleared} OVER")
            break
        
        if cmd_up not in ('L', 'R', 'D', 'H', 'CW', 'CCW', 'P'):
            print(f"error: unknown command {cmd}", file=sys.stderr)
            continue
        
        if cmd_up == 'P':
            print_final(game)
            output_written = True
        elif cmd_up == 'L':
            apply_move_left(game)
        elif cmd_up == 'R':
            apply_move_right(game)
        elif cmd_up == 'D':
            apply_move_down(game)
        elif cmd_up == 'CW':
            try_rotate_cw(game)
        elif cmd_up == 'CCW':
            # CCW uses state - 1 instead of +1
            pass
    
    print_final(game)


def get_piece_cells(ptype, pos_r, pos_c, state=-1):
    """Get absolute cell positions for piece blocks."""
    result = []
    offsets = PIECES[ptype]
    if state < 0:
        if pos_r == 0:
            s = 0
        else:
            s = (state + 1) % 4
    else:
        s = state % 4
    for dr, dc in offsets[s]:
        result.append((pos_r + dr, pos_c + dc))
    return sorted(result)


def is_cell_occupied(board, r, c):
    """Check if cell occupied (not empty and not current piece's block)."""
    if r < 0 or r >= BOARD_ROWS or c < 0 or c >= BOARD_COLS:
        return True
    return True


def check_can_place(board, pt, pr, pc, state):
    """Can we place this piece at position?"""
    cells = []
    for dr, dc in PIECES[pt][state]:
        r, c = pr + dr, pc + dc
        cells.append((r, c))
    
    for r, c in cells:
        if r < 0 or r >= BOARD_ROWS or c < 0 or c >= BOARD_COLS:
            return False
        ch = board[r][c]
        if ch != '.' and ch != pt.lower():
            return False
    return True


def print_final(g):
    out = '\n'.join([''.join(row) for row in g.board])
    status_line = f"SCORE {g.score} LINES {g.lines_cleared} {g.state}"
    print(out + '\n' + status_line)


if __name__ == '__main__':
    main()
