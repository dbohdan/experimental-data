#!/usr/bin/env python3
"""Headless Tetris implementation per SPEC.md."""

import sys

BOARD_ROWS = 20
BOARD_COLS = 10

# Score: lines cleared at once -> points (index 0 unused)
LINE_SCORES = [0, 100, 300, 500, 800]


# Piece definitions: list of (dr, dc) for states 0-3
PIECES = {
    'I': [
        [(1,0), (1,1), (1,2), (1,3)],  # state 0 - horizontal bar
        [(0,2), (1,2), (2,2), (3,2)],  # state 1 - vertical bar
        [(2,0), (2,1), (2,2), (2,3)],  # state 2 - horizontal bar
        [(0,1), (1,1), (2,1), (3,1)],  # state 3 - vertical bar
    ],
    'O': [[(0,1), (0,2), (1,1), (1,2)]] * 4,  # square - same in all rotations
    'T': [
        [(0,1), (1,0), (1,1), (1,2)],  # state 0 - T pointing up
        [(0,1), (1,1), (1,2), (2,1)],  # state 1 - T pointing right
        [(1,0), (1,1), (1,2), (2,1)],  # state 2 - T pointing down
        [(0,1), (1,0), (1,1), (2,1)],  # state 3 - T pointing left
    ],
    'S': [
        [(0,1), (0,2), (1,0), (1,1)],  # state 0
        [(0,1), (1,1), (1,2), (2,2)],  # state 1
        [(1,1), (1,2), (2,0), (2,1)],  # state 2
        [(0,0), (1,0), (1,1), (2,1)],  # state 3
    ],
    'Z': [
        [(0,0), (0,1), (1,1), (1,2)],  # state 0
        [(0,2), (1,1), (1,2), (2,1)],  # state 1
        [(1,0), (1,1), (2,1), (2,2)],  # state 2
        [(0,1), (1,0), (1,1), (2,0)],  # state 3
    ],
    'J': [
        [(0,0), (1,0), (1,1), (1,2)],  # state 0
        [(0,1), (0,2), (1,1), (2,1)],  # state 1
        [(1,0), (1,1), (1,2), (2,2)],  # state 2
        [(0,1), (1,1), (2,0), (2,1)],  # state 3
    ],
    'L': [
        [(0,2), (1,0), (1,1), (1,2)],  # state 0
        [(0,1), (1,1), (2,1), (2,2)],  # state 1
        [(1,0), (1,1), (1,2), (2,0)],  # state 2
        [(0,0), (0,1), (1,1), (2,1)],  # state 3
    ],
}


class Board:
    """Represents board state for testing."""
    def __init__(self, rows_data):
        self.rows = len(rows_data)
        self.cols = len(rows_data[0]) if rows_data else 0
        self.data = [list(row) for row in rows_data]
    
    def copy(self):
        return Board([row[:] for row in self.data])
    
    def get(self, r, c):
        if r < 0 or r >= self.rows or c < 0 or c >= self.cols:
            return '.'
        return self.data[r][c]
    
    def set(self, r, c, val):
        if 0 <= r < self.rows and 0 <= c < self.cols:
            self.data[r][c] = val


def clone_board(board):
    """Return deep copy of board."""
    return [row[:] for row in board]


def get_cells(ptype, pr, pc, state):
    """Get absolute (r,c) positions for piece blocks."""
    cells = []
    offsets = PIECES[ptype][state]
    for dr, dc in offsets:
        cells.append((pr + dr, pc + dc))
    return sorted(cells)


def check_fit(board, ptype, pr, pc, state):
    """Check if piece would fit if placed with top-left at (pr, pc)."""
    cells = get_cells(ptype, pr, pc, state)
    for r, c in cells:
        cell_ch = board.get(r, c)
        if cell_ch != '.' and cell_ch.lower() != ptype.lower():
            return False
    return True


def find_ghost_pos(game, ptype):
    """Calculate where ghost (will-lock position) is."""
    gr, gc = game.pos_r, game.pos_c
    
    # Move down as far as possible using piece's current state
    while True:
        b_test = clone_board(game.board)
        if check_fit(b_test, ptype, gr + 1, gc, game.piece_state):
            gr += 1
        else:
            break
    
    return gr, gc


def spawn_piece(game, ptype):
    """Spawn new piece. Returns True if successful, False if game over."""
    # Check if fits at spawn position (0, 3) with state 0
    b_test = clone_board(game.board)
    if not check_fit(b_test, ptype, 0, 3, 0):
        return False
    
    # Place on board as lowercase
    for r, c in get_cells(ptype, 0, 3, 0):
        game.board[r][c] = ptype.lower()
    
    # Store piece info
    if ptype not in game.pieces:
        game.pieces[ptype] = {'state': 0, 'letter': ptype}
    
    return True


class Game:
    def __init__(self):
        self.board = [['.'] * BOARD_COLS for _ in range(BOARD_ROWS)]
        self.active_piece = None  # Current piece char or None
        self.piece_state = 0       # State of active piece
        self.pos_r = 0             # Box position row
        self.pos_c = 3             # Box position col
        self.queue = []            # Pieces waiting to be spawned
        self.next_idx = 0          # Next index in queue
        self.score = 0
        self.lines_cleared = 0
        self.state = 'PLAYING'
        self.pieces_sequence = []   # Original sequence string chars


def apply_move_left(game):
    """Move piece left by 1. Return True if moved."""
    if game.pos_c <= 0:
        return True
    b_test = clone_board(game.board)
    if check_fit(b_test, game.active_piece, game.pos_r, game.pos_c - 1):
        game.pos_c -= 1
        return True
    return False


def apply_move_right(game):
    """Move piece right by 1. Return True if moved."""
    if game.pos_c >= BOARD_COLS - 4:
        return True
    b_test = clone_board(game.board)
    if check_fit(b_test, game.active_piece, game.pos_r, game.pos_c + 1):
        game.pos_c += 1
        return True
    return False


def apply_move_down(game):
    """Move piece down by 1. If can't, lock instead."""
    b_test = clone_board(game.board)
    if check_fit(b_test, game.active_piece, game.pos_r + 1, game.pos_c):
        game.pos_r += 1
        game.score += 100
        return True
    else:
        lock_piece(game)
        return False


def hard_drop(game):
    """Drop piece to lowest possible position, add score, then lock."""
    base_score = 0
    tr, tc = game.pos_r, game.pos_c
    
    while True:
        b_test = clone_board(game.board)
        if check_fit(b_test, game.active_piece, tr + 1, tc):
            tr += 1
            base_score += 2
        else:
            break
    
    game.pos_r = tr
    game.score += base_score
    lock_piece(game)


def try_rotate_clockwise(game):
    """Try rotating piece clockwise. Apply if it fits."""
    old_state = game.piece_state
    new_state = (old_state + 1) % 4
    success = False
    
    # Try wall kicks: offset column by -2, -1, 0, +1, +2
    for offset in [-2, -1, 0, 1, 2]:
        try_col = game.pos_c + offset
        if 0 <= try_col <= BOARD_COLS - 4:
            b_test = clone_board(game.board)
            if check_fit(b_test, game.active_piece, game.pos_r, try_col, new_state):
                game.piece_state = new_state
                game.pos_c = try_col
                success = True
                break
    
    # If no kick works, try without changing column
    if not success:
        b_test = clone_board(game.board)
        if check_fit(b_test, game.active_piece, game.pos_r, game.pos_c, new_state):
            game.piece_state = new_state
            success = True
    
    return success


def lock_piece(game):
    """Lock current piece onto board, clear lines, respawn next."""
    pt = game.active_piece
    ps = game.piece_state
    
    # Lock blocks as uppercase
    for r, c in get_cells(pt, game.pos_r, game.pos_c, ps):
        if r < BOARD_ROWS and c < BOARD_COLS:
            game.board[r][c] = pt.upper()
    
    # Clear full lines
    cleared_rows = []
    for r in range(BOARD_ROWS):
        full = True
        for ch in game.board[r]:
            if ch == '.':
                full = False
                break
        if full:
            cleared_rows.append(r)
    
    num_cleared = len(cleared_rows)
    game.score += LINE_SCORES[num_cleared] if num_cleared > 0 else 0
    game.lines_cleared += num_cleared
    
    # Shift rows down, add empty ones at top
    remaining = [row[:] for row in game.board[:BOARD_ROWS - len(cleared_rows)]]
    remaining.extend(['.'] * BOARD_COLS * num_cleared)
    # Rebuild board
    game.board = remaining[:BOARD_ROWS]
    
    # Spawn next piece if available
    if game.next_idx >= len(game.queue):
        game.state = 'DONE'
        game.active_piece = None
    elif game.queue[game.next_idx]:
        pt = game.queue[game.next_idx]
        game.queue[game.next_idx] = None
        result = spawn_piece(game, pt)
        if not result:
            game.state = 'OVER'
            game.active_piece = None
    
    return num_cleared


def print_board_lines(game):
    """Print current board state."""
    return '\n'.join([''.join(row) for row in game.board])


def run_game(input_text):
    """Run tetris game with input text."""
    tokens = []
    for line in input_text.strip().split('\n'):
        tokens.extend(line.split())
    
    if not tokens:
        print("error: no input", file=sys.stderr)
        return
    
    # Separate piece sequence from commands
    piece_tokens = []
    cmd_tokens = []
    
    in_cmd = False
    for tok in tokens:
        if len(tok) == 1:
            piece_tokens.append(tok)
        else:
            in_cmd = True
            cmd_tokens.append(tok)
    
    # Build piece sequence list
    piece_seq_list = list(piece_tokens)
    
    # Init game
    game = Game()
    game.pieces_sequence = piece_tokens
    game.queue = list(cmd_tokens)  # Treat all remaining as command queue
    
    # The first piece in sequence spawns NOW, before any commands processed
    spawn_piece(game, piece_seq_list[0])
    piece_seq_list.pop(0)
    # Add remaining sequence pieces to queue
    game.queue.extend(piece_seq_list)
    
    # Print initial board (before any command applied)
    printed_once = False
    output_buffer = []
    
    def maybe_print():
        nonlocal printed_once
        if not printed_once:
            print(print_board_lines(game))
            printed_once = True
    
    # Process commands
    processed_until_end = True
    while processed_until_end:
        cmd_str = None
        idx = 0
        while idx < len(cmd_tokens):
            ts = cmd_tokens[idx]
            upper = ts.upper()
            
            if upper in ('P', 'L', 'R', 'D', 'H', 'CW', 'CCW'):
                cmd_str = ts
                break
            
            # Skip unknown
            idx += 1
        
        if cmd_str is None:
            processed_until_end = False
            continue
        
        cmd_upper = cmd_str.upper()
        
        if game.state == 'OVER':
            output_buffer.append(f"SCORE {game.score} LINES {game.lines_cleared} OVER")
            processed_until_end = False
            continue
        
        # Handle each command type
        if cmd_upper == 'P':
            output_buffer.append(print_board_lines(game))
            printed_once = True
        
        elif cmd_upper == 'L':
            # Only process if piece exists
            if game.active_piece is not None:
                apply_move_left(game)
        
        elif cmd_upper == 'R':
            if game.active_piece is not None:
                apply_move_right(game)
        
        elif cmd_upper == 'D':
            if game.active_piece is not None:
                apply_move_down(game)
        
        elif cmd_upper == 'H':
            if game.active_piece is not None:
                hard_drop(game)
        
        elif cmd_upper == 'CW':
            if game.active_piece is not None:
                try_rotate_clockwise(game)
        
        elif cmd_upper == 'CCW':
            if game.active_piece is not None:
                # CCW: new_state = (old + 3) mod 4
                old_state = game.piece_state
                new_state = (old_state + 3) % 4
                
                tried = False
                for offset in [-2, -1, 0, 1, 2]:
                    try_col = game.pos_c + offset
                    if 0 <= try_col <= BOARD_COLS - 4:
                        b_test = clone_board(game.board)
                        if check_fit(b_test, game.active_piece, game.pos_r, try_col, new_state):
                            game.piece_state = new_state
                            game.pos_c = try_col
                            tried = True
                            break
                
                if not tried:
                    b_test = clone_board(game.board)
                    if check_fit(b_test, game.active_piece, game.pos_r, game.pos_c, new_state):
                        game.piece_state = new_state
                        tried = True
                
                if tried:
                    game.pos_c = game.pos_c  # Keep original col
                    pass
        
        cmd_tokens.pop(idx)
        
        # Check if we should spawn next piece
        if game.active_piece is not None:
            processed_until_end = True
        else:
            # Try spawning next
            if game.queue and game.queue[game.next_idx]:
                pt = game.queue[game.next_idx]
                game.queue[game.next_idx] = None
                game.next_idx += 1
                result = spawn_piece(game, pt)
                
                if not result:
                    game.state = 'OVER'
                    game.active_piece = None
                processed_until_end = True
            elif game.active_piece is None:
                if game.next_idx >= len(game.queue):
                    processed_until_end = False
                else:
                    # Queue is empty but piece ran out? Should be DONE
                    game.state = 'DONE'
                    game.active_piece = None
                    processed_until_end = True
        
        # If became OVER, stop processing
        if game.state == 'OVER':
            break
    
    # Output everything
    if output_buffer:
        for line in output_buffer:
            print(line)
    else:
        print(print_board_lines(game))
    
    # Final status line
    st = f"SCORE {game.score} LINES {game.lines_cleared}"
    if game.state == 'PLAYING':
        st += ' PLAYING'
    elif game.state == 'OVER':
        st += ' OVER'
    else:
        st += ' DONE'
    print(st)


if __name__ == '__main__':
    main()
