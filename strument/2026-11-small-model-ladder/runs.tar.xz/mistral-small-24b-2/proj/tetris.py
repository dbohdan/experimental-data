import sys

# Constants
BOARD_COLUMNS = 10
BOARD_ROWS = 20
PIECE_TYPES = ['I', 'O', 'T', 'S', 'Z', 'J', 'L']

# Piece shapes
PIECE_SHAPES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)]
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)]
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)]
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)]
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)]
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)]
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)]
    ]
}

# Initialize the board
board = [['.' for _ in range(BOARD_COLUMNS)] for _ in range(BOARD_ROWS)]

# Initialize game state
score = 0
lines_cleared = 0
current_piece = None
current_piece_state = 0
current_piece_row = 0
current_piece_col = 3
piece_sequence = []
game_state = 'PLAYING'

# Read the piece sequence
def read_piece_sequence():
    global piece_sequence
    piece_sequence = list(sys.stdin.readline().strip())

# Spawn a new piece
def spawn_piece():
    global current_piece, current_piece_state, current_piece_row, current_piece_col, game_state
    if not piece_sequence:
        game_state = 'DONE'
        return False
    current_piece = piece_sequence.pop(0)
    current_piece_state = 0
    current_piece_row = 0
    current_piece_col = 3
    if not does_piece_fit():
        game_state = 'OVER'
        return False
    return True

# Check if a piece fits on the board
def does_piece_fit():
    for (dr, dc) in PIECE_SHAPES[current_piece][current_piece_state]:
        r, c = current_piece_row + dr, current_piece_col + dc
        if r < 0 or r >= BOARD_ROWS or c < 0 or c >= BOARD_COLUMNS or board[r][c] != '.':
            return False
    return True

# Move the piece left
def move_left():
    global current_piece_col
    if game_state != 'PLAYING':
        return
    current_piece_col -= 1
    if not does_piece_fit():
        current_piece_col += 1

# Move the piece right
def move_right():
    global current_piece_col
    if game_state != 'PLAYING':
        return
    current_piece_col += 1
    if not does_piece_fit():
        current_piece_col -= 1

# Move the piece down
def move_down():
    global current_piece_row, score
    if game_state != 'PLAYING':
        return
    current_piece_row += 1
    if not does_piece_fit():
        current_piece_row -= 1
        lock_piece()
    else:
        score += 1

# Hard drop the piece
def hard_drop():
    global current_piece_row, score
    if game_state != 'PLAYING':
        return
    while does_piece_fit():
        current_piece_row += 1
        score += 2
    current_piece_row -= 1
    lock_piece()

# Rotate the piece clockwise
def rotate_cw():
    global current_piece_state
    if game_state != 'PLAYING':
        return
    new_state = (current_piece_state + 1) % 4
    original_state = current_piece_state
    current_piece_state = new_state
    if not does_piece_fit():
        current_piece_state = original_state
        for dc in [-1, 1, -2, 2]:
            current_piece_col += dc
            if does_piece_fit():
                break
            current_piece_col -= dc
        else:
            current_piece_state = original_state

# Rotate the piece counterclockwise
def rotate_ccw():
    global current_piece_state
    if game_state != 'PLAYING':
        return
    new_state = (current_piece_state + 3) % 4
    original_state = current_piece_state
    current_piece_state = new_state
    if not does_piece_fit():
        current_piece_state = original_state
        for dc in [-1, 1, -2, 2]:
            current_piece_col += dc
            if does_piece_fit():
                break
            current_piece_col -= dc
        else:
            current_piece_state = original_state

# Lock the piece in place
def lock_piece():
    global board, score, lines_cleared, current_piece, game_state
    for (dr, dc) in PIECE_SHAPES[current_piece][current_piece_state]:
        r, c = current_piece_row + dr, current_piece_col + dc
        board[r][c] = current_piece
    clear_lines()
    if not spawn_piece():
        return

# Clear completed lines
def clear_lines():
    global board, score, lines_cleared
    lines_to_clear = [r for r in range(BOARD_ROWS) if all(cell != '.' for cell in board[r])]
    for r in lines_to_clear:
        del board[r]
        board.insert(0, ['.' for _ in range(BOARD_COLUMNS)])
    if lines_to_clear:
        lines_cleared += len(lines_to_clear)
        score += [100, 300, 500, 800][min(len(lines_to_clear) - 1, 3)]

# Print the board
def print_board():
    for row in board:
        print(''.join(row))
    print(f'SCORE {score} LINES {lines_cleared} {game_state}')

# Main game loop
def main():
    global game_state
    read_piece_sequence()
    if not spawn_piece():
        print_board()
        return
    for line in sys.stdin:
        for command in line.strip().split():
            if command == 'L':
                move_left()
            elif command == 'R':
                move_right()
            elif command == 'D':
                move_down()
            elif command == 'H':
                hard_drop()
            elif command == 'CW':
                rotate_cw()
            elif command == 'CCW':
                rotate_ccw()
            elif command == 'P':
                print_board()
            else:
                print(f'error: unknown command {command}', file=sys.stderr)
    print_board()

if __name__ == '__main__':
    main()