#!/usr/bin/env python3
"""Headless Tetris - A minimal tetris clone."""

import sys


ROWS = 20
COLS = 10

LOCKED_CHARS = {'I':'i','O':'o','T':'t','S':'s','Z':'z','J':'j','L':'l'}

SCORE_TABLE = {1:100, 2:300, 3:500, 4:800}


# Block layouts for each piece in spawn box (row,col offsets)
PIECES = {
    'I': [[(1,0),(1,1),(1,2),(1,3)], [(0,2),(1,2),(2,2),(3,2)], [(2,0),(2,1),(2,2),(2,3)], [(0,1),(1,1),(2,1),(3,1)]],
    'O': [[(0,1),(0,2),(1,1),(1,2)]],
    'T': [[(0,1),(1,0),(1,1),(1,2)], [(0,1),(1,1),(1,2),(2,1)], [(1,0),(1,1),(1,2),(2,1)], [(0,1),(1,0),(1,1),(2,1)]],
    'S': [[(0,1),(0,2),(1,0),(1,1)], [(0,1),(1,1),(1,2),(2,2)], [(1,1),(1,2),(2,0),(2,1)], [(0,0),(1,0),(1,1),(2,1)]],
    'Z': [[(0,0),(0,1),(1,1),(1,2)], [(0,2),(1,1),(1,2),(2,1)], [(1,0),(1,1),(2,1),(2,2)], [(0,1),(1,0),(1,1),(2,0)]],
    'J': [[(0,0),(1,0),(1,1),(1,2)], [(0,1),(0,2),(1,1),(2,1)], [(1,0),(1,1),(1,2),(2,2)], [(0,1),(1,0),(1,1),(2,1)]],
    'L': [[(0,2),(1,0),(1,1),(1,2)], [(0,1),(1,1),(2,1),(2,2)], [(1,0),(1,1),(1,2),(2,0)], [(0,0),(0,1),(1,1),(2,1)]],
}


def make_blocks(name, state):
    """Return list of absolute (r,c) block positions for given name at given state."""
    result = []
    base = PIECES[name][state]
    for br, bc in base:
        result.append((br, bc))
    return result


def apply_piece(boards, name, r_start, c_start, s_state, lock=True):
    """Place/lock a piece on boards. Lock mode marks as uppercase/edge '#', active mode marks lowercase."""
    blks = make_blocks(name, s_state)
    
    if lock:
        marker = LOCKED_CHARS[name]
        char = marker.upper()
    else:
        char = name.lower()
    
    placed = True
    for br, bc in blks:
        lr, lc = r_start + br, c_start + bc
        
        # Must be within bounds and not occupied
        if lr < 0 or lr >= ROWS or lc < 0 or lc >= COLS:
            return False
        if boards['grid'][lr][lc] != '.':
            return False
    
    # Actually place them
    for br, bc in blks:
        lr, lc = r_start + br, c_start + bc
        boards['grid'][lr][lc] = char
    
    return True


class Board:
    """Game board stored as a mutable grid."""
    
    def __init__(self):
        self.grid = [['.'] * COLS for _ in range(ROWS)]
    
    @property
    def display_lines(self):
        return [''.join(r) for r in self.grid]
    
    def can_fit(self, br, bc, name, s_state):
        """Check if piece would fit at position (r,c) with state."""
        blks = make_blocks(name, s_state)
        
        for br_off, bc_off in blks:
            tr, tc = br + br_off, bc + bc_off
            if tr < 0 or tr >= ROWS or tc < 0 or tc >= COLS:
                return False
            if self.grid[tr][tc] != '.':
                return False
        return True
    
    def try_lock(self, name, r_start, c_start, s_state):
        """Try to lock piece and return True if successful."""
        blks = make_blocks(name, s_state)
        
        best_c = c_start
        for oc in [-1, 1, -2, 2]:
            test_c = c_start + oc
            if self.can_fit(r_start, test_c, name, s_state):
                best_c = test_c
                break
        
        success = True
        marker = LOCKED_CHARS[name]
        char = marker.upper()
        
        for br, bc in blks:
            lr, lc = r_start + br, best_c + bc
            if lr < 0 or lr >= ROWS or lc < 0 or lc >= COLS:
                success = False
                break
            if self.grid[lr][lc] != '.':
                success = False
                break
        
        if success:
            for br, bc in blks:
                lr, lc = r_start + br, best_c + bc
                self.grid[lr][lc] = char
        
        return success
    
    def clear_lines(self):
        """Remove full lines from bottom up. Return count cleared."""
        kept = []
        cnt = 0
        
        for i in range(ROWS - 1, -1, -1):
            row_str = ''.join(self.grid[i])
            
            any_empty = any(ch == '.' for ch in row_str)
            
            if any_empty:
                kept.append(row_str)
            else:
                cnt += 1
        
        result = kept[:]
        while len(result) < ROWS:
            result.insert(0, ['.'] * COLS)
        self.grid = result[:ROWS]
        
        return cnt
    
    def cell_at(self, r, c):
        """Get character at position."""
        if r < 0 or r >= ROWS or c < 0 or c >= COLS:
            return '#'
        return self.grid[r][c]


def main():
    input_data = sys.stdin.read().splitlines()
    game = Game()
    
    seq_line = ''
    if input_data:
        seq_line = input_data[0]
    
    for ch in seq_line:
        game.pieces.append(ch)
    
    game.spawn_first()
    
    for line_num in range(1, len(input_data)):
        tokens = input_data[line_num].split()
        for tok in tokens:
            tok_stripped = tok.strip()
            if tok_stripped:
                game.do_cmd(tok_stripped)
    
    print_board(game)


class Game:
    def __init__(self):
        self.board = Board()
        self.active_p = None
        self.pieces = []
        self.next_idx = 0
        self.score = 0
        self.lines = 0
        self.status = 'PLAYING'
    
    def get_active_name(self):
        """Return name of active piece or None."""
        if self.active_p is None:
            return None
        return self.active_p['name']
    
    def get_active_pos(self):
        """Return current position as (r, c)."""
        if self.active_p is None:
            return None
        return self.active_p['pos']
    
    def get_active_state(self):
        if self.active_p is None:
            return 0
        return self.active_p['state']
    
    def update_board_position(self):
        """Update board with new active piece position (lowercase)."""
        pn = self.active_p['name']
        rr, cc = self.active_p['pos']
        ss = self.active_p['state']
        apply_piece({'board': self.board}, pn, rr, cc, ss, lock=False)
    
    def spawn_first(self):
        """Spawn first piece from queue."""
        if not self.pieces:
            self.status = 'DONE'
            self.active_p = None
            return
        
        name = self.pieces[0]
        self.pieces = self.pieces[1:]
        
        # Try spawning at different columns
        spawned = False
        for offset in [-1, 1, -2, 2]:
            test_pos = (INITIAL_ROW, INITIAL_COL + offset)
            test = {'name': name, 'state': 0, 'pos': test_pos}
            pos_r, pos_c = test['pos']
            
            if self.board.can_fit(pos_r, pos_c, name, 0):
                self.active_p = test
                self.update_board_position()
                spawned = True
                break
        
        if not spawned:
            self.status = 'OVER'
            self.active_p = None
        elif self.pieces:
            pass  # Next command will spawn next piece
    
    def try_rotate_cw(self):
        """Try rotating CW. Returns True if successful."""
        if self.active_p is None or self.status == 'OVER':
            return False
        
        target_s = (self.active_p['state'] + 1) % 4
        
        pname = self.get_active_name()
        curr_row, curr_col = self.get_active_pos()
        
        fits_here = self.board.can_fit(curr_row, curr_col, pname, target_s)
        
        col_offsets = [-1, 1, -2, 2]
        for oc in col_offsets:
            if fits_here:
                self.active_p['col'] = curr_col
                return True
            
            new_col = curr_col + oc
            test_fits = self.board.can_fit(curr_row, new_col, pname, target_s)
            if test_fits:
                self.active_p['col'] = new_col
                return True
        
        return False
    
    def try_rotate_ccw(self):
        """Try rotating CCW. Returns True if successful."""
        if self.active_p is None or self.status == 'OVER':
            return False
        
        target_s = (self.active_p['state'] + 3) % 4
        
        pname = self.get_active_name()
        curr_row, curr_col = self.get_active_pos()
        
        fits_here = self.board.can_fit(curr_row, curr_col, pname, target_s)
        
        col_offsets = [-1, 1, -2, 2]
        for oc in col_offsets:
            if fits_here:
                self.active_p['col'] = curr_col
                return True
            
            new_col = curr_col + oc
            test_fits = self.board.can_fit(curr_row, new_col, pname, target_s)
            if test_fits:
                self.active_p['col'] = new_col
                return True
        
        return False
    
    def try_move_left(self):
        """Try move left. Return True if moved."""
        if self.active_p is None or self.status == 'OVER':
            return False
        
        nc = self.active_p['col'] - 1
        nr = self.active_p['row']
        nn = self.get_active_name()
        ns = self.active_p['state']
        
        if self.board.can_fit(nr, nc, nn, ns):
            self.active_p['col'] = nc
            return True
        return False
    
    def try_move_right(self):
        """Try move right. Return True if moved."""
        if self.active_p is None or self.status == 'OVER':
            return False
        
        nc = self.active_p['col'] + 1
        nr = self.active_p['row']
        nn = self.get_active_name()
        ns = self.active_p['state']
        
        if self.board.can_fit(nr, nc, nn, ns):
            self.active_p['col'] = nc
            return True
        return False
    
    def drop_one(self):
        """Try move down one row. Return True if moved."""
        if self.active_p is None or self.status == 'OVER':
            return False
        
        nr = self.active_p['row'] + 1
        nc = self.active_p['col']
        nn = self.get_active_name()
        ns = self.active_p['state']
        
        if self.board.can_fit(nr, nc, nn, ns):
            self.active_p['row'] = nr
            return True
        return False
    
    def hard_drop(self):
        """Drop until locks. Add 2 points per step down."""
        if self.active_p is None or self.status == 'OVER':
            return False
        
        # Calculate how many steps we can drop
        drops = 0
        nn = self.get_active_name()
        ns = self.active_p['state']
        curr_r = self.active_p['row']
        curr_c = self.active_p['col']
        
        while True:
            test_r = curr_r + drops + 1
            test_c = curr_c
            test_blks = make_blocks(nn, ns)
            
            fits = True
            for br, bc in test_blks:
                tr, tc = test_r + br, test_c + bc
                if tr < 0 or tr >= ROWS or tc < 0 or tc >= COLS:
                    fits = False
                    break
                if self.board.grid[tr][tc] != '.':
                    fits = False
                    break
            
            if fits:
                self.active_p['row'] = test_r
                drops += 1
                self.score += 2
            else:
                break
        
        # Update and lock
        self.active_p['row'] = curr_r
        self.lock_current()
    
    def lock_current(self):
        """Lock current piece and clear lines."""
        if self.active_p is None:
            return
        
        rn = self.get_active_name()
        rc, rs = self.get_active_pos()
        st = self.active_p['state']
        
        self.board.try_lock(rn, rc, rs, st)
        
        num_cleared = self.board.clear_lines()
        self.lines += num_cleared
        self.score += SCORE_TABLE[num_cleared]
    
    def do_cmd(self, cmd):
        """Process one command."""
        if self.status == 'OVER':
            return True
        
        if cmd == 'P':
            self.print_final()
            return True
        
        # If no active piece, ignore most commands except P
        if self.active_p is None:
            return True
        
        if cmd == 'L':
            return self.try_move_left()
        
        elif cmd == 'R':
            return self.try_move_right()
        
        elif cmd == 'D':
            if self.drop_one():
                self.score += 1
            else:
                self.lock_current()
            return True
        
        elif cmd == 'H':
            self.hard_drop()
            return True
        
        elif cmd == 'CW':
            if self.try_rotate_cw():
                self.print_final()
                return True
            return False
        
        elif cmd == 'CCW':
            if self.try_rotate_ccw():
                self.print_final()
                return True
            return False
        
        else:
            print(f"error: unknown command {cmd}", file=sys.stderr)
            return True
    
    def print_final(self):
        """Print final game state."""
        out_lines = []
        for row in self.board.display_lines:
            out_lines.append(row)
        
        st = f"{'OVER' if self.status == 'OVER' else 'DONE'}"
        out_lines.append(f"SCORE {self.score} LINES {self.lines} {st}")
        
        sys.stdout.write('\n'.join(out_lines) + '\n')


if __name__ == '__main__':
    main()
