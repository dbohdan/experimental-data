#!/usr/bin/env python3
"""Headless Tetris."""

import sys


ROWS = 20
COLS = 10
INITIAL_ROW = 0
INITIAL_COL = 3

SCORES = {1: 100, 2: 300, 3: 500, 4: 800}
LOCKERS = {'I': 'i', 'O': 'o', 'T': 't', 'S': 's', 'Z': 'z', 'J': 'j', 'L': 'l'}


PIECES = {
    'I': [
        [(1,0),(1,1),(1,2),(1,3)],
        [(0,2),(1,2),(2,2),(3,2)],
        [(2,0),(2,1),(2,2),(2,3)],
        [(0,1),(1,1),(2,1),(3,1)]
    ],
    'O': [[(0,1),(0,2),(1,1),(1,2)]],
    'T': [
        [(0,1),(1,0),(1,1),(1,2)],
        [(0,1),(1,1),(1,2),(2,1)],
        [(1,0),(1,1),(1,2),(2,1)],
        [(0,1),(1,0),(1,1),(2,1)]
    ],
    'S': [
        [(0,1),(0,2),(1,0),(1,1)],
        [(0,1),(1,1),(1,2),(2,2)],
        [(1,1),(1,2),(2,0),(2,1)],
        [(0,0),(1,0),(1,1),(2,1)]
    ],
    'Z': [
        [(0,0),(0,1),(1,1),(1,2)],
        [(0,2),(1,1),(1,2),(2,1)],
        [(1,0),(1,1),(2,1),(2,2)],
        [(0,1),(1,0),(1,1),(2,0)]
    ],
    'J': [
        [(0,0),(1,0),(1,1),(1,2)],
        [(0,1),(0,2),(1,1),(2,1)],
        [(1,0),(1,1),(1,2),(2,2)],
        [(0,1),(1,0),(1,1),(2,1)]
    ],
    'L': [
        [(0,2),(1,0),(1,1),(1,2)],
        [(0,1),(1,1),(2,1),(2,2)],
        [(1,0),(1,1),(1,2),(2,0)],
        [(0,0),(0,1),(1,1),(2,1)]
    ]
}


class Board:
    def __init__(self):
        self.grid = [['.'] * COLS for _ in range(ROWS)]
    
    def can_place(self, rows_list):
        """Check if piece blocks at given absolute positions fit on board."""
        blks = []
        for r_row, c_col in rows_list:
            blks.append((r_row, c_col))
        
        valid = True
        for br, bc in blks:
            tr, tc = br, bc
            if tr < 0 or tr >= ROWS or tc < 0 or tc >= COLS:
                valid = False
                break
            ch = self.grid[tr][tc]
            if ch != '.' and ch not in '#':
                valid = False
                break
        return valid
    
    def place_piece(self, name, row_start, col_start, lock=True):
        """Place piece blocks on board."""
        marker = '#' if lock else LOCKERS[name].lower()
        
        pieces_blocks = PIECES[name]
        state_idx = len(pieces_blocks) - 1  # Use last state layout
        
        lr = row_start
        lc = col_start
        
        for br, bc in pieces_blocks[state_idx]:
            tr, tc = lr + br, lc + bc
            if 0 <= tr < ROWS and 0 <= tc < COLS:
                on_edge = (tr == 0 or tr == ROWS-1 or tc == 0 or tc == COLS-1)
                fc = '#' if on_edge else marker.upper() if lock else '.'
                
                if self.grid[tr][tc] == '.':
                    self.grid[tr][tc] = fc
                    
    def clear_lines(self):
        """Remove full lines from bottom up. Return number cleared."""
        cleared_count = 0
        kept = []
        
        for i in range(ROWS - 1, -1, -1):
            rs = ''.join(self.grid[i])
            
            all_locked = True
            for ch in rs:
                if ch != '.' and ch != '#':
                    all_locked = False
                    break
            
            if all_locked:
                cleared_count += 1
            else:
                kept.append(rs)
        
        result = list(reversed(kept))[:ROWS]
        while len(result) < ROWS:
            result.insert(0, ['.'] * COLS)
        
        self.grid = result[:ROWS]
        
        return cleared_count
    
    def get_state_str(self):
        """Get status string."""
        s = self.status
        if s == 'OVER' and not self.active:
            return s
        return s
