#!/usr/bin/env python3
"""Headless Tetris."""

import sys

ROWS = 20
COLS = 10


def expand(piece_char, start_row, start_col):
    """Return all absolute positions of piece blocks given piece char and starting position."""
    offsets = PIECES[piece_char]
    result = []
    for dr, dc in offsets[start_row % 4]:
        result.append((start_row + dr, start_col + dc))
    return result


PIECES = {
    'I': [
        [(1,0),(1,1),(1,2),(1,3)],
        [(0,2),(1,2),(2,2),(3,2)],
        [(2,0),(2,1),(2,2),(2,3)],
        [(0,1),(1,1),(2,1),(3,1)],
    ],
    'O': [[(0,1),(0,2),(1,1),(1,2)]],
    'T': [
        [(0,1),(1,0),(1,1),(1,2)],
        [(0,1),(1,1),(1,2),(2,1)],
        [(1,0),(1,1),(1,2),(2,1)],
        [(0,1),(1,0),(1,1),(2,1)],
    ],
    'S': [
        [(0,1),(0,2),(1,0),(1,1)],
        [(0,1),(1,1),(1,2),(2,2)],
        [(1,1),(1,2),(2,0),(2,1)],
        [(0,0),(1,0),(1,1),(2,1)],
    ],
    'Z': [
        [(0,0),(0,1),(1,1),(1,2)],
        [(0,2),(1,1),(1,2),(2,1)],
        [(1,0),(1,1),(2,1),(2,2)],
        [(0,1),(1,0),(1,1),(2,0)],
    ],
    'J': [
        [(0,0),(1,0),(1,1),(1,2)],
        [(0,1),(0,2),(1,1),(2,1)],
        [(1,0),(1,1),(1,2),(2,2)],
        [(0,1),(1,0),(1,1),(2,1)],
    ],
    'L': [
        [(0,2),(1,0),(1,1),(1,2)],
        [(0,1),(1,1),(2,1),(2,2)],
        [(1,0),(1,1),(1,2),(2,0)],
        [(0,0),(0,1),(1,1),(2,1)],
    ],
}

LOCKED_MARKER = {
    'I':'i', 'O':'o', 'T':'t', 'S':'s', 'Z':'z', 'J':'j', 'L':'l'
}

SCORE_TABLE = {1:100, 2:300, 3:500, 4:800}


def fits(piece_char, br, bc, state_idx, grid):
    """Check if piece would fit at absolute position (br, bc) with given state.
       Returns True if all four blocks are free or out-of-bounds."""
    offsets = PIECES[piece_char][state_idx]
    for tr, tc in [(br + r, bc + c) for r, c in offsets]:
        # Out of bounds means it doesn't fit
        if tr < 0 or tr >= ROWS or tc < 0 or tc >= COLS:
            return False
        # Cell must be empty '.' 
        if grid[tr][tc] != '.':
            return False
    return True


class Game:
    def __init__(self):
        # Grid initialized with all empty cells
        self.grid = [['.' for _ in range(COLS)] for _ in range(ROWS)]
        
        # Active piece info: char name, row of top-left box, col of top-left box
        self.active_name = None
        self.br = INITIAL_ROW
        self.bc = INITIAL_COL
        self.state = 0
        
        # Piece queue and index
        self.piece_list = []
        self.next_piece_idx = 0
        
        # Game state: 'PLAYING', 'OVER', 'DONE'
        self.game_state = 'PLAYING'
        
        # Score tracking
        self.score = 0
        self.lines_cleared = 0
    
    def spawn_next(self):
        """Spawn the next piece from the queue. Return True if successful."""
        if self.game_state == 'OVER':
            return False
        
        if self.next_piece_idx >= len(self.piece_list):
            self.game_state = 'DONE'
            return False
        
        name = self.piece_list[self.next_piece_idx]
        self.piece_list[self.next_piece_idx] = None  # Consume from queue
        self.next_piece_idx += 1
        
        found = False
        test_state = 0
        
        # Try different column offsets to find a valid spawn position
        for oc in [-1, 1, -2, 2]:
            tbc = self.bc + oc
            if fits(name, INITIAL_ROW, tbc, test_state, self.grid):
                self.active_name = name
                self.br = INITIAL_ROW
                self.bc = tbc
                self.state = test_state
                found = True
                break
        
        if not found:
            # Piece cannot spawn - game over
            self.active_name = None
            self.game_state = 'OVER'
            return False
        
        # Place the active piece on the board as lowercase
        self.lock_with_marker(name, self.state, marker_is_lower=True)
        
        return True
    
    def lock(self):
        """Lock the active piece onto the board."""
        name = self.active_name
        markers = LOCKED_MARKER[name]
        ps = self.state
        
        for br, bc in expand(name, self.br, self.bc):
            if 0 <= br < ROWS and 0 <= bc < COLS:
                self.place_locked(br, bc, name)
        
        # Clear any full lines and add new empty rows at top
        num_cleared = self.clear_lines()
        self.lines_cleared += num_cleared
        self.score += SCORE_TABLE[num_cleared]
    
    def place_locked(self, br, bc, name):
        """Place a locked block at absolute position (br, bc)."""
        marker = LOCKED_MARKER[name]
        
        for lr, lc in expand(name, br, bc):
            if 0 <= lr < ROWS and 0 <= lc < COLS:
                at_edge = (lr == 0 or lr == ROWS-1 or lc == 0 or lc == COLS-1)
                final_char = '#' if at_edge else marker.upper()
                self.grid[lr][lc] = final_char
    
    def try_move_horizontal(self, dr, dc):
        """Try moving piece by (dr, dc). Return True if move was made."""
        if self.game_state == 'OVER':
            return False
        
        if self.active_name is None:
            return False
        
        # Create test piece at new position
        new_br = self.br + dr
        new_bc = self.bc + dc
        test_state = self.state
        
        if fits(self.active_name, new_br, new_bc, test_state, self.grid):
            self.br = new_br
            self.bc = new_bc
            return True
        
        return False
    
    def try_rotate(self, direction_delta):
        """Try rotating clockwise or counterclockwise."""
        if self.game_state == 'OVER':
            return False
        
        if self.active_name is None:
            return False
        
        target_state = (self.state + direction_delta) % 4
        
        # First try at current position
        if fits(self.active_name, self.br, self.bc, target_state, self.grid):
            self.state = target_state
            return True
        
        # Then try shifting left/right
        for oc in [-1, 1, -2, 2]:
            tbc = self.bc + oc
            if fits(self.active_name, self.br, tbc, target_state, self.grid):
                self.bc = tbc
                self.state = target_state
                return True
        
        return False
    
    def hard_drop(self):
        """Drop piece down until it locks. Add score for each step down."""
        if self.game_state == 'OVER':
            return False
        
        if self.active_name is None:
            return False
        
        name = self.active_name
        total_steps = 0
        
        while True:
            new_br = self.br + total_steps + 1
            if fits(name, new_br, self.bc, self.state, self.grid):
                self.br = new_br
                total_steps += 1
                self.score += 2
            else:
                break
        
        # Drop piece to final position
        self.br = self.br
        
        # Lock it there
        self.lock()
    
    def remove_lines(self):
        """Remove all full lines from bottom up. Return count cleared."""
        cleared_count = 0
        kept = []
        
        for i in range(ROWS - 1, -1, -1):
            row_chars = list(self.grid[i])
            
            is_full = True
            for ch in row_chars:
                if ch != '.' and ch not in '#':  # Must be fully locked to count
                    is_full = False
                    break
            
            if is_full:
                cleared_count += 1
            else:
                kept.append(row_chars)
        
        # Rebuild board
        result = kept[:]
        while len(result) < ROWS:
            result.insert(0, ['.'] * COLS)
        
        self.grid = result[:ROWS]
        return cleared_count
    
    def lock_all(self, name, ps):
        """Lock all blocks of a piece type at a given absolute position."""
        markers = LOCKED_MARKER[name]
        
        for br, bc in expand(name, self.br, self.bc):
            if 0 <= br < ROWS and 0 <= bc < COLS:
                at_edge = (br == 0 or br == ROWS-1 or bc == 0 or bc == COLS-1)
                fc = '#' if at_edge else markers.upper()
                self.grid[br][bc] = fc
    
    def output_board(self):
        """Output the current board state."""
        lines = []
        for row in self.grid:
            lines.append(''.join(row))
        return lines
    
    def process_token(self, token):
        """Process one command token."""
        if token == 'P':
            pass
        
        if token == 'L':
            # Move left
            if self.try_move_horizontal(0, -1):
                pass
        
        elif token == 'R':
            # Move right
            if self.try_move_horizontal(0, 1):
                pass
        
        elif token == 'D':
            # Move down; if fails, lock
            moved_down = self.try_move_horizontal(1, 0)
            if not moved_down:
                self.lock()
            else:
                self.score += 1
        
        elif token == 'H':
            # Hard drop: drop down as much as possible, then lock
            self.hard_drop()
        
        elif token == 'CW':
            # Rotate clockwise
            if self.try_rotate(1):
                pass
        
        elif token == 'CCW':
            # Rotate counterclockwise
            if self.try_rotate(-1):
                pass
            # But wait - CCW should go counter-clockwise through states
            # State goes: s -> s+3 mod 4, which effectively wraps backwards
            # Actually we already handle this in try_rotate
        
        else:
            print(f"error: unknown command {token}", file=sys.stderr)
        
        if token == 'P':
            print('\n'.join(self.output_board()))
            if self.game_state == 'DONE':
                print(f"SCORE {self.score} LINES {self.lines_cleared} DONE")
            else:
                print(f"SCORE {self.score} LINES {self.lines_cleared} PLAYING")


# Main program
INITIAL_BR = 0
INITIAL_BC = 3

pieces_seq = input().split()[0]  # Just first line is piece sequence
piece_chars = list(pieces_seq)

board_grid = [['.' for _ in range(COLS)] for _ in range(ROWS)]

game = Game(board_grid)

# Spawn first piece before processing commands
game.spawn_next()

# Process remaining commands
for line in input_data.splitlines()[1:]:
    for tok in line.split():
        if tok.strip():
            game.process_token(tok)


if __name__ == '__main__':
    main()
