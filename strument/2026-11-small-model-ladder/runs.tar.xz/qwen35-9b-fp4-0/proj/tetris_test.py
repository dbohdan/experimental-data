#!/usr/bin/env python3
"""Test piece definitions."""

PIECES = {
    'I': [
        [(1,0), (1,1), (1,2), (1,3)],  # state 0
        [(0,2), (1,2), (2,2), (3,2)],  # state 1
        [(2,0), (2,1), (2,2), (2,3)],  # state 2
        [(0,1), (1,1), (2,1), (3,1)],  # state 3
    ],
}

class Piece:
    def __init__(self, name, row, col, state):
        self.name = name
        self.row = row
        self.col = col
        self.state = state
    
    @property
    def blocks_absolute(self):
        base = PIECES[self.name][self.state]
        result = []
        for br, bc in base:
            result.append((self.row + br, self.col + bc))
        return result

# Test spawning 'I' at (0, 3) and checking if it fits on empty board
ROWS = 20
COLS = 10

class Board:
    ROWS = ROWS
    COLS = COLS
    
    def __init__(self):
        self.grid = [['.'] * self.COLS for _ in range(self.ROWS)]
        self.occupied = [[False] * self.COLS for _ in range(self.ROWS)]
    
    def is_occupied_at(self, r, c):
        if r < 0 or r >= self.ROWS or c < 0 or c >= self.COLS:
            return True
        return self.occupied[r][c]
    
    def can_fit_blocks_at(self, blocks):
        for br, bc in blocks:
            if self.is_occupied_at(br, bc):
                return False
        return True

board = Board()
piece = Piece('I', 0, 3, 0)
print("Piece 'I' state 0:", piece.blocks_absolute)
print("Fits?", board.can_fit_blocks_at(piece.blocks_absolute))

piece2 = Piece('I', 0, 3, 1)
print("Piece 'I' state 1:", piece2.blocks_absolute)
print("Fits?", board.can_fit_blocks_at(piece2.blocks_absolute))

piece3 = Piece('I', 0, 3, 3)
print("Piece 'I' state 3:", piece3.blocks_absolute)
print("Fits?", board.can_fit_blocks_at(piece3.blocks_absolute))
