#!/usr/bin/env python3
"""Headless Tetris."""

import sys


# Constants
ROWS = 20
COLS = 10
START_ROW = 0
START_COL = 3


# Score for clearing lines
SCORE_TABLE = {1: 100, 2: 300, 3: 500, 4: 800}


LOCKED_CHARS = {
    'I': 'i', 'O': 'o', 'T': 't', 'S': 's', 'Z': 'z', 'J': 'j', 'L': 'l'
}


def build_piece_blocks(piece_char, state):
    """Return list of (br, bc) block offsets in 4x4 box for given piece and state."""
    return PIECES[piece_char][state]


PIECES = {
    'I': [
        [(1,0),(1,1),(1,2),(1,3)],
        [(0,2),(1,2),(2,2),(3,2)],
        [(2,0),(2,1),(2,2),(2,3)],
        [(0,1),(1,1),(2,1),(3,1)]
    ],
    'O': [[(0,1),(0,2),(1,1),(1,2)]],
    'T': [
        [(0,1),(1,0),(1,1),(1,2)],
        [(0,1),(1,1),(1,2),(2,1)],
        [(1,0),(1,1),(1,2),(2,1)],
        [(0,1),(1,0),(1,1),(2,1)]
    ],
    'S': [
        [(0,1),(0,2),(1,0),(1,1)],
        [(0,1),(1,1),(1,2),(2,2)],
        [(1,1),(1,2),(2,0),(2,1)],
        [(0,0),(1,0),(1,1),(2,1)]
    ],
    'Z': [
        [(0,0),(0,1),(1,1),(1,2)],
        [(0,2),(1,1),(1,2),(2,1)],
        [(1,0),(1,1),(2,1),(2,2)],
        [(0,1),(1,0),(1,1),(2,0)]
    ],
    'J': [
        [(0,0),(1,0),(1,1),(1,2)],
        [(0,1),(0,2),(1,1),(2,1)],
        [(1,0),(1,1),(1,2),(2,2)],
        [(0,1),(1,0),(1,1),(2,1)]
    ],
    'L': [
        [(0,2),(1,0),(1,1),(1,2)],
        [(0,1),(1,1),(2,1),(2,2)],
        [(1,0),(1,1),(1,2),(2,0)],
        [(0,0),(0,1),(1,1),(2,1)]
    ]
}


class Piece:
    """A spawned piece waiting to be placed."""
    
    def __init__(self, char):
        self.char = char
        self.row = START_ROW
        self.col = START_COL
        self.state = 0


def check_position_fits(board, r_start, c_start, p_name, s_state):
    """Check if piece named p_name at position (r_start, c_start) fits."""
    blocks = build_piece_blocks(p_name, s_state)
    for br, bc in blocks:
        tr, tc = r_start + br, c_start + bc
        if tr < 0 or tr >= ROWS or tc < 0 or tc >= COLS:
            return False
        if board[tr][tc] != '.':
            return False
    return True


class Board:
    """The game board as list of lists, '.' for empty cells."""
    
    R = ROWS
    C = COLS
    
    def __init__(self):
        self.grid = [['.'] * self.C for _ in range(self.R)]
    
    def place_at(self, name, r_start, c_start, s_state, is_locked=True):
        """Place blocks on board."""
        marker = LOCKED_CHARS[name]
        
        # Lock all positions
        locked_pos = []
        for br, bc in build_piece_blocks(name, s_state):
            lr, lc = r_start + br, c_start + bc
            locked_pos.append((lr, lc))
        
        for lr, lc in locked_pos:
            if lr < 0 or lr >= ROWS or lc < 0 or lc >= COLS:
                continue
            at_edge = (lr == 0 or lr == ROWS-1 or lc == 0 or lc == COLS-1)
            ch = '#' if at_edge else marker.upper()
            
            if self.grid[lr][lc] == '.':
                self.grid[lr][lc] = ch
            else:
                return False  # Collision
        
        return True
    
    def remove_full_lines(self):
        """Remove full lines from bottom up. Returns count cleared."""
        count = 0
        kept = []
        
        # Scan from bottom to top
        for i in range(ROWS - 1, -1, -1):
            row_str = ''.join(self.grid[i])
            
            is_full = True
            for ch in row_str:
                if ch != '.':  # Any non-empty cell means not a full line
                    is_full = False
                    break
            
            if is_full:
                count += 1
            else:
                kept.append(row_str)
        
        # Rebuild board
        result = kept[:]
        while len(result) < ROWS:
            result.insert(0, ['.'] * COLS)
        
        self.grid = result[:ROWS]
        
        return count


def main():
    lines_input = sys.stdin.read().splitlines()
    
    game = GameInstance()
    
    # First line is piece sequence
    seq_line = ''
    if lines_input:
        seq_line = lines_input[0]
    
    for c in seq_line:
        game.piece_queue.append(c)
    
    # Spawn first piece before processing commands
    game.spawn_first()
    
    # Process remaining command tokens
    for line_num in range(1, len(lines_input)):
        line = lines_input[line_num]
        tokens = line.split()
        
        for tok in tokens:
            tok = tok.strip()
            if tok:
                game.handle_cmd(tok)
    
    # Print final output
    print_board(game.board)
    status_line(f"{game.score}", f"{game.lines_total}", game.game_status())
    
    print('\n'.join(final_output()))


def print_board(board):
    """Print board rows."""
    global final_output_list
    final_output_list.append('')
    for r in board.grid:
        final_output_list.append(r)


def status_line(score, total_lines, status):
    """Add status line to output."""
    global final_output_list
    final_output_list.append(f"SCORE {score} LINES {total_lines} {status}")


final_output_list = []


class GameInstance:
    """Complete game state."""
    
    def __init__(self):
        self.board = Board()
        self.active_piece = None  # Current active piece
        self.queue = []  # List of upcoming piece names
        self.next_idx = 0  # Index into queue
        self.status = 'PLAYING'  # PLAYING, OVER, DONE
        self.score = 0
        self.lines_cleared = 0
        self.active_row = None   # Row of active piece
        self.active_col = None   # Col of active piece
        self.active_state = 0    # State/rotation of active piece
    
    def spawn_next(self):
        """Spawn next piece from queue. Return True if successful."""
        if self.status == 'OVER':
            return False
        
        if self.next_idx >= len(self.queue):
            self.status = 'DONE'
            return False
        
        name = self.queue[self.next_idx]
        self.queue[self.next_idx] = None
        self.next_idx += 1
        
        # Try column offsets -1, 1, -2, 2
        found = False
        col_offs = [-1, 1, -2, 2]
        
        for oc in col_offs:
            test_p = Piece(name)
            test_p.col = START_COL + oc
            test_p.state = 0  # Always try spawning in state 0
            
            if check_position_fits(self.board, test_p.row, test_p.col, name, 0):
                self.active_piece = test_p
                found = True
                break
        
        if not found:
            self.active_piece = None
            self.status = 'OVER'
            return False
        
        # Place the active piece on the board
        lock_piece(self.active_piece, is_locked=True)
        
        return True
    
    def rotate_clockwise(self):
        """Try rotating CW. Returns True if rotation succeeded."""
        if self.status == 'OVER' or self.active_piece is None:
            return False
        
        target_s = (self.active_piece.state + 1) % 4
        
        # First try at current position
        if check_position_fits(
            self.board, 
            self.active_piece.row, 
            self.active_piece.col, 
            self.active_piece.char, 
            target_s
        ):
            self.active_piece.state = target_s
            return True
        
        # Then try shifted columns
        col_offsets = [-1, 1, -2, 2]
        for off in col_offsets:
            new_pc = self.active_piece.col + off
            if check_position_fits(
                self.board,
                self.active_piece.row,
                new_pc,
                self.active_piece.char,
                target_s
            ):
                self.active_piece.state = target_s
                self.active_piece.col = new_pc
                return True
        
        return False
    
    def rotate_counterclockwise(self):
        """Try rotating CCW. Returns True if rotation succeeded."""
        if self.status == 'OVER' or self.active_piece is None:
            return False
        
        target_s = (self.active_piece.state + 3) % 4
        
        # First try at current position
        if check_position_fits(
            self.board,
            self.active_piece.row,
            self.active_piece.col,
            self.active_piece.char,
            target_s
        ):
            self.active_piece.state = target_s
            return True
        
        # Then try shifted columns
        col_offsets = [-1, 1, -2, 2]
        for off in col_offsets:
            new_pc = self.active_piece.col + off
            if check_position_fits(
                self.board,
                self.active_piece.row,
                new_pc,
                self.active_piece.char,
                target_s
            ):
                self.active_piece.state = target_s
                self.active_piece.col = new_pc
                return True
        
        return False
    
    def try_move_left(self):
        """Try moving left. Return True if moved."""
        if self.status == 'OVER' or self.active_piece is None:
            return False
        
        test_p = Piece(self.active_piece.char)
        test_p.row = self.active_piece.row
        test_p.col = self.active_piece.col - 1
        test_p.state = self.active_piece.state
        
        if check_position_fits(self.board, test_p.row, test_p.col, test_p.char, test_p.state):
            self.active_piece.col -= 1
            return True
        return False
    
    def try_move_right(self):
        """Try moving right. Return True if moved."""
        if self.status == 'OVER' or self.active_piece is None:
            return False
        
        test_p = Piece(self.active_piece.char)
        test_p.row = self.active_piece.row
        test_p.col = self.active_piece.col + 1
        test_p.state = self.active_piece.state
        
        if check_position_fits(self.board, test_p.row, test_p.col, test_p.char, test_p.state):
            self.active_piece.col += 1
            return True
        return False
    
    def move_down_one_or_lock(self):
        """Try to move down one. If doesn't fit, lock immediately. Return True if anything happened."""
        if self.status == 'OVER' or self.active_piece is None:
            return False
        
        test_p = Piece(self.active_piece.char)
        test_p.row = self.active_piece.row + 1
        test_p.col = self.active_piece.col
        test_p.state = self.active_piece.state
        
        if check_position_fits(self.board, test_p.row, test_p.col, test_p.char, test_p.state):
            self.active_piece.row += 1
            self.score += 1
        else:
            lock_piece(self.active_piece, is_locked=True)
        
        return True
    
    def hard_drop(self):
        """Drop piece down until it locks. Add 2 points per drop step."""
        if self.status == 'OVER' or self.active_piece is None:
            return
        
        name = self.active_piece.char
        steps = 0
        
        curr_r = self.active_piece.row
        while True:
            test_p = Piece(name)
            test_p.row = curr_r + steps + 1
            test_p.col = self.active_piece.col
            test_p.state = self.active_piece.state
            
            if check_position_fits(self.board, test_p.row, test_p.col, test_p.char, test_p.state):
                curr_r = test_p.row
                steps += 1
                self.score += 2
            else:
                break
        
        self.active_piece.row = curr_r
        lock_piece(self.active_piece, is_locked=True)
    
    def handle_cmd(self, cmd):
        """Handle a single command token."""
        if self.status == 'OVER':
            return False
        
        if cmd == 'P':
            print_board(self.board)
            out_lines.append(f"SCORE {self.score} LINES {self.lines_cleared} {self.status}")
            return True
        
        if self.active_piece is None:
            return False
        
        if cmd == 'L':
            self.try_move_left()
            return True
        
        elif cmd == 'R':
            self.try_move_right()
            return True
        
        elif cmd == 'D':
            if self.move_down_one_or_lock():
                return True
        
        elif cmd == 'H':
            self.hard_drop()
            return True
        
        elif cmd == 'CW':
            if self.rotate_clockwise():
                return True
            return False
        
        elif cmd == 'CCW':
            if self.rotate_counterclockwise():
                return True
            return False
        
        else:
            print(f"error: unknown command {cmd}", file=sys.stderr)
            return False
    
    def lock_piece_now(self):
        """Lock the active piece onto the board."""
        piece = self.active_piece
        num_cleared = self.board.remove_full_lines()
        self.lines_cleared += num_cleared
        self.score += SCORE_TABLE[num_cleared]
    
    def game_over_check(self):
        """Check if no more pieces can be spawned. Return 'OVER' if yes."""
        if self.next_idx >= len(self.queue):
            self.status = 'DONE'
            return True
        return False
    
    def get_active_info(self):
        """Get info about active piece as dict."""
        if self.active_piece is None:
            return {'name': None, 'row': 0, 'col': 0, 'state': 0}
        return {
            'name': self.active_piece.char,
            'row': self.active_piece.row,
            'col': self.active_piece.col,
            'state': self.active_piece.state
        }
    
    def finalize(self):
        """Finalize game - ensure we have output for end state."""
        status = 'DONE' if self.active_piece is None and self.status == 'DONE' else self.status
        return status


def lock_piece(piece, is_locked=True):
    """Place a piece's blocks on the board."""
    marker = LOCKED_CHARS[piece.char]
    
    for br, bc in build_piece_blocks(piece.char, piece.state):
        lr, lc = piece.row + br, piece.col + bc
        if lr < 0 or lr >= ROWS or lc < 0 or lc >= COLS:
            continue
        board.grid[lr][lc] = marker.upper() if is_locked else marker.lower()
    return True


def print_board(board):
    """Print board to stdout."""
    output_lines.append("")
    for row in board.grid:
        output_lines.append("".join(row))


def status_line(score, total_lines, st):
    """Create status line string."""
    output_lines.append(f"SCORE {score} LINES {total_lines} {st}")


output_lines = []
