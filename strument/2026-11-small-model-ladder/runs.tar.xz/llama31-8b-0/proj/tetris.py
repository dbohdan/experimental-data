        def print_grid(self):
            for row in self.grid:
                print(' '.join(str(cell) for cell in row))


from rich import print

class Tetris:
    def __init__(self):
        self.grid = [[0 for _ in range(10)] for _ in range(20)]

class Tetrimino:
    def __init__(self):
        self.shape = 0

    def position(self):
        for x, y in range(self.shape):
            yield x, y


