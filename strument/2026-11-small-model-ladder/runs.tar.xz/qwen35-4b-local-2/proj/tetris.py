#!/usr/bin/env python3
"""Headless Tetris - plays from commands on stdin, prints board to stdout."""

# Piece shapes: for each piece and state, list of (r, c) offsets in a 4x4 box
PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],  # state 0
        [(0, 2), (1, 2), (2, 2), (3, 2)],  # state 1
        [(2, 0), (2, 1), (2, 2), (2, 3)],  # state 2
        [(0, 1), (1, 1), (2, 1), (3, 1)],  # state 3
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],  # state 0
        [(0, 1), (1, 1), (1, 2), (2, 1)],  # state 1
        [(1, 0), (1, 1), (1, 2), (2, 1)],  # state 2
        [(0, 1), (1, 0), (1, 1), (2, 1)],  # state 3
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],  # state 0
        [(0, 1), (1, 1), (1, 2), (2, 2)],  # state 1
        [(1, 1), (1, 2), (2, 0), (2, 1)],  # state 2
        [(0, 0), (1, 0), (1, 1), (2, 1)],  # state 3
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],  # state 0
        [(0, 2), (1, 1), (1, 2), (2, 1)],  # state 1
        [(1, 0), (1, 1), (2, 1), (2, 2)],  # state 2
        [(0, 1), (1, 0), (1, 1), (2, 0)],  # state 3
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],  # state 0
        [(0, 1), (0, 2), (1, 1), (2, 1)],  # state 1
        [(1, 0), (1, 1), (1, 2), (2, 2)],  # state 2
        [(0, 1), (1, 1), (2, 0), (2, 1)],  # state 3
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],  # state 0
        [(0, 1), (1, 1), (2, 1), (2, 2)],  # state 1
        [(1, 0), (1, 1), (1, 2), (2, 0)],  # state 2
        [(0, 0), (0, 1), (1, 1), (2, 1)],  # state 3
    ],
}

# Score for clearing rows
CLEAR_SCORES = {1: 100, 2: 300, 3: 500, 4: 800}

# Board dimensions
BOARD_WIDTH = 10
BOARD_HEIGHT = 20


def piece_blocks(piece, state, pos_row, pos_col):
    """Return list of (board_row, board_col) for all blocks of the piece."""
    blocks = PIECES[piece][state]
    result = []
    for dr, dc in blocks:
        result.append((pos_row + dr, pos_col + dc))
    return result


def fits(piece, state, pos_row, pos_col, board):
    """Check if piece fits at position and state on the given board."""
    blocks = piece_blocks(piece, state, pos_row, pos_col)
    for br, bc in blocks:
        # Outside board
        if br < 0 or br >= BOARD_HEIGHT or bc < 0 or bc >= BOARD_WIDTH:
            return False
        # Cell already occupied
        if board[br][bc] != '.':
            return False
    return True


def place_piece(piece, state, pos_row, pos_col, board):
    """Lock piece onto the board, return new board."""
    blocks = piece_blocks(piece, state, pos_row, pos_col)
    new_board = [list(row) for row in board]
    for br, bc in blocks:
        new_board[br][bc] = piece
    return new_board


def clear_rows(board):
    """Clear full rows and shift down, return (new_board, rows_cleared)."""
    board = [list(row) for row in board]
    rows_to_remove = []
    for row in board:
        if all(cell != '.' for cell in row):
            rows_to_remove.append(board.pop(0))
    
    # Pad with empty rows at top
    while len(board) < BOARD_HEIGHT:
        board.insert(0, ['.' * BOARD_WIDTH])
    
    # Truncate to BOARD_HEIGHT
    board = board[:BOARD_HEIGHT]
    
    return board, len(rows_to_remove)


def print_board(board):
    """Print board to stdout."""
    for row in board:
        print(''.join(row))


def process_game(input_lines):
    """Process the game from input lines, return (final_board, score, lines_cleared, state)."""
    # Parse input: first line is piece sequence, rest are commands
    input_lines = [line.strip() for line in input_lines]
    input_lines = [line for line in input_lines if line]  # Remove empty lines
    
    if not input_lines:
        return None, 0, 0, 'DONE'
    
    piece_sequence = input_lines[0]
    commands = input_lines[1:]
    
    # Initialize board
    board = [('.' * BOARD_WIDTH) for _ in range(BOARD_HEIGHT)]
    
    # Current piece state
    current_piece = None
    current_state = 0
    current_pos = (0, 3)  # row, col
    
    score = 0
    lines_cleared = 0
    state = 'PLAYING'
    
    # Process commands
    for cmd in commands:
        if current_piece is None:
            # No piece in play, ignore commands except P
            if cmd == 'P':
                print_board(board)
                print(f"SCORE {score} LINES {lines_cleared} {state}")
            continue
        
        if cmd == 'L':
            if fits(current_piece, current_state, current_pos[0], current_pos[1] - 1, board):
                current_pos = (current_pos[0], current_pos[1] - 1)
        elif cmd == 'R':
            if fits(current_piece, current_state, current_pos[0], current_pos[1] + 1, board):
                current_pos = (current_pos[0], current_pos[1] + 1)
        elif cmd == 'D':
            if fits(current_piece, current_state, current_pos[0] + 1, current_pos[1], board):
                current_pos = (current_pos[0] + 1, current_pos[1])
                score += 1
            else:
                # Lock instead
                board = place_piece(current_piece, current_state, current_pos[0], current_pos[1], board)
                board, lines_cleared = clear_rows(board)
                score += CLEAR_SCORES.get(lines_cleared, 0)
                lines_cleared = 0
                # Spawn next piece
                if len(piece_sequence) > len(current_piece_sequence_index):
                    current_piece = piece_sequence[len(current_piece_sequence_index)]
                    current_piece_sequence_index += 1
                    current_state = 0
                    current_pos = (0, 3)
                else:
                    state = 'DONE'
        elif cmd == 'H':
            # Hard drop: move down as far as possible
            rows_moved = 0
            while fits(current_piece, current_state, current_pos[0] + 1, current_pos[1], board):
                current_pos = (current_pos[0] + 1, current_pos[1])
                rows_moved += 1
            # Lock
            board = place_piece(current_piece, current_state, current_pos[0], current_pos[1], board)
            board, lines_cleared = clear_rows(board)
            score += CLEAR_SCORES.get(lines_cleared, 0) * 2
            lines_cleared = 0
            # Spawn next piece
            if len(piece_sequence) > len(current_piece_sequence_index):
                current_piece = piece_sequence[len(current_piece_sequence_index)]
                current_piece_sequence_index += 1
                current_state = 0
                current_pos = (0, 3)
            else:
                state = 'DONE'
        elif cmd == 'CW':
            new_state = (current_state + 1) % 4
            if (new_state == current_state and fits(current_piece, new_state, current_pos[0], current_pos[1], board)):
                # Check with column shifts
                for shift in [-1, 1, -2, 2]:
                    if fits(current_piece, new_state, current_pos[0], current_pos[1] + shift, board):
                        current_state = new_state
                        current_pos = (current_pos[0], current_pos[1] + shift)
                        break
        elif cmd == 'CCW':
            new_state = (current_state + 3) % 4
            if (new_state == current_state and fits(current_piece, new_state, current_pos[0], current_pos[1], board)):
                # Check with column shifts
                for shift in [-1, 1, -2, 2]:
                    if fits(current_piece, new_state, current_pos[0], current_pos[1] + shift, board):
                        current_state = new_state
                        current_pos = (current_pos[0], current_pos[1] + shift)
                        break
        elif cmd == 'P':
            print_board(board)
            print(f"SCORE {score} LINES {lines_cleared} {state}")
        else:
            print(f"error: unknown command {cmd}", file=__import__('sys').stderr)
    
    # Print final output
    print_board(board)
    print(f"SCORE {score} LINES {lines_cleared} {state}")
    
    return board, score, lines_cleared, state


def main():
    import sys
    
    # Read all input
    input_data = sys.stdin.read().splitlines()
    
    result = process_game(input_data)
    
    if result is not None:
        _, score, lines, state = result
        sys.exit(0)


if __name__ == '__main__':
    main()
