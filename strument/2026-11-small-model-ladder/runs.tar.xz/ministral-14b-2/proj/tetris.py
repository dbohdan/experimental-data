#!/usr/bin/env python3

import sys
from collections import defaultdict

# Piece definitions: (r, c) offsets for each state (0-3)
PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)]
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)]
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)]
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)]
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)]
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)]
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)]
    ]
}

# Score table for clearing lines
SCORE_TABLE = {
    1: 100,
    2: 300,
    3: 500,
    4: 800
}

class Tetris:
    def __init__(self):
        self.board = [['.' for _ in range(10)] for _ in range(20)]
        self.score = 0
        self.lines_cleared = 0
        self.piece_sequence = []
        self.current_piece = None
        self.current_state = 0
        self.current_row = 0
        self.current_col = 3
        self.game_over = False
        self.game_done = False

    def spawn_piece(self, piece_type):
        if self.game_over or self.game_done:
            return False

        self.current_piece = piece_type
        self.current_state = 0
        self.current_row = 0
        self.current_col = 3

        if not self.is_valid_position():
            self.game_over = True
            return False

        return True

    def is_valid_position(self):
        if self.current_piece is None:
            return False

        piece_shapes = PIECES[self.current_piece][self.current_state]
        for (r, c) in piece_shapes:
            board_r = self.current_row + r
            board_c = self.current_col + c
            if (
                board_r < 0 or board_r >= 20 or 
                board_c < 0 or board_c >= 10 or
                (board_r >= 0 and self.board[board_r][board_c] != '.')
            ):
                return False
        return True

    def move(self, dr, dc):
        if self.game_over or self.game_done or self.current_piece is None:
            return False

        self.current_row += dr
        self.current_col += dc

        if not self.is_valid_position():
            self.current_row -= dr
            self.current_col -= dc
            return False

        return True

    def rotate(self, clockwise=True):
        if self.game_over or self.game_done or self.current_piece is None:
            return False

        new_state = (self.current_state + (1 if clockwise else 3)) % 4
        piece_shapes = PIECES[self.current_piece][new_state]

        # Try rotating at current position
        if self.is_valid_position_with_state(new_state):
            self.current_state = new_state
            return True

        # Try rotating with column shifts
        for dc in [-1, 1, -2, 2]:
            self.current_col += dc
            if self.is_valid_position_with_state(new_state):
                self.current_state = new_state
                return True
            self.current_col -= dc

        return False

    def is_valid_position_with_state(self, state):
        piece_shapes = PIECES[self.current_piece][state]
        for (r, c) in piece_shapes:
            board_r = self.current_row + r
            board_c = self.current_col + c
            if (
                board_r < 0 or board_r >= 20 or 
                board_c < 0 or board_c >= 10 or
                (board_r >= 0 and self.board[board_r][board_c] != '.')
            ):
                return False
        return True

    def hard_drop(self):
        if self.game_over or self.game_done or self.current_piece is None:
            return False

        original_row = self.current_row
        rows_dropped = 0
        while True:
            self.current_row += 1
            if not self.is_valid_position():
                self.current_row -= 1
                break
            rows_dropped += 1

        if rows_dropped == 0:
            return False

        self.score += 2 * rows_dropped
        self.lock_piece()
        return True

    def lock_piece(self):
        if self.game_over or self.game_done or self.current_piece is None:
            return False

        piece_shapes = PIECES[self.current_piece][self.current_state]
        for (r, c) in piece_shapes:
            board_r = self.current_row + r
            board_c = self.current_col + c
            if 0 <= board_r < 20 and 0 <= board_c < 10:
                self.board[board_r][board_c] = self.current_piece.lower()

        lines_cleared = self.clear_lines()
        self.current_piece = None
        return True

    def clear_lines(self):
        lines_to_clear = []
        for r in range(20):
            if all(cell != '.' for cell in self.board[r]):
                lines_to_clear.append(r)

        if not lines_to_clear:
            return 0

        lines_cleared = len(lines_to_clear)
        self.score += SCORE_TABLE.get(lines_cleared, 0)
        self.lines_cleared += lines_cleared

        # Remove cleared lines and add new empty lines
        for r in sorted(lines_to_clear, reverse=True):
            del self.board[r]
            self.board.insert(0, ['.' for _ in range(10)])

        return lines_cleared

    def print_board(self):
        for row in self.board:
            print(''.join(row))
        state = 'PLAYING' if self.current_piece is not None else 'OVER' if self.game_over else 'DONE'
        print(f"SCORE {self.score} LINES {self.lines_cleared} {state}")

    def process_command(self, cmd):
        if self.game_over or self.game_done:
            if cmd != 'P':
                return

        if cmd == 'L':
            self.move(0, -1)
        elif cmd == 'R':
            self.move(0, 1)
        elif cmd == 'D':
            if self.move(1, 0):
                self.score += 1
            else:
                self.lock_piece()
        elif cmd == 'H':
            self.hard_drop()
        elif cmd == 'CW':
            self.rotate(True)
        elif cmd == 'CCW':
            self.rotate(False)
        elif cmd == 'P':
            self.print_board()
        else:
            print(f"error: unknown command {cmd}", file=sys.stderr)

    def run(self, input_lines):
        if not input_lines:
            return

        self.piece_sequence = list(input_lines[0].strip())
        commands = ' '.join(input_lines[1:]).split()

        if not self.spawn_piece(self.piece_sequence[0]):
            self.game_over = True

        for cmd in commands:
            self.process_command(cmd)

        if not self.game_over and self.current_piece is None:
            self.game_done = True

        self.print_board()


def main():
    tetris = Tetris()
    input_lines = [line.strip() for line in sys.stdin if line.strip()]
    tetris.run(input_lines)


if __name__ == "__main__":
    main()