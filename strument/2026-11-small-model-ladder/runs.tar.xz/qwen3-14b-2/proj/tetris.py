import sys
import os

def main():
    # Read input
    input_lines = [line.rstrip('\r\n') for line in sys.stdin]
    
    # Parse piece sequence
    if not input_lines:
        sys.exit(0)
    
    piece_seq = input_lines[0]
    commands = []
    for line in input_lines[1:]:
        commands.extend(line.split())
    
    # Initialize board
    board = [['.' for _ in range(10)] for _ in range(20)]
    
    # Piece definitions
    PIECES = {
        'I': [
            [(1,0), (1,1), (1,2), (1,3)],
            [(0,2), (1,2), (2,2), (3,2)],
            [(2,0), (2,1), (2,2), (2,3)],
            [(0,1), (1,1), (2,1), (3,1)]
        ],
        'O': [
            [(0,1), (0,2), (1,1), (1,2)] for _ in range(4)
        ],
        'T': [
            [(0,1), (1,0), (1,1), (1,2)],
            [(0,1), (1,1), (1,2), (2,1)],
            [(1,0), (1,1), (1,2), (2,1)],
            [(0,1), (1,0), (1,1), (2,1)]
        ],
        'S': [
            [(0,1), (0,2), (1,0), (1,1)],
            [(0,1), (1,1), (1,2), (2,2)],
            [(1,1), (1,2), (2,0), (2,1)],
            [(0,0), (1,0), (1,1), (2,1)]
        ],
        'Z': [
            [(0,0), (0,1), (1,1), (1,2)],
            [(0,2), (1,1), (1,2), (2,1)],
            [(1,0), (1,1), (2,1), (2,2)],
            [(0,1), (1,0), (1,1), (2,0)]
        ],
        'J': [
            [(0,0), (1,0), (1,1), (1,2)],
            [(0,1), (0,2), (1,1), (2,1)],
            [(1,0), (1,1), (1,2), (2,2)],
            [(0,1), (1,1), (2,0), (2,1)]
        ],
        'L': [
            [(0,2), (1,0), (1,1), (1,2)],
            [(0,1), (1,1), (2,1), (2,2)],
            [(1,0), (1,1), (1,2), (2,0)],
            [(0,0), (0,1), (1,1), (2,1)]
        ]
    }
    
    # Game state
    score = 0
    lines_cleared = 0
    game_status = 'PLAYING'
    current_piece = None
    current_pos = (0, 3)
    current_state = 0
    piece_index = 0
    
    def is_valid(piece_type, pos, state):
        r, c = pos
        for dr, dc in PIECES[piece_type][state]:
            nr, nc = r + dr, c + dc
            if not (0 <= nr < 20 and 0 <= nc < 10):
                return False
            if board[nr][nc] != '.':
                return False
        return True
    
    def place_piece(piece_type, pos, state):
        r, c = pos
        for dr, dc in PIECES[piece_type][state]:
            nr, nc = r + dr, c + dc
            board[nr][nc] = piece_type
    
    def clear_lines():
        nonlocal lines_cleared, score
        full_rows = []
        for r in range(20):
            if all(cell != '.' for cell in board[r]):
                full_rows.append(r)
        
        if not full_rows:
            return
        
        lines_cleared += len(full_rows)
        score += {1: 100, 2: 300, 3: 500, 4: 800}[len(full_rows)]
        
        # Remove full rows and shift down
        for r in full_rows:
            del board[r]
            board.insert(0, ['.'] * 10)
    
    def print_board():
        # Create a temporary board with the current piece
        temp_board = [row[:] for row in board]
        if current_piece is not None:
            r, c = current_pos
            for dr, dc in PIECES[current_piece][current_state]:
                nr, nc = r + dr, c + dc
                if 0 <= nr < 20 and 0 <= nc < 10:
                    temp_board[nr][nc] = current_piece.lower()
        # Print the board
        for row in temp_board:
            print(''.join(row))
        print(f'SCORE {score} LINES {lines_cleared} {game_status}')
    
    # Spawn initial piece
    if piece_seq:
        current_piece = piece_seq[0]
        piece_index = 1
        if not is_valid(current_piece, current_pos, current_state):
            game_status = 'OVER'
    
    # Process commands
    for cmd in commands:
        if game_status != 'PLAYING' and cmd != 'P':
            continue
        
        if cmd == 'P':
            print_board()
            continue
        
        if current_piece is None:
            continue
        
        if cmd == 'L':
            new_pos = (current_pos[0], current_pos[1] - 1)
            if is_valid(current_piece, new_pos, current_state):
                current_pos = new_pos
        elif cmd == 'R':
            new_pos = (current_pos[0], current_pos[1] + 1)
            if is_valid(current_piece, new_pos, current_state):
                current_pos = new_pos
        elif cmd == 'D':
            new_pos = (current_pos[0] + 1, current_pos[1])
            if is_valid(current_piece, new_pos, current_state):
                current_pos = new_pos
                score += 1
            else:
                place_piece(current_piece, current_pos, current_state)
                clear_lines()
                current_piece = None
                if piece_index < len(piece_seq):
                    current_piece = piece_seq[piece_index]
                    piece_index += 1
                    current_pos = (0, 3)
                    current_state = 0
                    if not is_valid(current_piece, current_pos, current_state):
                        game_status = 'OVER'
                else:
                    game_status = 'DONE'
        elif cmd == 'H':
            move_count = 0
            while True:
                new_pos = (current_pos[0] + 1, current_pos[1])
                if is_valid(current_piece, new_pos, current_state):
                    current_pos = new_pos
                    move_count += 1
                    score += 2
                else:
                    break
            place_piece(current_piece, current_pos, current_state)
            clear_lines()
            current_piece = None
            if piece_index < len(piece_seq):
                current_piece = piece_seq[piece_index]
                piece_index += 1
                current_pos = (0, 3)
                current_state = 0
                if not is_valid(current_piece, current_pos, current_state):
                    game_status = 'OVER'
            else:
                game_status = 'DONE'
        elif cmd == 'CW':
            new_state = (current_state + 1) % 4
            # Try rotation at current position
            if is_valid(current_piece, current_pos, new_state):
                current_state = new_state
            else:
                # Try shifting left, right, left twice, right twice
                for shift in [-1, 1, -2, 2]:
                    new_pos = (current_pos[0], current_pos[1] + shift)
                    if is_valid(current_piece, new_pos, new_state):
                        current_pos = new_pos
                        current_state = new_state
                        break
        elif cmd == 'CCW':
            new_state = (current_state + 3) % 4
            # Try rotation at current position
            if is_valid(current_piece, current_pos, new_state):
                current_state = new_state
            else:
                # Try shifting left, right, left twice, right twice
                for shift in [-1, 1, -2, 2]:
                    new_pos = (current_pos[0], current_pos[1] + shift)
                    if is_valid(current_piece, new_pos, new_state):
                        current_pos = new_pos
                        current_state = new_state
                        break
        else:
            print(f'error: unknown command {cmd}', file=sys.stderr)
    
    # Final print
    print_board()

if __name__ == '__main__':
    main()