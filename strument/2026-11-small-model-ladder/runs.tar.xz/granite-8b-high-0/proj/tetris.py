#!/usr/bin/env python3
"""Headless Tetris according to SPEC.md."""

import sys

# Piece offsets from SPEC.md table (piece, state -> list of (r,c) offsets)
PIECE_OFFSETS = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],  # state 0
        [(0, 2), (1, 2), (2, 2), (3, 2)], # state 1
        [(2, 0), (2, 1), (2, 2), (2, 3)], # state 2
        [(0, 1), (1, 1), (2, 1), (3, 1)],  # state 3
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)], # state 0-3 all same
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)], # state 0
        [(0, 1), (1, 1), (1, 2), (2, 1)], # state 1
        [(1, 0), (1, 1), (1, 2), (2, 1)], # state 2
        [(0, 1), (1, 0), (1, 1), (2, 1)], # state 3
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)], # state 0
        [(0, 1), (1, 1), (1, 2), (2, 2)], # state 1
        [(1, 1), (1, 2), (2, 0), (2, 1)], # state 2
        [(0, 0), (1, 0), (1, 1), (2, 1)], # state 3
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)], # state 0
        [(0, 2), (1, 1), (1, 2), (2, 1)], # state 1
        [(1, 0), (1, 1), (2, 1), (2, 2)], # state 2
        [(0, 1), (1, 0), (1, 1), (2, 0)], # state 3
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)], # state 0
        [(0, 1), (0, 2), (1, 1), (2, 1)], # state 1
        [(1, 0), (1, 1), (1, 2), (2, 2)], # state 2
        [(0, 1), (1, 1), (2, 0), (2, 1)], # state 3
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)], # state 0
        [(0, 1), (1, 1), (2, 1), (2, 2)], # state 1
        [(1, 0), (1, 1), (1, 2), (2, 0)], # state 2
        [(0, 0), (0, 1), (1, 1), (2, 1)], # state 3
    ],
}

def fits(board, piece_type, state, row, col):
    """Check if piece fits at (row, col) with given state.
    board is 20x10 list of chars, where '.' = empty, uppercase = locked.
    Assumes current piece is NOT on board (we clear it before calling).
    Returns True if all blocks land on board and on empty cells ('.').
    """
    offsets = PIECE_OFFSETS[piece_type][state]
    for dr, dc in offsets:
        r = row + dr
        c = col + dc
        if r < 0 or r >= 20 or c < 0 or c >= 10:
            return False
        if board[r][c] != '.':
            return False
    return True

def place_piece(board, piece_type, state, row, col, lowercase=True):
    """Place piece on board at (row, col) with given state.
    If lowercase=True, place as lowercase (current piece); otherwise place as uppercase (locked).
    """
    offsets = PIECE_OFFSETS[piece_type][state]
    for dr, dc in offsets:
        r = row + dr
        c = col + dc
        if lowercase:
            board[r][c] = piece_type.lower()
        else:
            board[r][c] = piece_type  # uppercase locked

def clear_piece(board, row, col, state, piece_type):
    """Remove piece from board (set to '.')."""
    offsets = PIECE_OFFSETS[piece_type][state]
    for dr, dc in offsets:
        r = row + dr
        c = col + dc
        board[r][c] = '.'

def lock_piece(board, piece_type, state, row, col):
    """Lock the piece (place as uppercase), clear full rows, update board.
    Returns (board, score_delta, rows_cleared).
    score_delta includes row-clear score (100/300/500/800 per row).
    """
    # Place as uppercase
    place_piece(board, piece_type, state, row, col, lowercase=False)
    
    # Find full rows (all 10 cells are not '.')
    full_rows = []
    for i in range(20):
        if all(board[i][j] != '.' for j in range(10)):
            full_rows.append(i)
    if not full_rows:
        return board, 0, 0
    
    # Score for row clear
    num_full = len(full_rows)
    if num_full == 1:
        score_delta = 100
    elif num_full == 2:
        score_delta = 300
    elif num_full == 3:
        score_delta = 500
    elif num_full == 4:
        score_delta = 800
    else:
        # Should not happen
        score_delta = 0
    
    # Remove full rows and insert empty rows at top
    non_full = [i for i in range(20) if i not in full_rows]
    new_board = [['.'] * 10 for _ in range(20)]
    for orig_i in non_full:
        # count full rows above orig_i
        above_full = sum(1 for fr in full_rows if fr < orig_i)
        new_i = orig_i - above_full
        for j in range(10):
            new_board[new_i][j] = board[orig_i][j]
    return new_board, score_delta, num_full

def print_game(board, score, lines_cleared_total, state):
    """Print board (20 lines of 10 chars) and SCORE line."""
    for row in board:
        sys.stdout.write(''.join(row) + '\n')
    sys.stdout.write(f"SCORE {score} LINES {lines_cleared_total} {state}\n")

def main():
    data = sys.stdin.read().strip()
    if not data:
        board = [['.'] * 10 for _ in range(20)]
        print_game(board, 0, 0, "DONE")
        return
    
    tokens = data.split()
    if len(tokens) < 1:
        return
    piece_seq = tokens[0]
    commands = tokens[1:]
    
    # Game state
    board = [['.'] * 10 for _ in range(20)]  # 20 rows, 10 cols
    state = "PLAYING"  # "PLAYING", "OVER", "DONE"
    score = 0
    lines_cleared_total = 0
    next_piece_idx = 0  # index in piece_seq for next piece to spawn
    # Current piece info, or None
    current = None  # dict: {'type': str, 'state': int, 'row': int, 'col': int}
    
    # Spawn first piece if sequence not empty
    if piece_seq:
        first_piece = piece_seq[0]
        # Try spawn at (0, 3) state 0
        if fits(board, first_piece, 0, 0, 3):
            current = {'type': first_piece, 'state': 0, 'row': 0, 'col': 3}
            place_piece(board, first_piece, 0, 0, 3, lowercase=True)
            next_piece_idx = 1
        else:
            # Spawn fails, game over
            state = "OVER"
    
    # Process commands
    for cmd in commands:
        if state == "OVER" or state == "DONE":
            if cmd == "P":
                print_game(board, score, lines_cleared_total, state)
            # ignore all other commands (including unknown)
            continue
        
        if current is None:
            # No piece in play (should only happen if state == OVER), ignore except P
            if cmd != "P":
                sys.stderr.write(f"error: unknown command {cmd}\n")
            continue
        
        if cmd == "P":
            # Print current game
            print_game(board, score, lines_cleared_total, state)
            continue
        
        if cmd == "L":
            if fits(board, current['type'], current['state'], current['row'], current['col'] - 1):
                clear_piece(board, current['row'], current['col'], current['state'], current['type'])
                current['col'] -= 1
                place_piece(board, current['type'], current['state'], current['row'], current['col'], lowercase=True)
        elif cmd == "R":
            if fits(board, current['type'], current['state'], current['row'], current['col'] + 1):
                clear_piece(board, current['row'], current['col'], current['state'], current['type'])
                current['col'] += 1
                place_piece(board, current['type'], current['state'], current['row'], current['col'], lowercase=True)
        elif cmd == "D":
            if fits(board, current['type'], current['state'], current['row'] + 1, current['col']):
                # Move down
                clear_piece(board, current['row'], current['col'], current['state'], current['type'])
                current['row'] += 1
                place_piece(board, current['type'], current['state'], current['row'], current['col'], lowercase=True)
            else:
                # Doesn't fit: lock instead, no score for this D
                new_board, score_delta, rows_cleared = lock_piece(board, current['type'], current['state'], current['row'], current['col'])
                score += score_delta
                lines_cleared_total += rows_cleared
                # Spawn next piece if any
                if next_piece_idx < len(piece_seq):
                    piece = piece_seq[next_piece_idx]
                    if fits(new_board, piece, 0, 0, 3):
                        # Spawn at (0,3) state 0
                        current = {'type': piece, 'state': 0, 'row': 0, 'col': 3}
                        place_piece(new_board, piece, 0, 0, 3, lowercase=True)
                        board = new_board
                        # Update next_piece_idx
                        next_piece_idx += 1
                    else:
                        # Spawn fails
                        state = "OVER"
                        board = new_board
                else:
                    # No more pieces
                    board = new_board
                    state = "DONE"
                continue
        elif cmd == "H":
            # Hard drop: find max k such that piece fits at (row+k, col)
            max_k = 0
            for k in range(1, 20):
                if fits(board, current['type'], current['state'], current['row'] + k, current['col']):
                    max_k = k
                else:
                    break
            if max_k > 0:
                # Drop the piece down by max_k
                clear_piece(board, current['row'], current['col'], current['state'], current['type'])
                current['row'] += max_k
                place_piece(board, current['type'], current['state'], current['row'], current['col'], lowercase=True)
                # Score += 2 per row moved
                score += 2 * max_k
            else:
                # Can't drop even one row: lock immediately
                new_board, score_delta, rows_cleared = lock_piece(board, current['type'], current['state'], current['row'], current['col'])
                score += score_delta
                lines_cleared_total += rows_cleared
                # Spawn next piece if any
                if next_piece_idx < len(piece_seq):
                    piece = piece_seq[next_piece_idx]
                    if fits(new_board, piece, 0, 0, 3):
                        current = {'type': piece, 'state': 0, 'row': 0, 'col': 3}
                        place_piece(new_board, piece, 0, 0, 3, lowercase=True)
                        board = new_board
                        next_piece_idx += 1
                    else:
                        state = "OVER"
                        board = new_board
                else:
                    board = new_board
                    state = "DONE"
                continue
        elif cmd == "CW":
            new_state = (current['state'] + 1) % 4
            positions = [(current['row'], current['col']),
                         (current['row'], current['col'] - 1),
                         (current['row'], current['col'] + 1),
                         (current['row'], current['col'] - 2),
                         (current['row'], current['col'] + 2)]
            found = False
            for r, c in positions:
                if fits(board, current['type'], new_state, r, c):
                    clear_piece(board, current['row'], current['col'], current['state'], current['type'])
                    current['row'] = r
                    current['state'] = new_state
                    current['col'] = c
                    place_piece(board, current['type'], current['state'], current['row'], current['col'], lowercase=True)
                    found = True
                    break
            # if not found, nothing happens
        elif cmd == "CCW":
            new_state = (current['state'] + 3) % 4  # (state - 1) mod 4
            positions = [(current['row'], current['col']),
                         (current['row'], current['col'] - 1),
                         (current['row'], current['col'] + 1),
                         (current['row'], current['col'] - 2),
                         (current['row'], current['col'] + 2)]
            found = False
            for r, c in positions:
                if fits(board, current['type'], new_state, r, c):
                    clear_piece(board, current['row'], current['col'], current['state'], current['type'])
                    current['row'] = r
                    current['state'] = new_state
                    current['col'] = c
                    place_piece(board, current['type'], current['state'], current['row'], current['col'], lowercase=True)
                    found = True
                    break
            # if not found, nothing happens
        else:
            # Unknown command
            sys.stderr.write(f"error: unknown command {cmd}\n")
    
    # After processing all commands, print final game state
    print_game(board, score, lines_cleared_total, state)

if __name__ == "__main__":
    main()
