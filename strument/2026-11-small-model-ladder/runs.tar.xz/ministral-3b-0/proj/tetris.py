#!/usr/bin/env python3

import sys
from collections import defaultdict

# Define the pieces and their states
PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],  # State 0
        [(0, 2), (1, 2), (2, 2), (3, 2)],  # State 1
        [(2, 0), (2, 1), (2, 2), (2, 3)],  # State 2
        [(0, 1), (1, 1), (2, 1), (3, 1)],  # State 3
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],  # State 0
        [(0, 1), (0, 2), (1, 1), (1, 2)],  # State 1
        [(0, 1), (0, 2), (1, 1), (1, 2)],  # State 2
        [(0, 1), (0, 2), (1, 1), (1, 2)],  # State 3
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],  # State 0
        [(0, 1), (1, 1), (1, 2), (2, 1)],  # State 1
        [(1, 0), (1, 1), (1, 2), (2, 1)],  # State 2
        [(0, 1), (1, 0), (1, 1), (2, 1)],  # State 3
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],  # State 0
        [(0, 1), (1, 1), (1, 2), (2, 2)],  # State 1
        [(1, 1), (1, 2), (2, 0), (2, 1)],  # State 2
        [(0, 0), (1, 0), (1, 1), (2, 1)],  # State 3
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],  # State 0
        [(0, 2), (1, 1), (1, 2), (2, 1)],  # State 1
        [(1, 0), (1, 1), (2, 1), (2, 2)],  # State 2
        [(0, 1), (1, 0), (1, 1), (2, 0)],  # State 3
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],  # State 0
        [(0, 1), (0, 2), (1, 1), (2, 1)],  # State 1
        [(1, 0), (1, 1), (1, 2), (2, 2)],  # State 2
        [(0, 1), (1, 1), (2, 0), (2, 1)],  # State 3
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],  # State 0
        [(0, 1), (1, 1), (2, 1), (2, 2)],  # State 1
        [(1, 0), (1, 1), (1, 2), (2, 0)],  # State 2
        [(0, 0), (0, 1), (1, 1), (2, 1)],  # State 3
    ],
}

class Tetris:
    def __init__(self):
        self.board = [['.' for _ in range(10)] for _ in range(20)]
        self.score = 0
        self.lines_cleared = 0
        self.state = 'PLAYING'
        self.piece_sequence = []
        self.current_piece = None
        self.current_state = 0
        self.current_position = (0, 3)  # Starting position

    def _can_fit(self, piece_type, state, row, col):
        offsets = PIECES[piece_type][state]
        for r, c in offsets:
            new_row, new_col = row + r, col + c
            if new_row < 0 or new_row >= 20 or new_col < 0 or new_col >= 10:
                return False
            if self.board[new_row][new_col] != '.':
                return False
        return True

    def _rotate_piece(self, piece_type, state):
        # Try rotating the piece and checking if it fits
        for shift in [-1, 1, -2, 2]:
            new_state = (state + 1) % 4
            offsets = PIECES[piece_type][new_state]
            # Check if the rotated piece fits at the current position
            if self._can_fit(piece_type, new_state, self.current_position[0], self.current_position[1]):
                return offsets
        return None

    def _lock_piece(self):
        if not self.current_piece:
            return
        offsets = PIECES[self.current_piece][self.current_state]
        for r, c in offsets:
            row, col = self.current_position[0] + r, self.current_position[1] + c
            if 0 <= row < 20 and 0 <= col < 10:
                self.board[row][col] = self.current_piece.upper()

    def _clear_lines(self):
        # Count lines to clear
        lines_to_clear = 0
        for row in range(19, -1, -1):
            if all(self.board[row][col] != '.' for col in range(10)):
                lines_to_clear += 1
                # Remove the line
                del self.board[row]
                self.board.insert(0, ['.' for _ in range(10)])
        
        if lines_to_clear > 0:
            self.lines_cleared += lines_to_clear
            self.score += {1: 100, 2: 300, 3: 500, 4: 800}[lines_to_clear]

    def _spawn_piece(self):
        if not self.piece_sequence:
            self.state = 'DONE'
            return
        self.current_piece = self.piece_sequence.pop(0)
        self.current_state = 0
        self.current_position = (0, 3)
        if not self._can_fit(self.current_piece, self.current_state, 0, 3):
            self.state = 'OVER'
            return
        
    def move_left(self):
        if self.state != 'PLAYING' or not self.current_piece:
            return
        if self.current_position[1] > 0 and self._can_fit(self.current_piece, self.current_state, self.current_position[0], self.current_position[1] - 1):
            self.current_position = (self.current_position[0], self.current_position[1] - 1)

    def move_right(self):
        if self.state != 'PLAYING' or not self.current_piece:
            return
        if self.current_position[1] < 9 and self._can_fit(self.current_piece, self.current_state, self.current_position[0], self.current_position[1] + 1):
            self.current_position = (self.current_position[0], self.current_position[1] + 1)

    def move_down(self):
        if self.state != 'PLAYING' or not self.current_piece:
            return
        if self.current_position[0] < 19 and self._can_fit(self.current_piece, self.current_state, self.current_position[0] + 1, self.current_position[1]):
            self.current_position = (self.current_position[0] + 1, self.current_position[1])
            self._lock_piece()
            self._clear_lines()
            self.score += 100  # Add score for moving down
            self._spawn_piece()
        else:
            self._lock_piece()
            self._clear_lines()
            self._spawn_piece()

    def hard_drop(self):
        if self.state != 'PLAYING' or not self.current_piece:
            return
        # Move down as far as possible
        rows_moved = 0
        while self.current_position[0] < 19 and self._can_fit(self.current_piece, self.current_state, self.current_position[0] + 1, self.current_position[1]):
            self.current_position = (self.current_position[0] + 1, self.current_position[1])
            rows_moved += 1
        self._lock_piece()
        self._clear_lines()
        self.score += 2 * rows_moved  # Add score for rows moved
        self._spawn_piece()

    def rotate_clockwise(self):
        if self.state != 'PLAYING' or not self.current_piece:
            return
        new_state = (self.current_state + 1) % 4
        # Try rotating the piece and checking if it fits
        if self._can_fit(self.current_piece, new_state, self.current_position[0], self.current_position[1]):
            self.current_state = new_state

    def rotate_counterclockwise(self):
        if self.state != 'PLAYING' or not self.current_piece:
            return
        new_state = (self.current_state + 3) % 4
        # Try rotating the piece and checking if it fits
        if self._can_fit(self.current_piece, new_state, self.current_position[0], self.current_position[1]):
            self.current_state = new_state

    def print_board(self):
        for row in self.board:
            print(''.join(row))
        print(f"SCORE {self.score} LINES {self.lines_cleared} {self.state}")

    def process_command(self, command):
        if command == 'L':
            self.move_left()
        elif command == 'R':
            self.move_right()
        elif command == 'D':
            self.move_down()
        elif command == 'H':
            self.hard_drop()
        elif command == 'CW':
            self.rotate_clockwise()
        elif command == 'CCW':
            self.rotate_counterclockwise()
        elif command == 'P':
            self.print_board()
        else:
            print(f"error: unknown command {command}", file=sys.stderr)

if __name__ == "__main__":
    tetris = Tetris()
    piece_sequence = sys.stdin.readline().strip()
    tetris.piece_sequence = list(piece_sequence)
    tetris._spawn_piece()
    
    for line in sys.stdin:
        line = line.strip()
        if line:
            tetris.process_command(line)
    
    tetris.print_board()