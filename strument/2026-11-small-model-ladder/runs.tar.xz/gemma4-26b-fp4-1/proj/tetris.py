import sys

PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)]
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)]
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)]
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)]
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)]
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)]
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)]
    ]
}

class Tetris:
    def __init__(self, piece_sequence):
        self.piece_sequence = piece_sequence
        self.board = [['.' for _ in range(10)] for _ in range(20)]
        self.score = 0
        self.lines_cleared = 0
        self.state = 'PLAYING'
        self.current_piece = None
        self.next_piece_index = 0
        self._spawn_next_piece()

    def _spawn_next_piece(self):
        if self.next_piece_index >= len(self.piece_sequence):
            self.state = 'DONE'
            self.current_piece = None
            return

        piece_type = self.piece_sequence[self.next_piece_index]
        self.next_piece_index += 1
        
        self.current_piece = {
            'type': piece_type,
            'state': 0,
            'row': 0,
            'col': 3
        }

        if not self._fits(self.current_piece):
            self.state = 'OVER'
            self.current_piece = None

    def _fits(self, piece):
        offsets = PIECES[piece['type']][piece['state']]
        for dr, dc in offsets:
            r, c = piece['row'] + dr, piece['col'] + dc
            if not (0 <= r < 20 and 0 <= c < 10):
                return False
            if self.board[r][c] != '.':
                return False
        return True

    def move_left(self):
        if self.state != 'PLAYING' or self.current_piece is None:
            return
        old_col = self.current_piece['col']
        self.current_piece['col'] -= 1
        if not self._fits(self.current_piece):
            self.current_piece['col'] = old_col

    def move_right(self):
        if self.state != 'PLAYING' or self.current_piece is None:
            return
        old_col = self.current_piece['col']
        self.current_piece['col'] += 1
        if not self._fits(self.current_piece):
            self.current_piece['col'] = old_col

    def move_down(self):
        if self.state != 'PLAYING' or self.current_piece is None:
            return
        
        self.current_piece['row'] += 1
        if self._fits(self.current_piece):
            self.score += 1
        else:
            self.current_piece['row'] -= 1
            self._lock_piece()

    def hard_drop(self):
        if self.state != 'PLAYING' or self.current_piece is None:
            return
        
        original_row = self.current_piece['row']
        while True:
            self.current_piece['row'] += 1
            if self._fits(self.current_piece):
                continue
            else:
                self.current_piece['row'] -= 1
                break
        
        rows_moved = self.current_piece['row'] - original_row
        self.score += 2 * rows_moved
        self._lock_piece()

    def rotate_cw(self):
        if self.state != 'PLAYING' or self.current_piece is None:
            return
        
        old_state = self.current_piece['state']
        old_col = self.current_piece['col']
        
        new_state = (old_state + 1) % 4
        self.current_piece['state'] = new_state
        
        # Rotation tries the new state at the current position, 
        # then with the column shifted by -1, +1, -2, +2, in that order, keeping the row.
        # The first of these five where the piece fits is taken. If none fits, nothing happens.
        
        column_offsets = [0, -1, 1, -2, 2]
        found = False
        for offset in column_offsets:
            self.current_piece['col'] = old_col + offset
            if self._fits(self.current_piece):
                found = True
                break
        
        if not found:
            self.current_piece['state'] = old_state
            self.current_piece['col'] = old_col

    def rotate_ccw(self):
        if self.state != 'PLAYING' or self.current_piece is None:
            return
        
        old_state = self.current_piece['state']
        old_col = self.current_piece['col']
        
        new_state = (old_state + 3) % 4
        self.current_piece['state'] = new_state
        
        column_offsets = [0, -1, 1, -2, 2]
        found = False
        for offset in column_offsets:
            self.current_piece['col'] = old_col + offset
            if self._fits(self.current_piece):
                found = True
                break
        
        if not found:
            self.current_piece['state'] = old_state
            self.current_piece['col'] = old_col

    def _lock_piece(self):
        offsets = PIECES[self.current_piece['type']][self.current_piece['state']]
        for dr, dc in offsets:
            r, c = self.current_piece['row'] + dr, self.current_piece['col'] + dc
            self.board[r][c] = self.current_piece['type']
        
        self._clear_lines()
        self._spawn_next_piece()

    def _clear_lines(self):
        rows_to_clear = []
        for r in range(20):
            if all(self.board[r][c] != '.' for c in range(10)):
                rows_to_clear.append(r)
        
        if not rows_to_clear:
            return

        num_cleared = len(rows_to_clear)
        
        # Scoring
        if num_cleared == 1:
            self.score += 100
        elif num_cleared == 2:
            self.score += 300
        elif num_cleared == 3:
            self.score += 500
        elif num_cleared == 4:
            self.score += 800
            
        self.lines_cleared += num_cleared
        
        # Remove rows and shift down
        for r in rows_to_clear:
            # This is tricky because we want to remove multiple rows at once.
            # The spec says "every full row (all 10 cells locked) is removed, 
            # the rows above it move down to close the gap, and empty rows enter at the top."
            pass

        # Let's do it correctly.
        new_board = []
        for r in range(20):
            if r not in rows_to_clear:
                new_board.append(self.board[r])
        
        while len(new_board) < 20:
            new_board.insert(0, ['.' for _ in range(10)])
            
        self.board = new_board

    def print_board(self):
        for r in range(20):
            line = ""
            for c in range(10):
                if self.current_piece and self.current_piece['type'].lower() == self.current_piece['type'].lower() and \
                   any(r == self.current_piece['row'] + dr and c == self.current_piece['col'] + dc 
                       for dr, dc in PIECES[self.current_piece['type']][self.current_piece['state']]):
                    # Wait, I need to distinguish between current piece blocks and locked blocks.
                    # The spec says: "." for an empty cell, the uppercase letter for a locked cell, 
                    # and the lowercase letter for a block of the piece in play.
                    pass
            # This is getting confusing. Let's refine the printing.
            pass

def main():
    # ...
    pass

if __name__ == "__main__":
    main()
