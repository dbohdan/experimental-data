import sys

PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)],
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)],
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)],
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)],
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)],
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)],
    ],
}

class Tetris:
    def __init__(self):
        self.rows = 20
        self.cols = 10
        self.board = [['.' for _ in range(self.cols)] for _ in range(self.rows)]
        self.score = 0
        self.lines_cleared = 0
        self.state = 'PLAYING'
        self.pieces_sequence = []
        self.current_piece_type = None
        self.current_piece_state = 0
        self.current_piece_pos = (0, 3)
        self.piece_in_play = False

    def spawn_piece(self):
        if not self.pieces_sequence:
            self.state = 'DONE'
            self.piece_in_play = False
            return

        self.current_piece_type = self.pieces_sequence[0]
        self.pieces_sequence.pop(0)
        self.current_piece_state = 0
        self.current_piece_pos = (0, 3)

        if not self.piece_fits(self.current_piece_pos, self.current_piece_state):
            self.state = 'OVER'
            self.piece_in_play = False
        else:
            self.piece_in_play = True

    def piece_fits(self, pos, state):
        r, c = pos
        piece_blocks = PIECES[self.current_piece_type][state]
        for dr, dc in piece_blocks:
            nr, nc = r + dr, c + dc
            if not (0 <= nr < self.rows and 0 <= nc < self.cols):
                return False
            if self.board[nr][nc] != '.':
                return False
        return True

    def move_left(self):
        if self.state != 'PLAYING' or not self.piece_in_play: return
        r, c = self.current_piece_pos
        if self.piece_fits((r, c - 1), self.current_piece_state):
            self.current_piece_pos = (r, c - 1)

    def move_right(self):
        if self.state != 'PLAYING' or not self.piece_in_play: return
        r, c = self.current_piece_pos
        if self.piece_fits((r, c + 1), self.current_piece_state):
            self.current_piece_pos = (r, c + 1)

    def move_down(self):
        if self.state != 'PLAYING' or not self.piece_in_play: return
        r, c = self.current_piece_pos
        if self.piece_fits((r + 1, c), self.current_piece_state):
            self.current_piece_pos = (r + 1, c)
            self.score += 1
        else:
            self.lock_piece()

    def hard_drop(self):
        if self.state != 'PLAYING' or not self.piece_in_play: return
        r, c = self.current_piece_pos
        rows_moved = 0
        while self.piece_fits((r + 1, c), self.current_piece_state):
            r += 1
            rows_moved += 1
        self.current_piece_pos = (r, c)
        self.score += 2 * rows_moved
        self.lock_piece()

    def rotate_cw(self):
        if self.state != 'PLAYING' or not self.piece_in_play: return
        new_state = (self.current_piece_state + 1) % 4
        for dc in [0, -1, 1, -2, 2]:
            r, c = self.current_piece_pos
            if self.piece_fits((r, c + dc), new_state):
                self.current_piece_state = new_state
                self.current_piece_pos = (r, c + dc)
                return

    def rotate_ccw(self):
        if self.state != 'PLAYING' or not self.piece_in_play: return
        new_state = (self.current_piece_state + 3) % 4
        for dc in [0, -1, 1, -2, 2]:
            r, c = self.current_piece_pos
            if self.piece_fits((r, c + dc), new_state):
                self.current_piece_state = new_state
                self.current_piece_pos = (r, c + dc)
                return

    def lock_piece(self):
        r, c = self.current_piece_pos
        piece_blocks = PIECES[self.current_piece_type][self.current_piece_state]
        for dr, dc in piece_blocks:
            self.board[r + dr][c + dc] = self.current_piece_type.lower()
        
        self.piece_in_play = False
        
        rows_to_clear = []
        for r in range(self.rows):
            if all(self.board[r][c] != '.' for c in range(self.cols)):
                rows_to_clear.append(r)
        
        if rows_to_clear:
            num_cleared = len(rows_to_clear)
            self.lines_cleared += num_cleared
            score_map = {1: 100, 2: 300, 3: 500, 4: 800}
            self.score += score_map.get(num_cleared, 0)
            
            new_board = [self.board[r] for r in range(self.rows) if r not in rows_to_clear]
            new_board = [['.'] * self.cols for _ in range(self.rows - len(new_board))] + new_board
            self.board = new_board

        self.spawn_piece()

    def print_board(self):
        display_board = [row[:] for row in self.board]
        if self.piece_in_play:
            r, c = self.current_piece_pos
            piece_blocks = PIECES[self.current_piece_type][self.current_piece_state]
            for dr, dc in piece_blocks:
                display_board[r + dr][c + dc] = self.current_piece_type.lower()
        
        for row in display_board:
            print("".join(row))
        print(f"SCORE {self.score} LINES {self.lines_cleared} {self.state}")

    def run(self, input_stream):
        first_line = input_stream.readline()
        if not first_line:
            return
        
        self.pieces_sequence = list(first_line.strip())
        self.spawn_piece()
        
        def get_tokens():
            for line in input_stream:
                for token in line.split():
                    yield token
        
        tokens = get_tokens()
        for token in tokens:
            if self.state == 'OVER':
                if token == 'P':
                    self.print_board()
                continue
            
            if token == 'P':
                self.print_board()
                continue
            
            if not self.piece_in_play:
                continue
                
            if token == 'L':
                self.move_left()
            elif token == 'R':
                self.move_right()
            elif token == 'D':
                self.move_down()
            elif token == 'H':
                self.hard_drop()
            elif token == 'CW':
                self.rotate_cw()
            elif token == 'CCW':
                self.rotate_ccw()
            else:
                sys.stderr.write(f"error: unknown command {token}\n")
        
        self.print_board()

if __name__ == "__main__":
    game = Tetris()
    game.run(sys.stdin)
