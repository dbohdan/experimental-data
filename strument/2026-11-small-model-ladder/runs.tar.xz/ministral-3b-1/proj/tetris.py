#!/usr/bin/env python3

import sys
from collections import defaultdict

# Piece definitions: (r, c) offsets for each state
PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],  # State 0: Vertical line
        [(0, 2), (1, 2), (2, 2), (3, 2)],  # State 1: Horizontal line
        [(2, 0), (2, 1), (2, 2), (2, 3)],  # State 2: Vertical line (mirrored)
        [(0, 1), (1, 1), (2, 1), (3, 1)],  # State 3: Horizontal line
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],  # State 0: Square
        [(0, 1), (0, 2), (1, 1), (1, 2)],  # State 1: Square
        [(0, 1), (0, 2), (1, 1), (1, 2)],  # State 2: Square
        [(0, 1), (0, 2), (1, 1), (1, 2)],  # State 3: Square
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],  # State 0: T-shape
        [(0, 1), (1, 1), (1, 2), (2, 1)],  # State 1: Rotated T
        [(1, 0), (1, 1), (1, 2), (2, 1)],  # State 2: Rotated T
        [(0, 1), (1, 0), (1, 1), (2, 1)],  # State 3: Rotated T
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],  # State 0: Zigzag
        [(0, 1), (1, 1), (1, 2), (2, 2)],  # State 1: Rotated Zigzag
        [(1, 1), (1, 2), (2, 0), (2, 1)],  # State 2: Rotated Zigzag
        [(0, 0), (1, 0), (1, 1), (2, 1)],  # State 3: Rotated Zigzag
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],  # State 0: Anti-zigzag
        [(0, 2), (1, 1), (1, 2), (2, 1)],  # State 1: Rotated Anti-zigzag
        [(1, 0), (1, 1), (2, 1), (2, 2)],  # State 2: Rotated Anti-zigzag
        [(0, 1), (1, 0), (1, 1), (2, 0)],  # State 3: Rotated Anti-zigzag
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],  # State 0: L-shape
        [(0, 1), (0, 2), (1, 1), (2, 1)],  # State 1: Rotated L
        [(1, 0), (1, 1), (1, 2), (2, 2)],  # State 2: Rotated L
        [(0, 1), (1, 1), (2, 0), (2, 1)],  # State 3: Rotated L
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],  # State 0: Mirrored L-shape
        [(0, 1), (1, 1), (2, 1), (2, 2)],  # State 1: Rotated Mirrored L
        [(1, 0), (1, 1), (1, 2), (2, 0)],  # State 2: Rotated Mirrored L
        [(0, 0), (0, 1), (1, 1), (2, 1)],  # State 3: Rotated Mirrored L
    ],
}

# Rotation logic: try new state at current position, then shift columns
# to find the first valid position

def try_rotation(piece_type, state, row, col, board_set):
    if piece_type not in PIECES:
        return None
    
    offsets = PIECES[piece_type]
    
    # Try clockwise rotation
    new_state = (state + 1) % 4
    new_offsets = offsets[new_state]
    
    # Check if the new state fits at the current position
    valid = True
    for r, c in new_offsets:
        if (row + r, col + c) not in board_set:
            valid = False
            break
    if valid:
        return (piece_type, new_state, row, col)
    
    # Try shifting columns
    for shift in [-1, 1, -2, 2]:
        new_col = col + shift
        if new_col < 0 or new_col >= 10:
            continue
        
        valid = True
        for r, c in new_offsets:
            if (row + r, new_col + c) not in board_set:
                valid = False
                break
        if valid:
            return (piece_type, new_state, row, new_col)
    
    # Try counterclockwise rotation
    new_state = (state + 3) % 4
    new_offsets = offsets[new_state]
    
    # Check if the new state fits at the current position
    valid = True
    for r, c in new_offsets:
        if (row + r, col + c) not in board_set:
            valid = False
            break
    if valid:
        return (piece_type, new_state, row, col)
    
    # Try shifting columns
    for shift in [-1, 1, -2, 2]:
        new_col = col + shift
        if new_col < 0 or new_col >= 10:
            continue
        
        valid = True
        for r, c in new_offsets:
            if (row + r, new_col + c) not in board_set:
                valid = False
                break
        if valid:
            return (piece_type, new_state, row, new_col)
    
    return None

# Board and piece state
BOARD_SIZE = 20
COLUMNS = 10

# Initialize board: empty cells are represented as (row, col) tuples
board_set = set()
score = 0
lines_cleared = 0
current_piece = None
current_state = 0
current_row = 0
current_col = 3

# Read input
piece_sequence = sys.stdin.readline().strip()

# Process commands
for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    
    commands = line.split()
    for cmd in commands:
        if cmd == 'P':
            print_board()
            print(f"SCORE {score} LINES {lines_cleared} {'PLAYING' if current_piece else 'OVER' if not current_piece else 'DONE'}")
            continue
        
        if not current_piece:
            continue
            
        if cmd == 'L':
            new_col = current_col - 1
            if new_col >= 0:
                piece_fits = True
                for r, c in PIECES[current_piece][current_state % 4]:
                    if (current_row + r, new_col + c) not in board_set:
                        piece_fits = False
                        break
                if piece_fits:
                    current_col = new_col
        
        elif cmd == 'R':
            new_col = current_col + 1
            if new_col < COLUMNS:
                piece_fits = True
                for r, c in PIECES[current_piece][current_state % 4]:
                    if (current_row + r, new_col + c) not in board_set:
                        piece_fits = False
                        break
                if piece_fits:
                    current_col = new_col
        
        elif cmd == 'D':
            new_row = current_row + 1
            if new_row < BOARD_SIZE:
                piece_fits = True
                for r, c in PIECES[current_piece][current_state % 4]:
                    if (new_row + r, current_col + c) not in board_set:
                        piece_fits = False
                        break
                if piece_fits:
                    current_row = new_row
                    score += 100
                else:
                    lock_piece()
            else:
                lock_piece()
        
        elif cmd == 'H':
            # Hard drop: move down as far as possible
            max_drop = 0
            for drop in range(1, BOARD_SIZE - current_row):
                valid = True
                for r, c in PIECES[current_piece][current_state % 4]:
                    if (current_row + drop + r, current_col + c) not in board_set:
                        valid = False
                        break
                if valid:
                    max_drop = drop
                else:
                    break
            
            for drop in range(1, max_drop + 1):
                current_row += drop
                score += 2 * drop
            
            lock_piece()
        
        elif cmd == 'CW':
            new_piece = try_rotation(current_piece, current_state, current_row, current_col, board_set)
            if new_piece:
                current_piece, current_state, current_row, current_col = new_piece
        
        elif cmd == 'CCW':
            new_piece = try_rotation(current_piece, current_state, current_row, current_col, board_set)
            if new_piece:
                current_piece, current_state, current_row, current_col = new_piece
        
        elif cmd.startswith('error:'):
            print(cmd, file=sys.stderr)

# Initialize the game
for piece in piece_sequence:
    current_piece = piece
    current_state = 0
    current_row = 0
    current_col = 3
    
    # Check if the piece fits
    if piece in PIECES:
        try:
            state_offsets = PIECES[piece][current_state % 4]
            if isinstance(state_offsets, tuple):
                fits = True
                for r, c in state_offsets:
                    if (current_row + r, current_col + c) not in board_set:
                        fits = False
                        break
            else:
                fits = False
        except Exception as e:
            print(f"Error accessing offsets[state] for {piece}: {e}")
            fits = False
    else:
        fits = False
    
    if not fits:
        current_piece = None

# Lock the first piece if it fits
if current_piece:
    lock_piece()

# Print the final board
print_board()
print(f"SCORE {score} LINES {lines_cleared} {'PLAYING' if current_piece else 'OVER' if not current_piece else 'DONE'}")


def lock_piece():
    global board_set, lines_cleared, score
    
    # Add the piece's blocks to the board
    for r, c in PIECES[current_piece][current_state % 4]:
        board_set.add((current_row + r, current_col + c))
    
    # Check for cleared lines
    cleared_lines = []
    for row in range(BOARD_SIZE):
        if all((row, col) in board_set for col in range(COLUMNS)):
            cleared_lines.append(row)
    
    # Remove cleared lines and update the board
    for row in cleared_lines:
        board_set -= {(row, col) for col in range(COLUMNS)}
        board_set.update((row - 1, col) for col in range(COLUMNS) if (row - 1, col) not in board_set)
    
    lines_cleared += len(cleared_lines)
    score += {1: 100, 2: 300, 3: 500, 4: 800}[len(cleared_lines)]
    
    # Move remaining rows down
    for row in cleared_lines:
        for col in range(COLUMNS):
            if (row, col) in board_set:
                board_set.remove((row, col))
                board_set.add((row - len(cleared_lines), col))
    
    # Spawn the next piece
    if piece_sequence:
        piece_sequence = piece_sequence[1:]  # Remove the used piece
        current_piece = piece_sequence[0]
        current_state = 0
        current_row = 0
        current_col = 3
        
        # Check if the piece fits
        fits = True
        for r, c in PIECES[current_piece][current_state % 4]:
            if (current_row + r, current_col + c) not in board_set:
                fits = False
                break
        
        if not fits:
            current_piece = None


def print_board():
    # Create a 2D board representation
    board_grid = [['.' for _ in range(COLUMNS)] for _ in range(BOARD_SIZE)]
    
    # Fill the board grid with locked pieces
    for (row, col) in board_set:
        board_grid[row][col] = board_set[(row, col)].upper()
    
    # Fill the board grid with current piece
    if current_piece:
        state_offsets = PIECES[current_piece][current_state % 4]
        for r, c in state_offsets:
            board_grid[current_row + r][current_col + c] = current_piece.lower()
    
    # Print the board
    for row in board_grid:
        print(''.join(row))

# Initialize the board
board_set = set()