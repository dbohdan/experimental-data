#!/usr/bin/env python3

import sys

# Define the piece shapes and their rotations
PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],  # State 0
        [(0, 2), (1, 2), (2, 2), (3, 2)],  # State 1
        [(2, 0), (2, 1), (2, 2), (2, 3)],  # State 2
        [(0, 1), (1, 1), (2, 1), (3, 1)],  # State 3
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],  # State 0
        [(0, 1), (0, 2), (1, 1), (1, 2)],  # State 1
        [(0, 1), (0, 2), (1, 1), (1, 2)],  # State 2
        [(0, 1), (0, 2), (1, 1), (1, 2)],  # State 3
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],  # State 0
        [(0, 1), (1, 1), (2, 1), (2, 2)],  # State 1
        [(1, 0), (1, 1), (1, 2), (2, 1)],  # State 2
        [(0, 1), (1, 0), (1, 1), (2, 1)],  # State 3
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],  # State 0
        [(0, 1), (1, 1), (1, 2), (2, 2)],  # State 1
        [(1, 1), (1, 2), (2, 0), (2, 1)],  # State 2
        [(0, 0), (1, 0), (1, 1), (2, 1)],  # State 3
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],  # State 0
        [(0, 2), (1, 1), (1, 2), (2, 1)],  # State 1
        [(1, 0), (1, 1), (2, 1), (2, 2)],  # State 2
        [(0, 1), (1, 0), (1, 1), (2, 0)],  # State 3
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],  # State 0
        [(0, 1), (0, 2), (1, 1), (2, 1)],  # State 1
        [(1, 0), (1, 1), (1, 2), (2, 2)],  # State 2
        [(0, 1), (1, 1), (2, 0), (2, 1)],  # State 3
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],  # State 0
        [(0, 1), (1, 1), (2, 1), (2, 2)],  # State 1
        [(1, 0), (1, 1), (1, 2), (2, 0)],  # State 2
        [(0, 0), (0, 1), (1, 1), (2, 1)],  # State 3
    ],
}

# Initialize the board
BOARD_WIDTH = 10
BOARD_HEIGHT = 20

# Initialize the game state
def init_game():
    board = [['.' for _ in range(BOARD_WIDTH)] for _ in range(BOARD_HEIGHT)]
    score = 0
    lines_cleared = 0
    state = 'PLAYING'
    return board, score, lines_cleared, state

# Check if a piece fits at a given position and state
def fits(board, piece, row, col, state):
    for r_offset, c_offset in PIECES[piece][state]:
        r = row + r_offset
        c = col + c_offset
        if r < 0 or r >= BOARD_HEIGHT or c < 0 or c >= BOARD_WIDTH or board[r][c] != '.':
            return False
    return True

# Lock a piece and clear completed rows
def lock_piece(board, piece, row, col, state):
    for r_offset, c_offset in PIECES[piece][state]:
        r = row + r_offset
        c = col + c_offset
        board[r][c] = piece.upper()
    
    # Clear completed rows
    cleared_rows = []
    for r in range(BOARD_HEIGHT):
        if all(board[r][c] != '.' for c in range(BOARD_WIDTH)):
            cleared_rows.append(r)
    
    # Move rows up and add empty rows at the top
    for r in sorted(cleared_rows, reverse=True):
        for c in range(BOARD_WIDTH):
            board[r][c] = '.'
        
        for r2 in range(r, 0, -1):
            board[r2][c] = board[r2 - 1][c]
        
        for c in range(BOARD_WIDTH):
            board[0][c] = '.'
    
    # Update score
    score = 0
    for r in cleared_rows:
        score += 100 * (4 - (cleared_rows.index(r) + 1))
    
    return score

# Rotate a piece clockwise
def rotate_piece(piece, state):
    return (state + 1) % 4

# Rotate a piece counterclockwise
def rotate_counterclockwise(piece, state):
    return (state + 3) % 4

# Try to rotate a piece at a given position and state
def try_rotate(board, piece, row, col, state):
    new_state = rotate_piece(piece, state)
    
    # Try all possible shifts for rotation
    for shift in [-2, -1, 1, 2]:
        new_row, new_col = row, col
        for r_offset, c_offset in PIECES[piece][new_state]:
            new_r = new_row + r_offset
            new_c = new_col + c_offset + shift
            if new_r < 0 or new_r >= BOARD_HEIGHT or new_c < 0 or new_c >= BOARD_WIDTH or board[new_r][new_c] != '.':
                continue
        
        # Check if the rotated piece fits
        if fits(board, piece, new_row, new_col, new_state):
            return new_row, new_col, new_state
    
    return row, col, state

# Process a command
def process_command(board, piece_sequence, current_piece, current_row, current_col, current_state, score, lines_cleared, state):
    command = sys.stdin.readline().strip()
    if not command:
        return None, score, lines_cleared, state, current_piece, current_row, current_col, current_state
    
    if command == 'P':
        print_board(board)
        print(f"SCORE {score} LINES {lines_cleared} {state}")
        return board, score, lines_cleared, state, current_piece, current_row, current_col, current_state
    
    if not state == 'PLAYING':
        return board, score, lines_cleared, state, current_piece, current_row, current_col, current_state
    
    # Initialize current_piece if not already set
    if current_piece is None:
        piece_sequence = list(piece_sequence)
        current_piece = piece_sequence.pop(0)
        current_row, current_col, current_state = 0, 3, 0
        if not fits(board, current_piece, current_row, current_col, current_state):
            state = 'OVER'
            return board, score, lines_cleared, state, current_piece, current_row, current_col, current_state
    
    if command == 'L':
        if fits(board, current_piece, current_row, current_col - 1, current_state):
            current_col -= 1
    
    elif command == 'R':
        if fits(board, current_piece, current_row, current_col + 1, current_state):
            current_col += 1
    
    elif command == 'D':
        if fits(board, current_piece, current_row + 1, current_col, current_state):
            current_row += 1
            score += 1
            if not fits(board, current_piece, current_row, current_col, current_state):
                lock_piece(board, current_piece, current_row - 1, current_col, current_state)
                score = lock_piece(board, current_piece, current_row - 1, current_col, current_state)
                lines_cleared += 1
                
                if piece_sequence:
                    current_piece = piece_sequence.pop(0)
                    current_row, current_col, current_state = 0, 3, 0
                    if not fits(board, current_piece, current_row, current_col, current_state):
                        state = 'OVER'
        else:
            lock_piece(board, current_piece, current_row, current_col, current_state)
            score = lock_piece(board, current_piece, current_row, current_col, current_state)
            lines_cleared += 1
            
            if piece_sequence:
                current_piece = piece_sequence.pop(0)
                current_row, current_col, current_state = 0, 3, 0
                if not fits(board, current_piece, current_row, current_col, current_state):
                    state = 'OVER'
    
    elif command == 'H':
        new_row = current_row
        while fits(board, current_piece, new_row + 1, current_col, current_state):
            new_row += 1
        
        for r_offset, c_offset in PIECES[current_piece][current_state]:
            r = new_row + r_offset
            c = current_col + c_offset
            board[r][c] = current_piece.lower()
        
        score += 2 * (new_row - current_row)
        lock_piece(board, current_piece, new_row - 1, current_col, current_state)
        score = lock_piece(board, current_piece, new_row - 1, current_col, current_state)
        lines_cleared += 1
        
        if piece_sequence:
            current_piece = piece_sequence.pop(0)
            current_row, current_col, current_state = 0, 3, 0
            if not fits(board, current_piece, current_row, current_col, current_state):
                state = 'OVER'
    
    elif command == 'CW':
        new_row, new_col, new_state = try_rotate(board, current_piece, current_row, current_col, current_state)
        if new_state != current_state:
            current_state = new_state
    
    elif command == 'CCW':
        new_state = rotate_counterclockwise(current_piece, current_state)
        if new_state != current_state:
            if fits(board, current_piece, current_row, current_col, new_state):
                current_state = new_state
    
    else:
        print(f"error: unknown command {command}", file=sys.stderr)

# Print the board
def print_board(board):
    for row in board:
        print(''.join(row))

# Main game loop
def main():
    piece_sequence = sys.stdin.readline().strip()
    board, score, lines_cleared, state = init_game()
    piece_sequence_list = list(piece_sequence)
    
    current_piece = None
    current_row = 0
    current_col = 3
    current_state = 0
    
    # Read all commands from stdin
    for line in sys.stdin:
        line = line.strip()
        if line:
            board, score, lines_cleared, state, current_piece, current_row, current_col, current_state = process_command(
                board, piece_sequence_list, current_piece, current_row, current_col, current_state, score, lines_cleared, state
            )
    
    # Print the final board and score
    print_board(board)
    print(f"SCORE {score} LINES {lines_cleared} {state}")

# Redirect stdin to avoid issues with reading from a file
if __name__ == "__main__":
    import sys
    sys.stdin = open(sys.stdin.fileno(), mode='r', buffering=1)
    main()