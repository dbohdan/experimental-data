#!/usr/bin/env python3
"""Headless Tetris per SPEC.md."""

import sys

COLS = 10
ROWS = 20

SHAPES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)],
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)],
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)],
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)],
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)],
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)],
    ],
}

POINTS = {1: 100, 2: 300, 3: 500, 4: 800}


def parse_input(text):
    lines = text.splitlines()
    # First line is the piece sequence.
    idx = 0
    sequence = ""
    while idx < len(lines):
        line = lines[idx].strip()
        if line:
            sequence = line
            idx += 1
            break
        idx += 1
    rest = " ".join(lines[idx:])
    commands = rest.split()
    return sequence, commands


def main():
    text = sys.stdin.read()
    sequence, commands = parse_input(text)

    board = [['.'] * COLS for _ in range(ROWS)]
    score = 0
    lines_cleared = 0
    state = 'PLAYING'  # PLAYING, OVER, DONE
    seq_idx = 0
    piece = None  # dict with letter, row, col, rot

    def spawn():
        nonlocal piece, seq_idx, state
        if seq_idx >= len(sequence):
            # sequence exhausted; game done if no piece in play
            piece = None
            state = 'DONE'
            return
        letter = sequence[seq_idx]
        letter = letter.upper() if letter.isupper() else letter
        # sequence should be letters; use as-is
        piece = {'letter': sequence[seq_idx], 'row': 0, 'col': 3, 'rot': 0}
        if not fits(piece, board):
            piece = None
            state = 'OVER'
            return
        state = 'PLAYING'

    def fits(p, b):
        for r, c in SHAPES[p['letter']][p['rot']]:
            rr = p['row'] + r
            cc = p['col'] + c
            if rr < 0 or rr >= ROWS or cc < 0 or cc >= COLS:
                return False
            if b[rr][cc] != '.':
                return False
        return True

    def lock():
        nonlocal score, lines_cleared, piece, state, seq_idx
        p = piece
        for r, c in SHAPES[p['letter']][p['rot']]:
            board[p['row'] + r][p['col'] + c] = p['letter']
        # clear full rows
        new_board = [row[:] for row in board]
        cleared = 0
        kept = []
        for row in board:
            if all(cell != '.' for cell in row):
                cleared += 1
            else:
                kept.append(row[:])
        while len(kept) < ROWS:
            kept.insert(0, ['.'] * COLS)
        board[:] = kept
        if cleared:
            score += POINTS.get(cleared, 0)
            lines_cleared += cleared
        piece = None
        seq_idx += 1
        spawn()

    def print_game():
        display = [row[:] for row in board]
        if piece is not None:
            for r, c in SHAPES[piece['letter']][piece['rot']]:
                rr = piece['row'] + r
                cc = piece['col'] + c
                if 0 <= rr < ROWS and 0 <= cc < COLS:
                    display[rr][cc] = piece['letter'].lower()
        for row in display:
            sys.stdout.write(''.join(row) + '\n')
        sys.stdout.write('SCORE %d LINES %d %s\n' % (score, lines_cleared, state))

    # Initial spawn before reading commands
    if sequence:
        spawn()
    else:
        state = 'DONE'

    for cmd in commands:
        if cmd == 'P':
            print_game()
            continue
        if cmd not in ('L', 'R', 'D', 'H', 'CW', 'CCW'):
            print('error: unknown command %s' % cmd, file=sys.stderr)
            continue
        if piece is None:
            # game over or done; ignore
            continue
        if cmd == 'L':
            new = dict(piece)
            new['col'] -= 1
            if fits(new, board):
                piece['col'] -= 1
        elif cmd == 'R':
            new = dict(piece)
            new['col'] += 1
            if fits(new, board):
                piece['col'] += 1
        elif cmd == 'D':
            new = dict(piece)
            new['row'] += 1
            if fits(new, board):
                piece['row'] += 1
                score += 1
            else:
                lock()
        elif cmd == 'H':
            moved = 0
            while True:
                new = dict(piece)
                new['row'] += 1
                if fits(new, board):
                    piece['row'] += 1
                    moved += 1
                else:
                    break
            score += 2 * moved
            lock()
        elif cmd == 'CW':
            new = dict(piece)
            new['rot'] = (piece['rot'] + 1) % 4
            for dc in (0, -1, 1, -2, 2):
                cand = dict(new)
                cand['col'] = piece['col'] + dc
                if fits(cand, board):
                    piece['rot'] = new['rot']
                    piece['col'] = cand['col']
                    break
        elif cmd == 'CCW':
            new = dict(piece)
            new['rot'] = (piece['rot'] + 3) % 4
            for dc in (0, -1, 1, -2, 2):
                cand = dict(new)
                cand['col'] = piece['col'] + dc
                if fits(cand, board):
                    piece['rot'] = new['rot']
                    piece['col'] = cand['col']
                    break

    # End of input: print once more
    print_game()


if __name__ == '__main__':
    main()
