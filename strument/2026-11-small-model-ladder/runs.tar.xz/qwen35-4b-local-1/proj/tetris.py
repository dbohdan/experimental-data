	#!/usr/bin/env python3
	"""Headless Tetris - plays from commands on stdin, prints board to stdout."""
	
	SHAPES = {
	    'I': [
	        [(1, 0), (1, 1), (1, 2), (1, 3)],
	        [(0, 2), (1, 2), (2, 2), (3, 2)],
	        [(2, 0), (2, 1), (2, 2), (2, 3)],
	        [(0, 1), (1, 1), (2, 1), (3, 1)],
	    ],
	    'O': [
	        [(0, 1), (0, 2), (1, 1), (1, 2)],
	        [(0, 1), (0, 2), (1, 1), (1, 2)],
	        [(0, 1), (0, 2), (1, 1), (1, 2)],
	        [(0, 1), (0, 2), (1, 1), (1, 2)],
	    ],
	    'T': [
	        [(0, 1), (1, 0), (1, 1), (1, 2)],
	        [(0, 1), (1, 1), (1, 2), (2, 1)],
	        [(1, 0), (1, 1), (1, 2), (2, 1)],
	        [(0, 1), (1, 0), (1, 1), (2, 1)],
	    ],
	    'S': [
	        [(0, 1), (0, 2), (1, 0), (1, 1)],
	        [(0, 1), (1, 1), (1, 2), (2, 2)],
	        [(1, 1), (1, 2), (2, 0), (2, 1)],
	        [(0, 0), (1, 0), (1, 1), (2, 1)],
	    ],
	    'Z': [
	        [(0, 0), (0, 1), (1, 1), (1, 2)],
	        [(0, 2), (1, 1), (1, 2), (2, 1)],
	        [(1, 0), (1, 1), (2, 1), (2, 2)],
	        [(0, 1), (1, 0), (1, 1), (2, 0)],
	    ],
	    'J': [
	        [(0, 0), (1, 0), (1, 1), (1, 2)],
	        [(0, 1), (0, 2), (1, 1), (2, 1)],
	        [(1, 0), (1, 1), (1, 2), (2, 2)],
	        [(0, 1), (1, 1), (2, 0), (2, 1)],
	    ],
	    'L': [
	        [(0, 2), (1, 0), (1, 1), (1, 2)],
	        [(0, 1), (1, 1), (2, 1), (2, 2)],
	        [(1, 0), (1, 1), (1, 2), (2, 0)],
	        [(0, 0), (0, 1), (1, 1), (2, 1)],
	    ],
	}
	
	ROWS = 20
	COLS = 10
	CLEAR_POINTS = {1: 100, 2: 300, 3: 500, 4: 800}
	
	
	def make_board():
	    return [['.' for _ in range(COLS)] for _ in range(ROWS)]
	
	
	def piece_on_board(piece_shape, row, col):
	    for dr, dc in piece_shape:
	        r, c = row + dr, col + dc
	        if not (0 <= r < ROWS and 0 <= c < COLS):
	            return False
	        if board[r][c] != '.':
	            return False
	    return True
	
	
	def piece_blocks(piece_shape, row, col):
	    return [(row + dr, col + dc) for dr, dc in piece_shape]
	
	
	def clear_rows():
	    cleared = 0
	    to_remove = []
	    for r in range(ROWS - 1, -1, -1):
	        if all(board[r][c] != '.' for c in range(COLS)):
	            to_remove.append(r)
	            cleared += 1
	    if cleared == 0:
	        return 0
	    for r in to_remove:
	        del board[r]
	    new_board = [['.' for _ in range(COLS)] for _ in range(cleared)]
	    board = new_board + board
	    return cleared
	
	
	def lock_piece(piece, row, col):
	    for r, c in piece_blocks(SHAPES[piece], row, col):
	        board[r][c] = piece
	    cleared = clear_rows()
	    return cleared * CLEAR_POINTS[cleared]
	
	
	def print_board():
	    for row in board:
	        print(''.join(row))
	
	
	def main():
	    global board, score, lines_cleared, state, piece, piece_state
	    board = make_board()
	    score = 0
	    lines_cleared = 0
	    state = 'PLAYING'
	    import sys
	    lines = sys.stdin.read().split()
	    piece_seq = lines[0]
	    commands = lines[1:]
	    piece_idx = 0
	    piece = piece_seq[0]
	    piece_state = 0
	    row = 0
	    col = 3
	    if not piece_on_board(SHAPES[piece], row, col):
	        state = 'OVER'
	    else:
	        for cmd in commands:
	            if state == 'OVER':
	                continue
	            if piece is None:
	                if cmd == 'P':
	                    print_board()
	                    print(f"SCORE {score} LINES {lines_cleared} {state}")
	                continue
	            if cmd == 'L':
	                if piece_on_board(SHAPES[piece], row, col - 1):
	                    col -= 1
	            elif cmd == 'R':
	                if piece_on_board(SHAPES[piece], row, col + 1):
	                    col += 1
	            elif cmd == 'D':
	                if piece_on_board(SHAPES[piece], row + 1, col):
	                    row += 1
	                    score += 1
	                else:
	                    lock_piece(piece, row, col)
	                    if piece_idx < len(piece_seq):
	                        piece_idx += 1
	                        piece = piece_seq[piece_idx]
	                        piece_state = 0
	                        row = 0
	                        col = 3
	                        if not piece_on_board(SHAPES[piece], row, col):
	                            state = 'OVER'
	            elif cmd == 'H':
	                rows_dropped = 0
	                while piece_on_board(SHAPES[piece], row + 1, col):
	                    row += 1
	                    rows_dropped += 1
	                score += 2 * rows_dropped
	                lock_piece(piece, row, col)
	                if piece_idx < len(piece_seq):
	                    piece_idx += 1
	                    piece = piece_seq[piece_idx]
	                    piece_state = 0
	                    row = 0
	                    col = 3
	                    if not piece_on_board(SHAPES[piece], row, col):
	                        state = 'OVER'
	            elif cmd == 'CW':
	                piece_state = (piece_state + 1) % 4
	            elif cmd == 'CCW':
	                piece_state = (piece_state + 3) % 4
	            elif cmd == 'P':
	                print_board()
	            else:
	                print(f"error: unknown command {cmd}", file=sys.stderr)
	        print_board()
	        print(f"SCORE {score} LINES {lines_cleared} {state}")
	    else:
	        print_board()
	        print(f"SCORE {score} LINES {lines_cleared} {state}")
	
	
	if __name__ == '__main__':
	    main()
