#!/usr/bin/env python3
"""Headless Tetris implementation."""

import sys


# Board dimensions
BOARD_ROWS = 20
BOARD_COLS = 10


def fits(piece_letter: str, row: int, col: int, state: int, board: list) -> bool:
    """Check if the piece fits at the given position and state."""
    offsets = PIECES[piece_letter][state]
    for dr, dc in offsets:
        br, bc = row + dr, col + dc
        if not (0 <= br < BOARD_ROWS and 0 <= bc < BOARD_COLS):
            return False
        if board[br][bc] != '.':
            return False
    return True


PIECES = {
    'I': [
        [(1,0), (1,1), (1,2), (1,3)],   # state 0
        [(0,2), (1,2), (2,2), (3,2)],   # state 1
        [(2,0), (2,1), (2,2), (2,3)],   # state 2
        [(0,1), (1,1), (2,1), (3,1)],   # state 3
    ],
    'O': [
        [(0,1), (0,2), (1,1), (1,2)],   # all states same
    ] * 4,
    'T': [
        [(0,1), (1,0), (1,1), (1,2)],   # state 0
        [(0,1), (1,1), (1,2), (2,1)],   # state 1
        [(1,0), (1,1), (1,2), (2,1)],   # state 2
        [(0,1), (1,0), (1,1), (2,1)],   # state 3
    ],
    'S': [
        [(0,1), (0,2), (1,0), (1,1)],   # state 0
        [(0,1), (1,1), (1,2), (2,2)],   # state 1
        [(1,1), (1,2), (2,0), (2,1)],   # state 2
        [(0,0), (1,0), (1,1), (2,1)],   # state 3
    ],
    'Z': [
        [(0,0), (0,1), (1,1), (1,2)],   # state 0
        [(0,2), (1,1), (1,2), (2,1)],   # state 1
        [(1,0), (1,1), (2,1), (2,2)],   # state 2
        [(0,1), (1,0), (1,1), (2,0)],   # state 3
    ],
    'J': [
        [(0,0), (1,0), (1,1), (1,2)],   # state 0
        [(0,1), (0,2), (1,1), (2,1)],   # state 1
        [(1,0), (1,1), (1,2), (2,2)],   # state 2
        [(0,1), (1,1), (2,0), (2,1)],   # state 3
    ],
    'L': [
        [(0,2), (1,0), (1,1), (1,2)],   # state 0
        [(0,1), (1,1), (2,1), (2,2)],   # state 1
        [(1,0), (1,1), (1,2), (2,0)],   # state 2
        [(0,0), (0,1), (1,1), (2,1)],   # state 3
    ],
}


class TetrisGame:
    def __init__(self):
        self.board = [['.' for _ in range(BOARD_COLS)] for _ in range(BOARD_ROWS)]
        self.score = 0
        self.lines_cleared = 0
        self.piece_queue = []
        self.current_piece = None
        self.state = "PLAYING"
        
    def next_piece(self) -> bool:
        """Spawn the next piece. Returns True if successful."""
        if not self.piece_queue:
            self.state = "DONE"
            return True
        
        letter = self.piece_queue.pop(0)
        self.current_piece = letter
        self.current_piece_row = 0
        self.current_piece_col = 3
        self.current_piece_state = 0
        
        # Check if piece fits at spawn position
        if not fits(letter, 0, 3, 0, self.board):
            self.state = "OVER"
            self.current_piece = None
            return False
        
        # Render current piece onto board
        blocks = get_absolute_blocks(letter, 0, 3, 0)
        for br, bc in blocks:
            self.board[br][bc] = letter.lower()
        
        return True
    
    def get_absolute_blocks(self, piece_letter: str, row: int, col: int, state: int):
        """Get absolute board positions for all blocks of the piece."""
        offsets = PIECES[piece_letter][state]
        result = []
        for dr, dc in offsets:
            result.append((row + dr, col + dc))
        return result
    
    def handle_command(self, cmd: str) -> bool:
        """Handle a command. Returns True if piece still exists or should continue."""
        if self.state == "OVER":
            return False
        
        cmd = cmd.upper()
        
        if cmd == 'P':
            self._print_game()
            return True
            
        elif cmd == 'L':
            return self.move_left()
            
        elif cmd == 'R':
            return self.move_right()
            
        elif cmd == 'D':
            return self.move_down()
            
        elif cmd == 'CW':
            return self.rotate_clockwise()
            
        elif cmd == 'CCW':
            return self.rotate_counterclockwise()
            
        else:
            print(f"error: unknown command {cmd}", file=sys.stderr)
            return True
    
    def move_left(self) -> bool:
        """Move piece one column left if it fits."""
        return self.try_move(-1, self.current_piece_row, self.current_piece_col)
    
    def move_right(self) -> bool:
        """Move piece one column right if it fits."""
        return self.try_move(1, self.current_piece_row, self.current_piece_col)
    
    def try_move(self, dc: int, row: int, col: int) -> bool:
        """Try to move piece by dc columns."""
        new_col = col + dc
        target_pieces = [p for p in self.piece_queue]  # Clone without current
        
        if not fits(self.current_piece, row, new_col, self.current_piece_state, self.board):
            return False
        
        # Check if move puts us too close to end of queue (would skip spawning next)
        pieces_remaining = len(target_pieces)
        if pieces_remaining > 0 and self.next_piece():
            # Move executed successfully, update position and render
            self.current_piece_row = row
            self.current_piece_col = new_col
            self._render_current_piece()
            return True
        elif pieces_remaining > 0:
            # Don't allow this move, it would cause premature spawn issue
            pass
        return True
    
    def move_down(self) -> bool:
        """Move piece one row down if it fits. Otherwise lock."""
        can_move = fits(self.current_piece, self.current_piece_row + 1,
                       self.current_piece_col, self.current_piece_state, self.board)
        
        if can_move:
            self.current_piece_row += 1
            self._render_current_piece()
            self.score += 1
            return True
        else:
            return self.lock_piece()
    
    def rotate_clockwise(self) -> bool:
        """Rotate clockwise. Try positions with col adjustments."""
        if self.current_piece is None:
            return False
        
        new_state = (self.current_piece_state + 1) % 4
        
        # Try: same col, col-1, col+1, col-2, col+2
        col_offsets = [0, -1, 1, -2, 2]
        
        for col_offset in col_offsets:
            test_col = self.current_piece_col + col_offset
            if fits(self.current_piece, self.current_piece_row, test_col, new_state, self.board):
                self.current_piece_state = new_state
                self.current_piece_col = test_col
                self._render_current_piece()
                return True
        
        return False
    
    def rotate_counterclockwise(self) -> bool:
        """Rotate counterclockwise."""
        if self.current_piece is None:
            return False
        
        for _ in range(3):
            ret = self.rotate_clockwise()
            if not ret:
                return False
    
    def lock_piece(self):
        """Lock the current piece and clear any full lines."""
        blocks = get_absolute_blocks(
            self.current_piece,
            self.current_piece_row,
            self.current_piece_col,
            self.current_piece_state
        )
        letter = self.current_piece.upper()
        
        for br, bc in blocks:
            self.board[br][bc] = letter
        
        self._clear_lines()
        self.current_piece = None
    
    def _clear_lines(self):
        """Clear full lines from bottom up."""
        lines_cleared = 0
        
        # Find lowest non-empty row (highest index)
        non_empty = False
        for r in range(BOARD_ROWS - 1, -1, -1):
            if all(c != '.' for c in self.board[r]):
                non_empty = True
                break
        
        # Count consecutive full rows from bottom
        while non_empty:
            found_full = False
            for r in range(BOARD_ROWS - 1, -1, -1):
                if all(c != '.' for c in self.board[r]):
                    found_full = True
                    lines_cleared += 1
                    self.board.pop(r)
                    self.board.insert(0, ['.'] * BOARD_COLS)
                    break
            if not found_full:
                break
        
        # Score calculation
        if lines_cleared == 1:
            self.score += 100
        elif lines_cleared == 2:
            self.score += 300
        elif lines_cleared == 3:
            self.score += 500
        else:
            self.score += 800
        
        self.lines_cleared += lines_cleared
    
    def _render_current_piece(self):
        """Render the current moving piece on the board."""
        blocks = self.get_absolute_blocks(
            self.current_piece,
            self.current_piece_row,
            self.current_piece_col,
            self.current_piece_state
        )
        for br, bc in blocks:
            if 0 <= br < BOARD_ROWS and 0 <= bc < BOARD_COLS:
                self.board[br][bc] = self.current_piece.lower()
    
    def _print_game(self):
        """Print the current game state."""
        output = []
        
        if self.state == "PLAYING":
            # Print board plus current piece
            for i in range(BOARD_ROWS):
                output.append("".join(self.board[i]))
        elif self.state == "OVER":
            # Last frame with OVER appended will be printed elsewhere
            for i in range(BOARD_ROWS):
                output.append("".join(self.board[i]))
        elif self.state == "DONE":
            # Print what we saw last time + append done indicator
            pass
        
        # Store this output
        if self.state == "PLAYING":
            self.last_printed_output = '\n'.join(output)
        
        if len(output) == BOARD_ROWS:
            output.append(f"SCORE {self.score} LINES {self.lines_cleared} {self.state}")
        
        print('\n'.join(output))
    
    @property
    def game_over_or_done(self):
        return self.state in ("OVER", "DONE")


def main():
    # Read piece sequence from stdin
    piece_sequence = ""
    for line in sys.stdin:
        for char in line.strip():
            if char.isalpha():
                piece_sequence += char
    
    if not piece_sequence:
        return
    
    num_pieces = len(piece_sequence)
    idx = 0
    
    # Create initial game and store its state
    game = TetrisGame()
    games = []
    
    # Spawn first piece immediately
    if game.next_piece():
        games.append(game)
    
    done_idx = 0
    while idx < num_pieces:
        # For each existing game where piece exists and has next piece, spawn it
        new_game = TetrisGame()
        new_game.board = [list(row) for row in games[done_idx].board]
        new_game.score = games[done_idx].score
        new_game.lines_cleared = games[done_idx].lines_cleared
        new_game.piece_queue = games[done_idx].piece_queue[:]
        new_game.current_piece = games[done_idx].current_piece
        new_game.state = games[done_idx].state
        new_game.last_printed_output = getattr(games[done_idx], 'last_printed_output', '')
        
        piece_added = new_game.next_piece()
        if piece_added:
            games.append(new_game)
            done_idx += 1
        else:
            break
        
        idx += 1
    
    # Process commands
    while True:
        try:
            line = sys.stdin.readline()
            tokens = line.split()
            if not tokens:
                continue
            for token in tokens:
                changed = False
                for g in games:
                    changed = g.handle_command(token)
                    if not g.game_over_or_done:
                        break
                if changed:
                    # Update next piece spawning
                    for g in reversed(games):
                        if len(g.piece_queue) > 0:
                            idx_to_spawn = len([x for x in games if len(x.piece_queue) > 0])
                            break
            print_last_frame_and_exit(games)
        except EOFError:
            break


def print_last_frame_and_exit(games):
    """Print the last frame for all games and exit."""
    lines = []
    
    for g in games:
        output = []
        for i in range(BOARD_ROWS):
            output.append("".join(g.board[i]))
        
        final_line = f"SCORE {g.score} LINES {g.lines_cleared} {g.state}"
        output.append(final_line)
        
        lines.extend(output)
    
    print('\n'.join(lines))


if __name__ == "__main__":
    main()
