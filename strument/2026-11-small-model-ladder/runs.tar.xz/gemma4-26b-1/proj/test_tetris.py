import subprocess
import os

def test_sample(sample_name):
    input_file = f"samples/{sample_name}.in"
    expected_output_file = f"samples/{sample_name}.out"
    
    if not os.path.exists(input_file) or not os.path.exists(expected_output_file):
        print(f"Skipping {sample_name}: input or output file not found.")
        return

    with open(input_file, 'r') as f:
        input_content = f.read()

    result = subprocess.run(['python3', 'tetris.py'], input=input_content, capture_output=True, text=True)

    # The spec says "Your program's output for each .in must match its .out byte for byte."
    # This includes stdout and stderr.
    
    actual_output = result.stdout
    expected_output = ""
    with open(expected_output_file, 'r') as f:
        expected_output = f.read()
    
    # If there are errors in stderr, we should check them too, but the requirement is about matching .out
    # Let's see if the stdout matches.
    if actual_output == expected_output:
        print(f"PASS: {sample_name}")
    else:
        print(f"FAIL: {sample_name}")
        print(f"--- EXPECTED ---")
        print(expected_output)
        print(f"--- ACTUAL ---")
        print(actual_output)
        if result.stderr:
            print(f"--- STDERR ---")
            print(result.stderr)

samples_dir = "samples"
for filename in os.listdir(samples_dir):
    if filename.endswith(".in"):
        sample_name = filename[:-3]
        test_sample(sample_name)
