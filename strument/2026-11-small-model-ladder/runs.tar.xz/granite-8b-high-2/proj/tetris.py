#!/usr/bin/env python3
import sys

# Piece shapes as list of 4 states, each state is list of (r, c) offsets from top-left box corner
PIECES = {
    'I': [
        [(1,0), (1,1), (1,2), (1,3)],  # state 0
        [(0,2), (1,2), (2,2), (3,2)],  # state 1
        [(2,0), (2,1), (2,2), (2,3)],  # state 2
        [(0,1), (1,1), (2,1), (3,1)],  # state 3
    ],
    'O': [
        [(0,1), (0,2), (1,1), (1,2)]  # all same
    ],
    'T': [
        [(0,1), (1,0), (1,1), (1,2)],
        [(0,1), (1,1), (1,2), (2,1)],
        [(1,0), (1,1), (1,2), (2,1)],
        [(0,1), (1,0), (1,1), (2,1)]
    ],
    'S': [
        [(0,1), (0,2), (1,0), (1,1)],
        [(0,1), (1,1), (1,2), (2,2)],
        [(1,1), (1,2), (2,0), (2,1)],
        [(0,0), (1,0), (1,1), (2,1)]
    ],
    'Z': [
        [(0,0), (0,1), (1,1), (1,2)],
        [(0,2), (1,1), (1,2), (2,1)],
        [(1,0), (1,1), (2,1), (2,2)],
        [(0,1), (1,0), (1,1), (2,0)]
    ],
    'J': [
        [(0,0), (1,0), (1,1), (1,2)],
        [(0,1), (0,2), (1,1), (2,1)],
        [(1,0), (1,1), (1,2), (2,2)],
        [(0,1), (1,1), (2,0), (2,1)]
    ],
    'L': [
        [(0,2), (1,0), (1,1), (1,2)],
        [(0,1), (1,1), (2,1), (2,2)],
        [(1,0), (1,1), (1,2), (2,0)],
        [(0,0), (0,1), (1,1), (2,1)]
    ]
}

def fits(piece_letter, state, row, col, locked):
    """Check if piece at (row, col) with given state fits on locked board."""
    offsets = PIECES[piece_letter][state]
    for r, c in offsets:
        br, bc = row + r, col + c
        if br < 0 or br >= 20 or bc < 0 or bc >= 10:
            return False
        if locked[br][bc] != '.':
            return False
    return True

def rotate_fits(piece_letter, state, row, col, locked):
    """Check if rotating the piece fits at (row, col) with the new state."""
    new_state = (state + 1) % 4
    offsets = PIECES[piece_letter][new_state]
    for r, c in offsets:
        br, bc = row + r, col + c
        if br < 0 or br >= 20 or bc < 0 or bc >= 10:
            return False
        if locked[br][bc] != '.':
            return False
    return True

def fits_with_shift(piece_letter, state, row, col, shift, locked):
    """Check if rotating and shifting by `shift` columns fits."""
    new_state = (state + 1) % 4
    offsets = PIECES[piece_letter][new_state]
    for r, c in offsets:
        br, bc = row + r, col + shift + c
        if br < 0 or br >= 20 or bc < 0 or bc >= 10:
            return False
        if locked[br][bc] != '.':
            return False
    return True

def place_piece(piece_letter, state, row, col, locked):
    """Place the piece as uppercase on locked board."""
    letter = piece_letter.upper()
    offsets = PIECES[piece_letter][state]
    for r, c in offsets:
        br, bc = row + r, col + c
        locked[br][bc] = letter

def remove_full_rows(locked):
    """Remove all full rows (all 10 cells not '.'), shifting down, add empty rows on top."""
    full_rows = []
    for r in range(20):
        if all(locked[r][c] != '.' for c in range(10)):
            full_rows.append(r)
    # Remove from bottom to top to avoid index issues
    for r in sorted(full_rows, reverse=True):
        del locked[r]
    # Insert empty rows at top
    for _ in full_rows:
        locked.insert(0, ['.'] * 10)
    return len(full_rows)

def draw_board(locked, current_piece):
    """Draw 20 rows of board: '.' for empty, uppercase for locked, lowercase for in-play piece."""
    # If no current piece, just return locked
    if current_piece is None:
        return [''.join(row) for row in locked]
    letter = current_piece['letter']
    state = current_piece['state']
    row = current_piece['row']
    col = current_piece['col']
    offsets = PIECES[letter][state]
    # Build 20x10 grid
    grid = [['.'] * 10 for _ in range(20)]
    # Place locked cells (uppercase)
    for r in range(20):
        for c in range(10):
            cell = locked[r][c]
            if cell != '.':
                grid[r][c] = cell
    # Overlay in-play piece (lowercase)
    for r_off, c_off in offsets:
        rr = row + r_off
        cc = col + c_off
        if 0 <= rr < 20 and 0 <= cc < 10:
            grid[rr][cc] = letter
    return [''.join(row) for row in grid]

def main():
    data = sys.stdin.read().splitlines()
    if not data:
        return
    
    # First line is piece sequence
    piece_sequence = data[0].strip()
    # Remaining lines are commands (whitespace separated)
    commands = []
    for line in data[1:]:
        parts = line.split()
        commands.extend(parts)
    
    # Initialize
    locked = [['.'] * 10 for _ in range(20)]  # only locked cells (uppercase)
    current_piece = None
    game_state = None  # 'PLAYING', 'OVER', 'DONE'
    score = 0
    total_rows_cleared = 0  # LINES in SCORE line (total rows cleared over game)
    piece_index = 0  # index into piece_sequence for next piece
    
    # Helper: score points for clearing c rows
    def score_for_clear(c):
        if c == 1:
            return 100
        if c == 2:
            return 300
        if c == 3:
            return 500
        if c == 4:
            return 800
        return 0
    
    # Spawn first piece if possible
    if piece_sequence:
        letter = piece_sequence[0]
        if letter not in PIECES:
            sys.stderr.write(f"error: unknown piece {letter}\n")
            sys.exit(1)
        # Spawn at (row=0, col=3), state 0
        if fits(letter, 0, 0, 3, locked):
            current_piece = {'letter': letter, 'state': 0, 'row': 0, 'col': 3}
            game_state = 'PLAYING'
            piece_index = 1
        else:
            game_state = 'OVER'
    else:
        game_state = 'DONE'
    
    # Process commands
    for cmd in commands:
        if cmd == 'P':
            # Print current board
            board_lines = draw_board(locked, current_piece)
            # We'll store the final board to print again at the end
            # For now, just print it
            sys.stdout.write('\n'.join(board_lines) + '\n')
            continue
        
        # Unknown command
        if game_state not in ('OVER', 'DONE') and cmd not in ('L', 'R', 'D', 'H', 'CW', 'CCW', 'P'):
            sys.stderr.write(f"error: unknown command {cmd}\n")
        
        if game_state == 'OVER' or game_state == 'DONE':
            continue
        
        # Game is PLAYING, current_piece exists
        cp = current_piece
        if cp is None:
            continue
        
        if cmd == 'L':
            # Try to move left: (row, col-1)
            if fits(cp['letter'], cp['state'], cp['row'], cp['col'] - 1, locked):
                cp['col'] -= 1
        elif cmd == 'R':
            # Try to move right: (row, col+1)
            if fits(cp['letter'], cp['state'], cp['row'], cp['col'] + 1, locked):
                cp['col'] += 1
        elif cmd == 'D':
            # Try to move down: (row+1, col)
            if fits(cp['letter'], cp['state'], cp['row'] + 1, cp['col'], locked):
                cp['row'] += 1
                score += 1
            else:
                # Lock instead
                place_piece(cp['letter'], cp['state'], cp['row'], cp['col'], locked)
                # Remove full rows
                cleared = remove_full_rows(locked)
                total_rows_cleared += cleared
                # Add score for rows cleared
                score += score_for_clear(cleared)
                # Spawn next piece if available
                if piece_index < len(piece_sequence):
                    next_letter = piece_sequence[piece_index]
                    if next_letter not in PIECES:
                        game_state = 'OVER'
                    else:
                        # Spawn at (0, 3) state 0, check fit
                        if fits(next_letter, 0, 0, 3, locked):
                            current_piece = {'letter': next_letter, 'state': 0, 'row': 0, 'col': 3}
                            game_state = 'PLAYING'
                            piece_index += 1
                        else:
                            game_state = 'OVER'
                else:
                    game_state = 'DONE'
                current_piece = None  # piece locked, no current piece
        elif cmd == 'H':
            # Hard drop: find max dr such that piece fits at (row+dr, col)
            # Start from current row
            max_dr = 0
            cur_row = cp['row']
            # Find the lowest row where it fits
            for dr in range(1, 21):
                if fits(cp['letter'], cp['state'], cur_row + dr, cp['col'], locked):
                    max_dr = dr
                else:
                    break
            # Move down max_dr rows
            cp['row'] += max_dr
            score += 2 * max_dr
            # Lock
            place_piece(cp['letter'], cp['state'], cp['row'], cp['col'], locked)
            cleared = remove_full_rows(locked)
            total_rows_cleared += cleared
            score += score_for_clear(cleared)
            # Spawn next piece if available
            if piece_index < len(piece_sequence):
                next_letter = piece_sequence[piece_index]
                if next_letter not in PIECES:
                    game_state = 'OVER'
                else:
                    if fits(next_letter, 0, 0, 3, locked):
                        current_piece = {'letter': next_letter, 'state': 0, 'row': 0, 'col': 3}
                        game_state = 'PLAYING'
                        piece_index += 1
                    else:
                        game_state = 'OVER'
            else:
                game_state = 'DONE'
            current_piece = None
        elif cmd == 'CW':
            # Rotate clockwise: try states in order: current, col-1, col+1, col-2, col+2
            new_state = (cp['state'] + 1) % 4
            # Try positions in order
            positions = [(cp['row'], cp['col']), (cp['row'], cp['col'] - 1),
                         (cp['row'], cp['col'] + 1), (cp['row'], cp['col'] - 2),
                         (cp['row'], cp['col'] + 2)]
            moved = False
            for r, c in positions:
                if fits(cp['letter'], new_state, r, c, locked):
                    cp['row'], cp['col'] = r, c
                    cp['state'] = new_state
                    moved = True
                    break
            # No piece lock, just change state
        elif cmd == 'CCW':
            # Rotate counterclockwise: new_state = (state + 3) % 4
            new_state = (cp['state'] + 3) % 4
            positions = [(cp['row'], cp['col']), (cp['row'], cp['col'] - 1),
                         (cp['row'], cp['col'] + 1), (cp['row'], cp['col'] - 2),
                         (cp['row'], cp['col'] + 2)]
            moved = False
            for r, c in positions:
                if fits(cp['letter'], new_state, r, c, locked):
                    cp['row'], cp['col'] = r, c
                    cp['state'] = new_state
                    moved = True
                    break
        # Note: unknown command already handled above
    
    # Print final board and SCORE line
    board_lines = draw_board(locked, current_piece)
    # Determine final state
    final_state = game_state
    # If game_state was not set (e.g., no pieces), set appropriately
    # game_state should be set: 'PLAYING', 'OVER', or 'DONE'
    # At the very end, print board then SCORE line
    sys.stdout.write('\n'.join(board_lines) + '\n')
    sys.stdout.write(f"SCORE {score} LINES {total_rows_cleared} {final_state}\n")
    
    # Exit with status 0
    sys.exit(0)

if __name__ == '__main__':
    main()
