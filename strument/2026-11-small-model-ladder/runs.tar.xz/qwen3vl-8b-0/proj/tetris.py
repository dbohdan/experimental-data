import sys

# Define the 7 tetris pieces with their 4 rotation states
# Each piece is represented as a list of (row, col) offsets in a 4x4 box
PIECES = {
    'I': [(1,0), (1,1), (1,2), (1,3)],
    'O': [(0,1), (0,2), (1,1), (1,2)],
    'T': [(0,1), (1,0), (1,1), (1,2)],
    'S': [(0,1), (0,2), (1,0), (1,1)],
    'Z': [(0,0), (0,1), (1,1), (1,2)],
    'J': [(0,0), (1,0), (1,1), (1,2)],
    'L': [(0,2), (1,0), (1,1), (1,2)],
}

# Board dimensions
BOARD_WIDTH = 10
BOARD_HEIGHT = 20

# Initialize empty board
board = [['.' for _ in range(BOARD_WIDTH)] for _ in range(BOARD_HEIGHT)]

# Game state
score = 0
lines_cleared = 0
game_state = 'PLAYING'  # 'PLAYING', 'OVER', or 'DONE'

# Current piece and its state
current_piece = None
current_state = 0

# Piece sequence
piece_sequence = []

# Current piece position
current_row = 0
current_col = 3

# Read piece sequence from first line
first_line = sys.stdin.readline().strip()
if first_line:
    piece_sequence = list(first_line)

# Function to check if a piece fits at a given position and state
def piece_fits(row, col, piece, state):
    if piece is None:
        return False
    for r, c in PIECES[piece][state]:
        board_row = row + r
        board_col = col + c
        # Check if the block is within bounds and not occupied
        if board_row < 0 or board_row >= BOARD_HEIGHT or board_col < 0 or board_col >= BOARD_WIDTH:
            return False
        if board[board_row][board_col] != '.':
            return False
    return True

# Function to get the blocks of a piece at a given position and state
def get_piece_blocks(row, col, piece, state):
    blocks = []
    for r, c in PIECES[piece][state]:
        board_row = row + r
        board_col = col + c
        blocks.append((board_row, board_col))
    return blocks

# Function to check if a piece can be rotated at current position
def can_rotate(piece, state):
    global current_piece
    if current_piece is None:
        return False
    # Try the new state at the current position
    new_state = (state + 1) % 4
    if piece_fits(current_row, current_col, current_piece, new_state):
        return True
    
    # Try shifting by -1, +1, -2, +2 columns
    for shift in [-1, 1, -2, 2]:
        new_col = current_col + shift
        if piece_fits(current_row, new_col, current_piece, new_state):
            return True
    
    return False

# Function to rotate the piece
def rotate_piece(piece):
    global current_state
    if current_piece is None:
        return
    if can_rotate(piece, current_state):
        current_state = (current_state + 1) % 4

# Function to move piece left
def move_left():
    global current_col
    if current_piece is None:
        return
    if current_col > 0 and piece_fits(current_row, current_col - 1, current_piece, current_state):
        current_col -= 1

# Function to move piece right
def move_right():
    global current_col
    if current_piece is None:
        return
    if current_col < BOARD_WIDTH - 1 and piece_fits(current_row, current_col + 1, current_piece, current_state):
        current_col += 1

# Function to move piece down
def move_down():
    global current_row, score
    if current_piece is None:
        return False
    if piece_fits(current_row + 1, current_col, current_piece, current_state):
        current_row += 1
        return True  # Piece moved down
    else:
        # Piece locks
        lock_piece()
        return False  # Piece didn't move

# Function to hard drop
def hard_drop():
    global current_row, score
    if current_piece is None:
        return
    # Move down as many rows as possible
    rows_moved = 0
    while piece_fits(current_row + 1, current_col, current_piece, current_state):
        current_row += 1
        rows_moved += 1
    # Lock the piece
    lock_piece()
    # Add score
    score += rows_moved * 2

# Function to lock the piece
def lock_piece():
    global current_row, current_col, current_piece, current_state, game_state, lines_cleared
    # Place the piece on the board
    if current_piece is None:
        return
    blocks = get_piece_blocks(current_row, current_col, current_piece, current_state)
    for board_row, board_col in blocks:
        board[board_row][board_col] = current_piece
    
    # Check for completed rows
    completed_rows = []
    for row in range(BOARD_HEIGHT):
        if all(board[row][col] != '.' for col in range(BOARD_WIDTH)):
            completed_rows.append(row)
    
    # Remove completed rows and shift down
    for row in reversed(completed_rows):
        # Remove the row
        for col in range(BOARD_WIDTH):
            board[row][col] = '.'
        # Shift all rows above down
        for r in range(row, 0, -1):
            for c in range(BOARD_WIDTH):
                board[r][c] = board[r-1][c]
        # Add empty row at the top
        for c in range(BOARD_WIDTH):
            board[0][c] = '.'
        
    # Update score
    if len(completed_rows) == 1:
        score += 100
    elif len(completed_rows) == 2:
        score += 300
    elif len(completed_rows) == 3:
        score += 500
    elif len(completed_rows) == 4:
        score += 800
    
    # Update lines cleared
    lines_cleared += len(completed_rows)
    
    # Check if game is over (next piece doesn't fit)
    if not spawn_next_piece():
        game_state = 'OVER'

# Function to spawn the next piece
def spawn_next_piece():
    global current_piece, current_state, current_row, current_col
    if not piece_sequence:
        game_state = 'DONE'
        return False
    
    current_piece = piece_sequence[0]
    piece_sequence.pop(0)
    
    # Check if piece fits at spawn position
    if current_piece is None:
        game_state = 'OVER'
        return False
    
    if not piece_fits(0, 3, current_piece, 0):
        game_state = 'OVER'
        return False
    
    current_state = 0
    current_row = 0
    current_col = 3
    
    return True

# Function to print the current game state
def print_game():
    # Print the board
    for row in board:
        print(''.join(row))
    
    # Print score, lines cleared, and game state
    print(f'SCORE {score} LINES {lines_cleared} {game_state}')

# Main game loop
for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    
    # Process each command
    for command in line.split():
        if command == 'L':
            move_left()
        elif command == 'R':
            move_right()
        elif command == 'D':
            if move_down():
                score += 1
        elif command == 'H':
            hard_drop()
        elif command == 'CW':
            rotate_piece(current_piece)
        elif command == 'CCW':
            # Rotate counterclockwise (state + 3) mod 4
            current_state = (current_state + 3) % 4
        elif command == 'P':
            print_game()
        else:
            print(f'error: unknown command {command}', file=sys.stderr)

# Print final state after all input is processed
print_game()

# Exit with status 0
sys.exit(0)