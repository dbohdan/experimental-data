import sys

BOARD_ROWS = 20
BOARD_COLS = 10

# Blocks of each piece as (r, c) offsets in its 4x4 box, for states 0..3.
SHAPES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)],
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)],
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)],
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)],
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)],
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)],
    ],
}

# Points for clearing rows in one go.
ROW_POINTS = {1: 100, 2: 300, 3: 500, 4: 800}

# Mutable game state.
board = None
current = None      # piece state dict or None when no piece in play
sequence = []
index = 0           # index into sequence
state = 'PLAYING'   # 'PLAYING', 'OVER' or 'DONE'
score = 0
lines_cleared = 0


def new_piece(letter):
    """Create the piece in its spawn position (row 0, col 3, state 0)."""
    return {'letter': letter, 'state': 0, 'row': 0, 'col': 3}


def fits(letter, state, row, col):
    """True when the piece's blocks at this position/state are on the board and empty."""
    for r, c in SHAPES[letter][state]:
        rr = row + r
        cc = col + c
        if rr < 0 or rr >= BOARD_ROWS or cc < 0 or cc >= BOARD_COLS:
            return False
        if board[rr][cc] != '.':
            return False
    return True


def print_board():
    for row in board:
        print(''.join(row))


def clear_rows():
    """Remove every full row, closing gaps. Returns the number of rows removed."""
    removed = [r for r in range(BOARD_ROWS) if all(board[r][c] != '.' for c in range(BOARD_COLS))]
    for r in removed:
        del board[r]
    for r in removed:
        board.append(['.'] * BOARD_COLS)
    return len(removed)


def spawn_next():
    """Spawn the next piece from the sequence, or end the game."""
    global index, current, state
    if index < len(sequence):
        letter = sequence[index]
        index += 1
        if fits(letter, 0, 0, 3):
            current = new_piece(letter)
            state = 'PLAYING'
        else:
            state = 'OVER'
            current = None
    else:
        state = 'DONE'


def lock(letter, state, row, col):
    """Lock the current piece and clear the board after it."""
    global score, lines_cleared
    for r, c in SHAPES[letter][state]:
        board[row + r][col + c] = letter
    removed = clear_rows()
    lines_cleared += removed
    if removed:
        score += ROW_POINTS[removed]
    spawn_next()


def handle_command(cmd):
    global current, score, lines_cleared, state
    if current is None:
        return
    letter = current['letter']
    state = current['state']
    row = current['row']
    col = current['col']
    if cmd == 'L':
        if fits(letter, state, row, col - 1):
            current['col'] = col - 1
    elif cmd == 'R':
        if fits(letter, state, row, col + 1):
            current['col'] = col + 1
    elif cmd == 'D':
        if fits(letter, state, row + 1, col):
            current['row'] = row + 1
            score += 1
        else:
            lock(letter, state, row, col)
    elif cmd == 'H':
        moved = 0
        for k in range(1, BOARD_ROWS + 1):
            if fits(letter, state, row + k, col):
                moved = k
            else:
                break
        current['row'] = row + moved
        score += 2 * moved
        lock(letter, state, row, col)
    elif cmd == 'CW':
        new_state = (state + 1) % 4
        result = rotate(letter, new_state, row, col)
        if result is None:
            return
        current['state'] = result[0]
        current['row'] = result[1]
        current['col'] = result[2]
    elif cmd == 'CCW':
        new_state = (state + 3) % 4
        result = rotate(letter, new_state, row, col)
        if result is None:
            return
        current['state'] = result[0]
        current['row'] = result[1]
        current['col'] = result[2]
    elif cmd == 'P':
        print_board()
    else:
        sys.stderr.write(f'error: unknown command {cmd}\n')


def rotate(letter, new_state, row, col):
    """Rotate to new_state, trying the current position then column shifts.
    Returns (state, row, col) on success, else None."""
    for shift in (0, -1, 1, -2, 2):
        if fits(letter, new_state, row, col + shift):
            return new_state, row, col + shift
    return None


def main():
    global board
    data = sys.stdin.read()
    lines = data.splitlines()
    if not lines:
        return

    sequence = lines[0].strip()
    commands = []
    for line in lines[1:]:
        commands.extend(line.split())
    sequence = list(sequence)

    board = [['.'] * BOARD_COLS for _ in range(BOARD_ROWS)]
    spawn_next()

    for cmd in commands:
        handle_command(cmd)

    print_board()
    print(f'SCORE {score} LINES {lines_cleared} {state}')


if __name__ == '__main__':
    main()
