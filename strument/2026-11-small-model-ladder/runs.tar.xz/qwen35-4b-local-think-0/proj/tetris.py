#!/usr/bin/env python3
"""Headless Tetris - plays from input commands."""

import sys

# Piece definitions: each state is a list of (r, c) offsets
# State 0, 1, 2, 3 for each piece
PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)],
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)],
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)],
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)],
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)],
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)],
    ],
}

SCORES = {1: 100, 2: 300, 3: 500, 4: 800}


def make_board():
    """Create empty 10x20 board."""
    return [['.' for _ in range(10)] for _ in range(20)]


def piece_fits(board, piece_shape, row, col):
    """Check if piece at (row, col) fits (all cells on board and empty)."""
    for offset in piece_shape:
        dr, dc = offset
        r, c = row + dr, col + dc
        if r < 0 or r >= 20 or c < 0 or c >= 10:
            return False
        if board[r][c] != '.':
            return False
    return True


def lock_piece(board, piece_shape, row, col, piece_type):
    """Lock piece cells onto board."""
    for offset in piece_shape:
        dr, dc = offset
        r, c = row + dr, col + dc
        board[r][c] = piece_type


def clear_rows(board):
    """Clear full rows, return number of rows cleared."""
    rows_to_clear = []
    for r in range(20):
        if all(board[r][c] != '.' for c in range(10)):
            rows_to_clear.append(r)
    
    if not rows_to_clear:
        return 0
    
    # Score based on rows cleared
    score = SCORES.get(len(rows_to_clear), 0)
    
    # Remove cleared rows and shift down
    # Collect remaining rows
    remaining = []
    for r in range(20):
        if r not in rows_to_clear:
            remaining.append(board[r][:])
    
    # Add empty rows at top
    num_empty = 20 - len(remaining)
    for _ in range(num_empty):
        remaining.append(['.' * 10])
    
    board = remaining
    
    return len(rows_to_clear)


def apply_command(board, piece_shape, row, col, piece_type, piece_state, command):
    """Apply a command and return (new_board, new_row, new_col, new_state, score, locked)."""
    new_board = [list(r) for r in board]
    new_row = row
    new_col = col
    new_state = piece_state
    score = 0
    locked = False
    
    if command == 'L':
        if piece_fits(board, piece_shape, row, col - 1):
            new_col = col - 1
            score = 1
    elif command == 'R':
        if piece_fits(board, piece_shape, row, col + 1):
            new_col = col + 1
            score = 1
    elif command == 'D':
        if piece_fits(board, piece_shape, row + 1, col):
            new_row = row + 1
            score = 1
        else:
            locked = True
            lock_piece(new_board, piece_shape, row, col, piece_type)
            cleared = clear_rows(new_board)
            score += SCORES.get(cleared, 0)
    elif command == 'H':
        # Hard drop - drop as far as possible
        while piece_fits(board, piece_shape, row + 1, col):
            row += 1
        new_row = row
        score = row * 2
        locked = True
        lock_piece(new_board, piece_shape, new_row, col, piece_type)
        cleared = clear_rows(new_board)
        score += SCORES.get(cleared, 0)
    elif command == 'CW':
        new_state = (piece_state + 1) % 4
        piece_shape = PIECES[piece_type][new_state]
    elif command == 'CCW':
        new_state = (piece_state + 3) % 4
        piece_shape = PIECES[piece_type][new_state]
    elif command == 'P':
        print_board(new_board)
    else:
        print(f"error: unknown command {command}", file=sys.stderr)
        return new_board, new_row, new_col, new_state, score, False
    
    return new_board, new_row, new_col, new_state, score, locked


def print_board(board):
    """Print board to stdout."""
    for row in board:
        print(''.join(row))


def main():
    with open(sys.argv[1], 'r') as f:
        lines = f.readlines()
    
    # Parse input
    sequence = lines[0].strip()
    commands = []
    for line in lines[1:]:
        line = line.strip()
        if line:
            commands.extend(line.split())
    
    # Initialize board
    board = make_board()
    score = 0
    lines_cleared = 0
    game_state = 'PLAYING'
    piece_type = None
    piece_shape = None
    piece_row = 0
    piece_col = 3
    piece_state = 0
    sequence_idx = 0
    
    # Spawn first piece
    if sequence_idx < len(sequence):
        piece_type = sequence[sequence_idx]
        piece_shape = PIECES[piece_type][piece_state]  # Get offsets for current state
        piece_row = 0
        piece_col = 3
        sequence_idx += 1
    
    # Process commands
    for cmd in commands:
        if piece_type is None:
            continue
        
        if cmd == 'P':
            print_board(board)
        else:
            new_board, new_row, new_col, new_state, score, locked = apply_command(
                board, piece_shape, piece_row, piece_col, piece_type, piece_state, cmd)
            board = new_board
            piece_row = new_row
            piece_col = new_col
            piece_state = new_state
            score = score
            if locked:
                piece_type = None
                piece_shape = None
                if piece_type is None and sequence_idx < len(sequence):
                    piece_type = sequence[sequence_idx]
                    piece_shape = PIECES[piece_type][piece_state]
                    piece_row = 0
                    piece_col = 3
                    piece_state = 0
                    sequence_idx += 1
                else:
                    game_state = 'OVER'
    
    # Print final board
    print_board(board)
    print(f"SCORE {score} LINES {lines_cleared} {game_state}")


if __name__ == '__main__':
    main()
