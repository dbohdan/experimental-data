#!/usr/bin/env python3
"""Headless Tetris: plays the game from commands on stdin, prints board to stdout."""

import sys

BOARD_W = 10
BOARD_H = 20

PIECE_TYPES = {'I', 'O', 'T', 'S', 'Z', 'J', 'L'}

PIECE_SHAPES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)],
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 1)],
        [(0, 1), (1, 0), (1, 1), (2, 1)],
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 1), (1, 2), (2, 0), (2, 1)],
        [(0, 0), (1, 0), (1, 1), (2, 1)],
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(0, 2), (1, 1), (1, 2), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 0)],
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 0), (2, 1)],
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 0)],
        [(0, 0), (0, 1), (1, 1), (2, 1)],
    ],
}


def piece_valid(piece_type, piece_state, piece_row, piece_col):
    """Check if piece fits at given position and state."""
    shape = PIECE_SHAPES[piece_type]
    for r, c in shape[piece_state]:
        br = piece_row + r
        bc = piece_col + c
        if br < 0 or br >= BOARD_H or bc < 0 or bc >= BOARD_W:
            return False
        if board[br][bc] != '.':
            return False
    return True


def place_piece(piece_type, piece_state, piece_row, piece_col):
    """Place the piece on the board, locking its blocks."""
    shape = PIECE_SHAPES[piece_type]
    for r, c in shape[piece_state]:
        br = piece_row + r
        bc = piece_col + c
        board[br][bc] = piece_type


def clear_lines():
    """Remove full rows, shift down, count rows removed."""
    global score, lines_cleared
    full_rows = []
    for r in range(BOARD_H):
        if all(board[r][c] != '.' for c in range(BOARD_W)):
            full_rows.append(r)
    if not full_rows:
        return
    lines_cleared += len(full_rows)
    points = [0, 100, 300, 500, 800]
    score += points[len(full_rows)]
    # Remove full rows
    for r in sorted(full_rows, reverse=True):
        del board[r]
    # Add empty rows at top
    for _ in range(len(full_rows)):
        board.insert(0, ['.' for _ in range(BOARD_W)])


def spawn_piece():
    """Spawn a new piece at row 0, col 3 in state 0.
    Returns True if a new piece was spawned, False if the game is over."""
    global current_type, current_state, current_col, current_row, over, done
    if not sequence:
        done = True
        return False
    piece_type = sequence.pop(0)
    if piece_type not in PIECE_TYPES:
        return False
    current_type = piece_type
    current_state = 0
    current_col = 3
    current_row = 0
    if not piece_valid(piece_type, 0, 0, 3):
        over = True
        return False
    place_piece(piece_type, 0, 0, 3)
    return True


def try_move(direction):
    """Try to move the piece one column in the given direction.
    Returns True if the move was successful, False otherwise."""
    global current_col
    new_col = current_col + direction
    if piece_valid(current_type, current_state, current_row, new_col):
        current_col = new_col
        return True
    return False


def try_move_down():
    """Try to move the piece one row down.
    Returns (moved, score_added)."""
    global current_row, score, lines_cleared
    if piece_valid(current_type, current_state, current_row + 1, current_col):
        current_row += 1
        return True, 0
    return False, 0


def try_hard_drop():
    """Hard drop: move the piece down as many rows as it fits, add 2 per row, then lock."""
    global current_row, score, lines_cleared
    drops = 0
    while piece_valid(current_type, current_state, current_row + 1, current_col):
        current_row += 1
        drops += 1
    score += drops * 2
    place_piece(current_type, current_state, current_row, current_col)


def try_rotate(cw):
    """Try to rotate the piece clockwise (or counterclockwise). Returns True if rotated."""
    global current_state, current_col
    new_state = (current_state + (1 if cw else 3)) % 4
    # Try the new state at current position, then with column shifted by -1, +1, -2, +2
    if piece_valid(current_type, new_state, current_row, current_col):
        current_state = new_state
        return True
    # Try shifted positions
    for shift in (-1, 1, -2, 2):
        if piece_valid(current_type, new_state, current_row, current_col + shift):
            current_state = new_state
            current_col += shift
            return True
    return False


def print_board():
    """Print the current board."""
    for r in range(BOARD_H):
        line = ''
        for c in range(BOARD_W):
            cell = board[r][c]
            if cell == '.':
                line += '.'
            elif cell == 'I' or cell == 'O' or cell == 'T' or cell == 'S' or cell == 'Z' or cell == 'J' or cell == 'L':
                line += cell
            else:
                line += cell
        print(line)


def main():
    global sequence, board, score, lines_cleared, over, done

    data = sys.stdin.read()
    lines = data.splitlines()
    if not lines:
        return

    sequence = list(lines[0].strip())
    commands_raw = []
    for i in range(1, len(lines)):
        parts = lines[i].split()
        commands_raw.extend(parts)

    commands = []
    for c in commands_raw:
        if c in ('L', 'R', 'D', 'H', 'CW', 'CCW', 'P'):
            commands.append(c)
        else:
            sys.stderr.write(f'error: unknown command {c}\n')

    board = [['.' for _ in range(BOARD_W)] for _ in range(BOARD_H)]
    score = 0
    lines_cleared = 0
    over = False
    done = False

    # Initial spawn
    spawn_piece()

    for cmd in commands:
        if done:
            break
        if over:
            # Still process commands but don't place anything
            break
        if cmd == 'P':
            print_board()
            continue
        # No piece in play
        if current_type is None:
            continue
        if cmd == 'L':
            try_move(-1)
        elif cmd == 'R':
            try_move(1)
        elif cmd == 'D':
            moved, added = try_move_down()
            if moved:
                score += 1
            else:
                place_piece(current_type, current_state, current_row, current_col)
        elif cmd == 'H':
            try_hard_drop()
        elif cmd == 'CW':
            try_rotate(True)
        elif cmd == 'CCW':
            try_rotate(False)
        else:
            sys.stderr.write(f'error: unknown command {cmd}\n')

    # Print final board
    print_board()

    if over:
        print(f'SCORE {score} LINES {lines_cleared} OVER')
    elif done:
        print(f'SCORE {score} LINES {lines_cleared} DONE')
    else:
        print(f'SCORE {score} LINES {lines_cleared} PLAYING')


if __name__ == '__main__':
    main()
