#!/usr/bin/env python3

WIDTH = 10
HEIGHT = 20

PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 1), (1, 1), (2, 1), (3, 1)],
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
    ],
}

def is_on_board(row, col):
    return 0 <= row < HEIGHT and 0 <= col < WIDTH

def is_fits(board, piece_type, state, row, col):
    offsets = PIECES[piece_type][state]
    for r, c in offsets:
        br, bc = row + r, col + c
        if not is_on_board(br, bc):
            return False
        if board[br][bc] != '.':
            return False
    return True

board = [['.'] * WIDTH for _ in range(HEIGHT)]

# Spawn I piece
print("Spawning I piece...")
print(is_fits(board, 'I', 0, 0, 3))
print("Board after spawn:")
for row in board:
    print(''.join(row))
