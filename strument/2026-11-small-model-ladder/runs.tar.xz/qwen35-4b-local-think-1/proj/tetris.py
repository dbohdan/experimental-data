#!/usr/bin/env python3
"""Headless Tetris - plays from input commands."""

import sys

# Board: 10 columns, 20 rows
# Row 0 is top, row 19 is bottom
# Column 0 is left, column 9 is right
WIDTH = 10
HEIGHT = 20

# Piece definitions: for each piece type, 4 rotation states
# Each state is a list of (r, c) offsets in the 4x4 box
PIECES = {
    'I': [
        [(1, 0), (1, 1), (1, 2), (1, 3)],  # state 0: horizontal
        [(0, 2), (1, 2), (2, 2), (3, 2)],  # state 1: vertical
        [(2, 0), (2, 1), (2, 2), (2, 3)],  # state 2: horizontal
        [(0, 1), (1, 1), (2, 1), (3, 1)],  # state 3: vertical
    ],
    'O': [
        [(0, 1), (0, 2), (1, 1), (1, 2)],  # all states same
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
        [(0, 1), (0, 2), (1, 1), (1, 2)],
    ],
    'T': [
        [(0, 1), (1, 0), (1, 1), (1, 2)],  # state 0
        [(0, 1), (1, 1), (1, 2), (2, 1)],  # state 1
        [(1, 0), (1, 1), (1, 2), (2, 1)],  # state 2
        [(0, 1), (1, 0), (1, 1), (2, 1)],  # state 3
    ],
    'S': [
        [(0, 1), (0, 2), (1, 0), (1, 1)],  # state 0
        [(0, 1), (1, 1), (1, 2), (2, 2)],  # state 1
        [(1, 1), (1, 2), (2, 0), (2, 1)],  # state 2
        [(0, 0), (1, 0), (1, 1), (2, 1)],  # state 3
    ],
    'Z': [
        [(0, 0), (0, 1), (1, 1), (1, 2)],  # state 0
        [(0, 2), (1, 1), (1, 2), (2, 1)],  # state 1
        [(1, 0), (1, 1), (2, 1), (2, 2)],  # state 2
        [(0, 1), (1, 0), (1, 1), (2, 0)],  # state 3
    ],
    'J': [
        [(0, 0), (1, 0), (1, 1), (1, 2)],  # state 0
        [(0, 1), (0, 2), (1, 1), (2, 1)],  # state 1
        [(1, 0), (1, 1), (1, 2), (2, 2)],  # state 2
        [(0, 1), (1, 1), (2, 0), (2, 1)],  # state 3
    ],
    'L': [
        [(0, 2), (1, 0), (1, 1), (1, 2)],  # state 0
        [(0, 1), (1, 1), (2, 1), (2, 2)],  # state 1
        [(1, 0), (1, 1), (1, 2), (2, 0)],  # state 2
        [(0, 0), (0, 1), (1, 1), (2, 1)],  # state 3
    ],
}

# Score for clearing rows
ClearedRowScores = {1: 100, 2: 300, 3: 500, 4: 800}


def is_on_board(row, col):
    """Check if a cell is on the board."""
    return 0 <= row < HEIGHT and 0 <= col < WIDTH


def is_fits(board, piece_type, state, row, col):
    """Check if a piece fits at the given position and state."""
    offsets = PIECES[piece_type][state]
    for r, c in offsets:
        br, bc = row + r, col + c
        # Check bounds
        if not is_on_board(br, bc):
            return False
        # Check if cell is occupied
        if board[br][bc] != '.':
            return False
    return True


def apply_piece(board, piece_type, state, row, col):
    """Apply a piece to the board, returning the modified board."""
    new_board = [list(row) for row in board]
    offsets = PIECES[piece_type][state]
    for r, c in offsets:
        br, bc = row + r, col + c
        new_board[br][bc] = piece_type
    return new_board


def clear_full_rows(board):
    """Clear all full rows and return (new_board, rows_cleared, score)."""
    rows_to_clear = []
    for r in range(HEIGHT):
        if all(board[r][c] != '.' for c in range(WIDTH)):
            rows_to_clear.append(r)
    
    if not rows_to_clear:
        return board, 0, 0
    
    rows_cleared = len(rows_to_clear)
    score = ClearedRowScores[rows_cleared]
    
    # Remove cleared rows and shift remaining rows down
    new_board = []
    for r in range(HEIGHT):
        if r not in rows_to_clear:
            new_board.append(board[r])
    
    # Add empty rows at the top
    while len(new_board) < HEIGHT:
        new_board.append(['.'] * WIDTH)
    
    return new_board, rows_cleared, score


def get_cells(board, piece_type, state, row, col):
    """Get all cells occupied by a piece at the given position and state."""
    offsets = PIECES[piece_type][state]
    cells = []
    for r, c in offsets:
        br, bc = row + r, col + c
        if is_on_board(br, bc):
            cells.append((br, bc))
    return cells


def rotate_clockwise(board, piece_type, row, col):
    """Rotate clockwise, returning (new_board, new_state) or (board, None) if no fit."""
    for shift in [-2, -1, 0, 1, 2]:
        new_state = (PIECES[piece_type].index(get_cells(board, piece_type, 0, row + shift, col + shift)) + 1) % 4
        if is_fits(board, piece_type, new_state, row, col):
            return apply_piece(board, piece_type, new_state, row, col), new_state
    return board, None


def rotate_counterclockwise(board, piece_type, row, col):
    """Rotate counterclockwise, returning (new_board, new_state) or (board, None) if no fit."""
    for shift in [-2, -1, 0, 1, 2]:
        new_state = (PIECES[piece_type].index(get_cells(board, piece_type, 0, row + shift, col + shift)) + 3) % 4
        if is_fits(board, piece_type, new_state, row, col):
            return apply_piece(board, piece_type, new_state, row, col), new_state
    return board, None


def move_left(board, piece_type, row, col):
    """Move left, returning (new_board, new_col) or (board, None) if no fit."""
    if is_fits(board, piece_type, 0, row, col - 1):
        return apply_piece(board, piece_type, 0, row, col - 1), col - 1
    return board, None


def move_right(board, piece_type, row, col):
    """Move right, returning (new_board, new_col) or (board, None) if no fit."""
    if is_fits(board, piece_type, 0, row, col + 1):
        return apply_piece(board, piece_type, 0, row, col + 1), col + 1
    return board, None


def move_down(board, piece_type, row, col):
    """Move down, returning (new_board, new_row, score) or (board, None, 0) if no fit."""
    if is_fits(board, piece_type, 0, row + 1, col):
        return apply_piece(board, piece_type, 0, row + 1, col), row + 1, 1
    return board, None, 0


def hard_drop(board, piece_type, row, col):
    """Hard drop, returning (new_board, new_row, score) or (board, None, 0) if no fit."""
    moved = 0
    while is_fits(board, piece_type, 0, row + 1, col):
        row += 1
        moved += 1
    return apply_piece(board, piece_type, 0, row, col), row, moved * 2


def print_board(board):
    """Print the board to stdout."""
    for row in board:
        print(''.join(row))


def main():
    # Read input
    input_data = sys.stdin.read().split()
    
    if not input_data:
        return
    
    # First line is the piece sequence
    piece_sequence = input_data[0]
    
    # Rest are commands
    commands = input_data[1:]
    
    # Initialize board
    board = [['.'] * WIDTH for _ in range(HEIGHT)]
    
    # Track state
    current_piece = None  # piece type or None
    current_state = 0
    current_row = 0
    current_col = 3
    score = 0
    lines_cleared = 0
    game_over = False  # spawn failed
    done = False  # sequence exhausted
    
    # Process commands
    for cmd in commands:
        if game_over or (current_piece is None and cmd != 'P'):
            continue
        
        if cmd == 'L':
            if current_piece is not None:
                new_board, new_col = move_left(board, current_piece, current_row, current_col)
                if new_board is not None:
                    board = new_board
                    current_col = new_col
        elif cmd == 'R':
            if current_piece is not None:
                new_board, new_col = move_right(board, current_piece, current_row, current_col)
                if new_board is not None:
                    board = new_board
                    current_col = new_col
        elif cmd == 'D':
            if current_piece is not None:
                new_board, new_row, s = move_down(board, current_piece, current_row, current_col)
                if new_board is not None:
                    board = new_board
                    current_row = new_row
                    score += s
                else:
                    # Lock piece
                    board = apply_piece(board, current_piece, current_state, current_row, current_col)
                    board, rows_cleared, s = clear_full_rows(board)
                    score += s
                    lines_cleared += rows_cleared
                    current_piece = None
        elif cmd == 'H':
            if current_piece is not None:
                new_board, new_row, s = hard_drop(board, current_piece, current_row, current_col)
                if new_board is not None:
                    board = new_board
                    current_row = new_row
                    score += s
                    # Lock piece
                    board = apply_piece(board, current_piece, current_state, current_row, current_col)
                    board, rows_cleared, s = clear_full_rows(board)
                    score += s
                    lines_cleared += rows_cleared
                    current_piece = None
        elif cmd == 'CW':
            if current_piece is not None:
                new_board, new_state = rotate_clockwise(board, current_piece, current_row, current_col)
                if new_board is not None:
                    board = new_board
                    current_state = new_state
        elif cmd == 'CCW':
            if current_piece is not None:
                new_board, new_state = rotate_counterclockwise(board, current_piece, current_row, current_col)
                if new_board is not None:
                    board = new_board
                    current_state = new_state
        elif cmd == 'P':
            print_board(board)
    
    # Print final board
    print_board(board)
    
    # Determine state
    if current_piece is None and not game_over:
        state = 'DONE'
    elif game_over:
        state = 'OVER'
    else:
        state = 'PLAYING'
    
    print(f'SCORE {score} LINES {lines_cleared} {state}')
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
