#!/usr/bin/env python3
import sys

PIECE_OFFSETS = {
    'I': [(1,0),(1,1),(1,2),(1,3)],
    'I1': [(0,2),(1,2),(2,2),(3,2)],  # not used, better dict
}
# Better: piece -> list of states each state list of (r,c)
PIECE = {
    'I': [
        [(1,0),(1,1),(1,2),(1,3)],
        [(0,2),(1,2),(2,2),(3,2)],
        [(2,0),(2,1),(2,2),(2,3)],
        [(0,1),(1,1),(2,1),(3,1)],
    ],
    'O': [
        [(0,1),(0,2),(1,1),(1,2)],
        [(0,1),(0,2),(1,1),(1,2)],
        [(0,1),(0,2),(1,1),(1,2)],
        [(0,1),(0,2),(1,1),(1,2)],
    ],
    'T': [
        [(0,1),(1,0),(1,1),(1,2)],
        [(0,1),(1,1),(1,2),(2,1)],
        [(1,0),(1,1),(1,2),(2,1)],
        [(0,1),(1,0),(1,1),(2,1)],
    ],
    'S': [
        [(0,1),(0,2),(1,0),(1,1)],
        [(0,1),(1,1),(1,2),(2,2)],
        [(1,1),(1,2),(2,0),(2,1)],
        [(0,0),(1,0),(1,1),(2,1)],
    ],
    'Z': [
        [(0,0),(0,1),(1,1),(1,2)],
        [(0,2),(1,1),(1,2),(2,1)],
        [(1,0),(1,1),(2,1),(2,2)],
        [(0,1),(1,0),(1,1),(2,0)],
    ],
    'J': [
        [(0,0),(1,0),(1,1),(1,2)],
        [(0,1),(0,2),(1,1),(2,1)],
        [(1,0),(1,1),(1,2),(2,2)],
        [(0,1),(1,1),(2,0),(2,1)],
    ],
    'L': [
        [(0,2),(1,0),(1,1),(1,2)],
        [(0,1),(1,1),(2,1),(2,2)],
        [(1,0),(1,1),(1,2),(2,0)],
        [(0,0),(0,1),(1,1),(2,1)],
    ],
}

def fits(board, row, col, blocks):
    for dr, dc in blocks:
        r = row + dr
        c = col + dc
        if r < 0 or r >= 20 or c < 0 or c >= 10:
            return False
        if board[r][c] != '.':
            return False
    return True

def render(board, cur_letter, cur_state, cur_row, cur_col):
    lines = []
    for r in range(20):
        line = []
        for c in range(10):
            if board[r][c] != '.':
                line.append(board[r][c])
            else:
                if cur_letter is not None:
                    found = False
                    for dr, dc in PIECE[cur_letter][cur_state]:
                        if r == cur_row + dr and c == cur_col + dc:
                            line.append(cur_letter.lower())
                            found = True
                            break
                    if not found:
                        line.append('.')
                else:
                    line.append('.')
        lines.append(''.join(line))
    return lines

def main():
    print(f"main called with stdin data:", file=sys.stderr)
    data = sys.stdin.read().split()
    print(f"data = {data}", file=sys.stderr)
    if not data:
        return
    piece_seq = data[0]
    commands = data[1:]
    print(f"piece_seq={piece_seq}, commands={commands}", file=sys.stderr)
    
    board = [['.'] * 10 for _ in range(20)]
    game_state = None  # 'PLAYING', 'OVER', 'DONE'
    cur_letter = None
    cur_state = None
    cur_row = None
    cur_col = None
    
    piece_idx = 0  # index of next piece to spawn (0-based)
    # spawn first piece
    if piece_seq:
        first = piece_seq[0]
        blocks0 = PIECE[first][0]
        if fits(board, 0, 3, blocks0):
            cur_letter = first
            cur_state = 0
            cur_row = 0
            cur_col = 3
            piece_idx += 1
            game_state = 'PLAYING'
        else:
            game_state = 'OVER'
    else:
        game_state = 'DONE'
    
    score = 0
    last_cleared_rows = 0
    
    def render_and_score():
        nonlocal board, cur_letter, cur_state, cur_row, cur_col, game_state
        lines = render(board, cur_letter, cur_state, cur_row, cur_col)
        for line in lines:
            print(line)
        if game_state == 'PLAYING':
            state_str = 'PLAYING'
        elif game_state == 'OVER':
            state_str = 'OVER'
        else:
            state_str = 'DONE'
        print(f"SCORE {score} LINES {last_cleared_rows} {state_str}")
    
    def lock():
        nonlocal board, game_state, piece_idx, score, last_cleared_rows, cur_letter, cur_state, cur_row, cur_col
        # place current piece as uppercase
        blocks = PIECE[cur_letter][cur_state]
        for dr, dc in blocks:
            board[cur_row+dr][cur_col+dc] = cur_letter  # uppercase
        # find full rows
        full = []
        for r in range(20):
            if all(board[r][c] != '.' for c in range(10)):
                full.append(r)
        rows_cleared = len(full)
        print(f"LOCK full rows {full}, rows_cleared={rows_cleared}", file=sys.stderr)
        # clear rows
        kept = [r for r in range(20) if r not in full]
        new_board = [['.'] * 10 for _ in range(20)]
        idx = 0
        for r in kept:
            for c in range(10):
                new_board[idx][c] = board[r][c]
            idx += 1
        board[:] = new_board
        # points
        if rows_cleared == 1:
            pts = 100
        elif rows_cleared == 2:
            pts = 300
        elif rows_cleared == 3:
            pts = 500
        elif rows_cleared == 4:
            pts = 800
        else:
            pts = 0
        score += pts
        last_cleared_rows = rows_cleared
        # spawn next piece if any
        if piece_idx < len(piece_seq):
            next_letter = piece_seq[piece_idx]
            blocks0 = PIECE[next_letter][0]
            if fits(board, 0, 3, blocks0):
                cur_letter = next_letter
                cur_state = 0
                cur_row = 0
                cur_col = 3
                piece_idx += 1
                game_state = 'PLAYING'
            else:
                game_state = 'OVER'
        else:
            game_state = 'DONE'
    
    for cmd in commands:
        if game_state == 'OVER' or game_state == 'DONE':
            if cmd == 'P':
                render_and_score()
            if cmd not in ['L', 'R', 'D', 'H', 'CW', 'CCW', 'P']:
                sys.stderr.write(f"error: unknown command {cmd}\n")
            continue
        
        if cmd not in ['L', 'R', 'D', 'H', 'CW', 'CCW', 'P']:
            sys.stderr.write(f"error: unknown command {cmd}\n")
            continue
        
        if cmd == 'L':
            if fits(board, cur_row, cur_col - 1, PIECE[cur_letter][cur_state]):
                cur_col -= 1
        elif cmd == 'R':
            if fits(board, cur_row, cur_col + 1, PIECE[cur_letter][cur_state]):
                cur_col += 1
        elif cmd == 'D':
            if fits(board, cur_row + 1, cur_col, PIECE[cur_letter][cur_state]):
                cur_row += 1
                score += 1
            else:
                lock()
        elif cmd == 'H':
            max_down = 0
            for down in range(1, 20 - cur_row + 1):
                if fits(board, cur_row + down, cur_col, PIECE[cur_letter][cur_state]):
                    max_down = down
                else:
                    break
            if max_down > 0:
                cur_row += max_down
                score += 2 * max_down
            lock()
        elif cmd == 'CW':
            new_state = (cur_state + 1) % 4
            blocks = PIECE[cur_letter][new_state]
            shifts = [0, -1, 1, -2, 2]
            placed = False
            for sh in shifts:
                if fits(board, cur_row, cur_col + sh, blocks):
                    cur_col += sh
                    cur_state = new_state
                    placed = True
                    break
        elif cmd == 'CCW':
            new_state = (cur_state + 3) % 4
            blocks = PIECE[cur_letter][new_state]
            shifts = [0, -1, 1, -2, 2]
            for sh in shifts:
                if fits(board, cur_row, cur_col + sh, blocks):
                    cur_col += sh
                    cur_state = new_state
                    break
        elif cmd == 'P':
            render_and_score()
    
    if game_state == 'PLAYING' or game_state == 'OVER':
        render_and_score()
    
    sys.exit(0)

if __name__ == '__main__':
    main()
