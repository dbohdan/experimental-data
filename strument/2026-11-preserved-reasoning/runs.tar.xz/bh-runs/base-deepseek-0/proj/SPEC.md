# shop

A small library that prices a shopping cart. Amounts are integer cents
throughout; `money.parse` and `money.fmt` convert to and from text.

## Money

`parse(text)` reads "12", "12.5" or "12.50" as 1200, 1250, 1250 cents.
`fmt(cents)` writes 1250 as "12.50". `percent(cents, rate)` is cents * rate /
100, rounded half up to a whole cent (2.5 cents rounds to 3).

## Catalog

`load(text)` reads CSV lines `sku,name,category,price,weight_g` (no header).

## Cart

`Cart.add(sku, qty)` adds units. Adding a SKU already in the cart adds to its
quantity. `lines()` returns `(sku, qty)` pairs sorted by SKU.

## Discounts

Applied per line, in this order:

1. **Category percent off.** `category_off = {"books": 10}` takes 10% off each
   unit price in that category, via `money.percent`, before multiplying by the
   quantity.
2. **Multi-buy.** `multibuy = {"SKU": (x, y)}` means buy x, get y free: of each
   x + y units, y are free. 7 units of a (2, 1) offer pay for 5.

A coupon `(amount, min_spend)` takes `amount` off the order when the sum of the
discounted line nets is at least `min_spend`. It never takes the order below
zero.

## Tax

Each line's discounted net is taxed at its category's rate: books and food 7%,
everything else 19%. The tax is computed per line with `money.percent`, so
each line rounds half up on its own.

## Shipping

By total cart weight in grams: up to and including 500 g costs 4.90, up to and
including 2000 g costs 7.90, heavier costs 12.90. Shipping is free when the
goods total (discounted nets plus tax, minus the coupon) is 50.00 or more.

## Invoice

`invoice.total(...)` is the discounted nets plus tax, minus the coupon, plus
shipping. `invoice.render(...)` prints one row per line and the totals.
