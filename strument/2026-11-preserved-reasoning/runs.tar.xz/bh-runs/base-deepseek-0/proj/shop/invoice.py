from shop import discounts, money, shipping, tax


def lines(cart, catalog, category_off=None, multibuy=None):
    out = []
    for sku, qty in cart.lines():
        item = catalog[sku]
        net = discounts.line_net(item, qty, category_off, multibuy)
        out.append((item, qty, net, tax.line_tax(item.category, net)))
    return out


def totals(cart, catalog, category_off=None, multibuy=None, coupon=None):
    rows = lines(cart, catalog, category_off, multibuy)
    net = sum(r[2] for r in rows)
    vat = sum(r[3] for r in rows)
    off = discounts.coupon_value(coupon, net)
    goods = net + vat - off
    weight = sum(r[0].weight_g * r[1] for r in rows)
    ship = shipping.cost(weight, goods)
    return {"net": net, "tax": vat, "coupon": off, "shipping": ship, "total": goods + ship}


def total(cart, catalog, **kw):
    return totals(cart, catalog, **kw)["total"]


def render(cart, catalog, **kw):
    out = []
    for item, qty, net, vat in lines(cart, catalog, kw.get("category_off"), kw.get("multibuy")):
        out.append(f"{item.sku:<8}{qty:>4}{money.fmt(net):>10}{money.fmt(vat):>8}")
    t = totals(cart, catalog, **kw)
    for k in ("net", "tax", "coupon", "shipping", "total"):
        out.append(f"{k:<12}{money.fmt(t[k]):>18}")
    return "\n".join(out)
