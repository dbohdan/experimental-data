from shop import money


class Item:
    def __init__(self, sku, name, category, price, weight_g):
        self.sku, self.name, self.category = sku, name, category
        self.price, self.weight_g = price, weight_g


def load(text):
    items = {}
    for line in text.strip().splitlines():
        sku, name, category, price, weight = [f.strip() for f in line.split(",")]
        items[sku] = Item(sku, name, category, money.parse(price), int(weight))
    return items
