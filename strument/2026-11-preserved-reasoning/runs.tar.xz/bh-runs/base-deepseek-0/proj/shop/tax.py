from shop import money

RATES = {"books": 7, "food": 7}
DEFAULT_RATE = 19


def line_tax(category, net):
    return money.percent(net, RATES.get(category, DEFAULT_RATE))
