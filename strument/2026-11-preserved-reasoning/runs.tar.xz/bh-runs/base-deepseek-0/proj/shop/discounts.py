from shop import money


def line_net(item, qty, category_off=None, multibuy=None):
    """A line's net after the category discount and any multi-buy offer."""
    unit = item.price
    off = (category_off or {}).get(item.category)
    if off:
        unit -= money.percent(unit, off)
    offer = (multibuy or {}).get(item.sku)
    paid = qty
    if offer:
        x, y = offer
        paid = qty - (qty // (x + y)) * y
    return unit * paid


def coupon_value(coupon, discounted_net):
    if not coupon:
        return 0
    amount, min_spend = coupon
    if discounted_net < min_spend:
        return 0
    return min(amount, discounted_net)
