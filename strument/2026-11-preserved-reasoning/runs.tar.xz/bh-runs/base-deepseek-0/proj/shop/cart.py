class Cart:
    def __init__(self):
        self._qty = {}

    def add(self, sku, qty=1):
        self._qty[sku] = self._qty.get(sku, 0) + qty

    def lines(self):
        return sorted(self._qty.items())
