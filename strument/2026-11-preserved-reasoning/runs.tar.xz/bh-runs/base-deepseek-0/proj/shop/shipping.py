FREE_FROM = 5000


def cost(weight_g, goods_total):
    if goods_total >= FREE_FROM:
        return 0
    if weight_g <= 500:
        return 490
    if weight_g <= 2000:
        return 790
    return 1290
