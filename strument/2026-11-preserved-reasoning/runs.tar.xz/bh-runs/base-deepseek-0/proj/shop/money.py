def parse(text):
    """Text such as "12", "12.5" or "12.50" to integer cents."""
    text = text.strip()
    if "." in text:
        whole, frac = text.split(".", 1)
        frac = (frac + "00")[:2]
        return int(whole) * 100 + int(frac)
    return int(text) * 100


def fmt(cents):
    sign = "-" if cents < 0 else ""
    cents = abs(cents)
    return f"{sign}{cents // 100}.{cents % 100:02d}"


def percent(cents, rate):
    """cents * rate / 100, rounded half up to a whole cent."""
    return (cents * rate * 2 + 100) // 200
