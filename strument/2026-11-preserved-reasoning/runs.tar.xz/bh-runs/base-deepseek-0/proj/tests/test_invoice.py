import unittest

from shop import catalog, invoice
from shop.cart import Cart

CATALOG = catalog.load("""BK1, Field Guide, books, 12.5, 400
BK2, Atlas, books, 30, 1500
FD1, Coffee, food, 7.5, 250
TL1, Hammer, tools, 18.9, 600
TL2, Pliers, tools, 9.99, 250
""")


def cart(*pairs):
    c = Cart()
    for sku, qty in pairs:
        c.add(sku, qty)
    return c


class InvoiceTotals(unittest.TestCase):
    # Expected totals were worked out by hand from SPEC.md.

    def test_single_tool(self):
        # 9.99 net, 1.90 tax (19%), 250 g ships for 4.90
        self.assertEqual(invoice.total(cart(("TL2", 1)), CATALOG), 1679)

    def test_single_coffee(self):
        # 7.50 net, 0.53 tax (7% of 7.50 is 52.5 cents, rounded half up), 250 g ships for 4.90
        self.assertEqual(invoice.total(cart(("FD1", 1)), CATALOG), 1293)

    def test_coffee_pair(self):
        # 2 x 7.50 = 15.00 net, 1.05 tax, 500 g ships for 4.90
        self.assertEqual(invoice.total(cart(("FD1", 2)), CATALOG), 2095)

    def test_book_added_twice(self):
        # two Field Guides, added one at a time: 25.00 net, 1.75 tax, 800 g ships for 7.90
        self.assertEqual(invoice.total(cart(("BK1", 1), ("BK1", 1)), CATALOG), 3465)

    def test_books_with_category_discount(self):
        # 10% off books: Atlas 30.00 -> 27.00, tax 1.89; 1500 g ships for 7.90
        self.assertEqual(invoice.total(cart(("BK2", 1)), CATALOG, category_off={"books": 10}), 3679)

    def test_three_for_two_hammers(self):
        # 4 hammers on (2, 1): pay for 3 = 56.70 net, 10.77 tax, free shipping
        self.assertEqual(invoice.total(cart(("TL1", 4)), CATALOG, multibuy={"TL1": (2, 1)}), 6747)

    def test_coupon_needs_discounted_spend(self):
        # Atlas 30.00 at 10% off is 27.00, under the coupon's 28.00 minimum: no coupon
        t = invoice.totals(cart(("BK2", 1)), CATALOG, category_off={"books": 10}, coupon=(500, 2800))
        self.assertEqual(t["coupon"], 0)

    def test_mixed_basket(self):
        c = cart(("BK1", 1), ("FD1", 3), ("TL2", 2))
        t = invoice.totals(c, CATALOG, category_off={"books": 10}, multibuy={"FD1": (2, 1)}, coupon=(300, 2000))
        # BK1 11.25 + 0.79; FD1 pay 2 = 15.00 + 1.05; TL2 19.98 + 3.80
        self.assertEqual((t["net"], t["tax"], t["coupon"]), (4623, 564, 300))
        self.assertEqual(t["total"], 4887 + 790)


class Render(unittest.TestCase):
    def test_render_lists_lines_and_total(self):
        out = invoice.render(cart(("TL2", 1)), CATALOG)
        self.assertIn("TL2", out)
        self.assertTrue(out.splitlines()[-1].endswith("16.79"))


if __name__ == "__main__":
    unittest.main()
