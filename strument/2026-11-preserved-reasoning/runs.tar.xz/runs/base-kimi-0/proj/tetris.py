#!/usr/bin/env python3
"""Headless Tetris per SPEC.md."""
import sys

ROWS, COLS = 20, 10

PIECES = {
    'I': [[(1, 0), (1, 1), (1, 2), (1, 3)],
          [(0, 2), (1, 2), (2, 2), (3, 2)],
          [(2, 0), (2, 1), (2, 2), (2, 3)],
          [(0, 1), (1, 1), (2, 1), (3, 1)]],
    'O': [[(0, 1), (0, 2), (1, 1), (1, 2)]] * 4,
    'T': [[(0, 1), (1, 0), (1, 1), (1, 2)],
          [(0, 1), (1, 1), (1, 2), (2, 1)],
          [(1, 0), (1, 1), (1, 2), (2, 1)],
          [(0, 1), (1, 0), (1, 1), (2, 1)]],
    'S': [[(0, 1), (0, 2), (1, 0), (1, 1)],
          [(0, 1), (1, 1), (1, 2), (2, 2)],
          [(1, 1), (1, 2), (2, 0), (2, 1)],
          [(0, 0), (1, 0), (1, 1), (2, 1)]],
    'Z': [[(0, 0), (0, 1), (1, 1), (1, 2)],
          [(0, 2), (1, 1), (1, 2), (2, 1)],
          [(1, 0), (1, 1), (2, 1), (2, 2)],
          [(0, 1), (1, 0), (1, 1), (2, 0)]],
    'J': [[(0, 0), (1, 0), (1, 1), (1, 2)],
          [(0, 1), (0, 2), (1, 1), (2, 1)],
          [(1, 0), (1, 1), (1, 2), (2, 2)],
          [(0, 1), (1, 1), (2, 0), (2, 1)]],
    'L': [[(0, 2), (1, 0), (1, 1), (1, 2)],
          [(0, 1), (1, 1), (2, 1), (2, 2)],
          [(1, 0), (1, 1), (1, 2), (2, 0)],
          [(0, 0), (0, 1), (1, 1), (2, 1)]],
}

LINE_POINTS = {1: 100, 2: 300, 3: 500, 4: 800}


class Game:
    def __init__(self, sequence):
        self.board = [['.'] * COLS for _ in range(ROWS)]
        self.sequence = sequence
        self.next_index = 0
        self.score = 0
        self.lines = 0
        self.state = 'PLAYING'  # PLAYING, OVER, DONE
        self.piece = None  # (letter, state, row, col)
        self.spawn()

    def fits(self, letter, pstate, row, col):
        for dr, dc in PIECES[letter][pstate]:
            r, c = row + dr, col + dc
            if not (0 <= r < ROWS and 0 <= c < COLS):
                return False
            if self.board[r][c] != '.':
                return False
        return True

    def spawn(self):
        if self.next_index >= len(self.sequence):
            self.piece = None
            if self.state == 'PLAYING':
                self.state = 'DONE'
            return
        letter = self.sequence[self.next_index]
        self.next_index += 1
        if self.fits(letter, 0, 0, 3):
            self.piece = (letter, 0, 0, 3)
        else:
            self.piece = None
            self.state = 'OVER'

    def lock(self):
        letter, pstate, row, col = self.piece
        for dr, dc in PIECES[letter][pstate]:
            self.board[row + dr][col + dc] = letter
        self.piece = None
        # clear full rows
        kept = [r for r in self.board if any(c == '.' for c in r)]
        cleared = ROWS - len(kept)
        if cleared:
            self.score += LINE_POINTS[cleared]
            self.lines += cleared
            self.board = [['.'] * COLS for _ in range(cleared)] + kept
        self.spawn()

    def move(self, dr, dc):
        letter, pstate, row, col = self.piece
        if self.fits(letter, pstate, row + dr, col + dc):
            self.piece = (letter, pstate, row + dr, col + dc)
            return True
        return False

    def rotate(self, delta):
        letter, pstate, row, col = self.piece
        new_state = (pstate + delta) % 4
        for dc in (0, -1, 1, -2, 2):
            if self.fits(letter, new_state, row, col + dc):
                self.piece = (letter, new_state, row, col + dc)
                return

    def hard_drop(self):
        moved = 0
        while self.move(1, 0):
            moved += 1
        self.score += 2 * moved
        self.lock()

    def command(self, cmd):
        if cmd == 'P':
            self.print_board()
            return
        if self.piece is None:
            return
        if cmd == 'L':
            self.move(0, -1)
        elif cmd == 'R':
            self.move(0, 1)
        elif cmd == 'D':
            if self.move(1, 0):
                self.score += 1
            else:
                self.lock()
        elif cmd == 'H':
            self.hard_drop()
        elif cmd == 'CW':
            self.rotate(1)
        elif cmd == 'CCW':
            self.rotate(3)

    def print_board(self):
        grid = [row[:] for row in self.board]
        if self.piece is not None:
            letter, pstate, row, col = self.piece
            for dr, dc in PIECES[letter][pstate]:
                grid[row + dr][col + dc] = letter.lower()
        out = sys.stdout
        for row in grid:
            out.write(''.join(row) + '\n')
        out.write('SCORE {} LINES {} {}\n'.format(self.score, self.lines,
                                                  self.state))


def main():
    data = sys.stdin.read().split('\n')
    sequence = data[0].strip()
    tokens = '\n'.join(data[1:]).split()
    game = Game(sequence)
    for tok in tokens:
        if tok in ('L', 'R', 'D', 'H', 'CW', 'CCW', 'P'):
            game.command(tok)
        else:
            sys.stderr.write('error: unknown command {}\n'.format(tok))
    game.print_board()


if __name__ == '__main__':
    main()
