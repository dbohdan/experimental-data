#!/usr/bin/env python3
"""Headless Tetris: reads a piece sequence and commands, prints the board."""

import sys

WIDTH = 10
HEIGHT = 20

PIECES = {
    'I': [
        ((1, 0), (1, 1), (1, 2), (1, 3)),
        ((0, 2), (1, 2), (2, 2), (3, 2)),
        ((2, 0), (2, 1), (2, 2), (2, 3)),
        ((0, 1), (1, 1), (2, 1), (3, 1)),
    ],
    'O': [
        ((0, 1), (0, 2), (1, 1), (1, 2)),
        ((0, 1), (0, 2), (1, 1), (1, 2)),
        ((0, 1), (0, 2), (1, 1), (1, 2)),
        ((0, 1), (0, 2), (1, 1), (1, 2)),
    ],
    'T': [
        ((0, 1), (1, 0), (1, 1), (1, 2)),
        ((0, 1), (1, 1), (1, 2), (2, 1)),
        ((1, 0), (1, 1), (1, 2), (2, 1)),
        ((0, 1), (1, 0), (1, 1), (2, 1)),
    ],
    'S': [
        ((0, 1), (0, 2), (1, 0), (1, 1)),
        ((0, 1), (1, 1), (1, 2), (2, 2)),
        ((1, 1), (1, 2), (2, 0), (2, 1)),
        ((0, 0), (1, 0), (1, 1), (2, 1)),
    ],
    'Z': [
        ((0, 0), (0, 1), (1, 1), (1, 2)),
        ((0, 2), (1, 1), (1, 2), (2, 1)),
        ((1, 0), (1, 1), (2, 1), (2, 2)),
        ((0, 1), (1, 0), (1, 1), (2, 0)),
    ],
    'J': [
        ((0, 0), (1, 0), (1, 1), (1, 2)),
        ((0, 1), (0, 2), (1, 1), (2, 1)),
        ((1, 0), (1, 1), (1, 2), (2, 2)),
        ((0, 1), (1, 1), (2, 0), (2, 1)),
    ],
    'L': [
        ((0, 2), (1, 0), (1, 1), (1, 2)),
        ((0, 1), (1, 1), (2, 1), (2, 2)),
        ((1, 0), (1, 1), (1, 2), (2, 0)),
        ((0, 0), (0, 1), (1, 1), (2, 1)),
    ],
}

CLEAR_SCORES = {1: 100, 2: 300, 3: 500, 4: 800}

ROTATION_SHIFTS = (0, -1, 1, -2, 2)


class Game:
    def __init__(self, sequence, out):
        self.sequence = sequence
        self.out = out
        self.board = [[None] * WIDTH for _ in range(HEIGHT)]
        self.next_index = 0
        self.piece = None  # (letter, state, row, col)
        self.score = 0
        self.lines = 0
        self.state = 'PLAYING'
        self.spawn()

    def blocks(self, letter, state):
        return PIECES[letter][state]

    def fits(self, letter, state, row, col):
        for r, c in self.blocks(letter, state):
            br, bc = row + r, col + c
            if br < 0 or br >= HEIGHT or bc < 0 or bc >= WIDTH:
                return False
            if self.board[br][bc] is not None:
                return False
        return True

    def spawn(self):
        if self.next_index >= len(self.sequence):
            self.piece = None
            self.state = 'DONE'
            return
        letter = self.sequence[self.next_index]
        self.next_index += 1
        if self.fits(letter, 0, 0, 3):
            self.piece = (letter, 0, 0, 3)
            self.state = 'PLAYING'
        else:
            self.piece = None
            self.state = 'OVER'

    def lock(self):
        letter, state, row, col = self.piece
        for r, c in self.blocks(letter, state):
            self.board[row + r][col + c] = letter
        full = [i for i in range(HEIGHT) if all(cell is not None for cell in self.board[i])]
        if full:
            for i in full:
                del self.board[i]
            for _ in full:
                self.board.insert(0, [None] * WIDTH)
            self.score += CLEAR_SCORES[len(full)]
            self.lines += len(full)
        self.piece = None
        self.spawn()

    def move(self, dcol):
        letter, state, row, col = self.piece
        if self.fits(letter, state, row, col + dcol):
            self.piece = (letter, state, row, col + dcol)

    def down(self):
        letter, state, row, col = self.piece
        if self.fits(letter, state, row + 1, col):
            self.piece = (letter, state, row + 1, col)
            self.score += 1
        else:
            self.lock()

    def hard_drop(self):
        letter, state, row, col = self.piece
        moved = 0
        while self.fits(letter, state, row + 1, col):
            row += 1
            moved += 1
        self.piece = (letter, state, row, col)
        self.score += 2 * moved
        self.lock()

    def rotate(self, delta):
        letter, state, row, col = self.piece
        new_state = (state + delta) % 4
        for dcol in ROTATION_SHIFTS:
            if self.fits(letter, new_state, row, col + dcol):
                self.piece = (letter, new_state, row, col + dcol)
                return

    def render(self):
        grid = [[cell if cell is not None else '.' for cell in rowrow] for rowrow in self.board]
        if self.piece is not None:
            letter, state, row, col = self.piece
            for r, c in self.blocks(letter, state):
                br, bc = row + r, col + c
                if 0 <= br < HEIGHT and 0 <= bc < WIDTH:
                    grid[br][bc] = letter.lower()
        lines = [''.join(r) for r in grid]
        lines.append('SCORE %d LINES %d %s' % (self.score, self.lines, self.state))
        return '\n'.join(lines)

    def handle(self, token):
        if token == 'P':
            self.out.write(self.render() + '\n')
            return
        if self.piece is None:
            return
        if token == 'L':
            self.move(-1)
        elif token == 'R':
            self.move(1)
        elif token == 'D':
            self.down()
        elif token == 'H':
            self.hard_drop()
        elif token == 'CW':
            self.rotate(1)
        elif token == 'CCW':
            self.rotate(-1)
        else:
            sys.stderr.write('error: unknown command %s\n' % token)


def main():
    data = sys.stdin.read()
    lines = data.split('\n')
    sequence = lines[0].strip() if lines else ''
    commands = '\n'.join(lines[1:]).split()

    out = sys.stdout
    game = Game(sequence, out)
    for token in commands:
        game.handle(token)
    out.write(game.render() + '\n')


if __name__ == '__main__':
    main()
