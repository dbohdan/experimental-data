#!/usr/bin/env python3
"""Headless Tetris: play a fixed piece sequence from commands on stdin."""

import sys

ROWS = 20
COLS = 10

SPAWN_ROW = 0
SPAWN_COL = 3

# Blocks of each piece state as (r, c) offsets inside the 4x4 box.
PIECES = {
    "I": (
        ((1, 0), (1, 1), (1, 2), (1, 3)),
        ((0, 2), (1, 2), (2, 2), (3, 2)),
        ((2, 0), (2, 1), (2, 2), (2, 3)),
        ((0, 1), (1, 1), (2, 1), (3, 1)),
    ),
    "O": (
        ((0, 1), (0, 2), (1, 1), (1, 2)),
        ((0, 1), (0, 2), (1, 1), (1, 2)),
        ((0, 1), (0, 2), (1, 1), (1, 2)),
        ((0, 1), (0, 2), (1, 1), (1, 2)),
    ),
    "T": (
        ((0, 1), (1, 0), (1, 1), (1, 2)),
        ((0, 1), (1, 1), (1, 2), (2, 1)),
        ((1, 0), (1, 1), (1, 2), (2, 1)),
        ((0, 1), (1, 0), (1, 1), (2, 1)),
    ),
    "S": (
        ((0, 1), (0, 2), (1, 0), (1, 1)),
        ((0, 1), (1, 1), (1, 2), (2, 2)),
        ((1, 1), (1, 2), (2, 0), (2, 1)),
        ((0, 0), (1, 0), (1, 1), (2, 1)),
    ),
    "Z": (
        ((0, 0), (0, 1), (1, 1), (1, 2)),
        ((0, 2), (1, 1), (1, 2), (2, 1)),
        ((1, 0), (1, 1), (2, 1), (2, 2)),
        ((0, 1), (1, 0), (1, 1), (2, 0)),
    ),
    "J": (
        ((0, 0), (1, 0), (1, 1), (1, 2)),
        ((0, 1), (0, 2), (1, 1), (2, 1)),
        ((1, 0), (1, 1), (1, 2), (2, 2)),
        ((0, 1), (1, 1), (2, 0), (2, 1)),
    ),
    "L": (
        ((0, 2), (1, 0), (1, 1), (1, 2)),
        ((0, 1), (1, 1), (2, 1), (2, 2)),
        ((1, 0), (1, 1), (1, 2), (2, 0)),
        ((0, 0), (0, 1), (1, 1), (2, 1)),
    ),
}

# Points for clearing 1, 2, 3 or 4 rows at once.
LINE_SCORES = (0, 100, 300, 500, 800)

KNOWN_COMMANDS = ("L", "R", "D", "H", "CW", "CCW", "P")


class Game:
    def __init__(self, sequence):
        self.board = [[None] * COLS for _ in range(ROWS)]
        self.sequence = sequence
        self.next_piece = 0
        self.score = 0
        self.lines = 0
        self.state = "PLAYING"
        self.piece = None  # [letter, row, col, state] while a piece is in play
        self._spawn()

    def fits(self, letter, row, col, state):
        """True when every block of the piece is on the board and on an empty cell."""
        for dr, dc in PIECES[letter][state]:
            r, c = row + dr, col + dc
            if not (0 <= r < ROWS and 0 <= c < COLS):
                return False
            if self.board[r][c] is not None:
                return False
        return True

    def _spawn(self):
        if self.next_piece >= len(self.sequence):
            self.piece = None
            self.state = "DONE"
            return
        letter = self.sequence[self.next_piece]
        self.next_piece += 1
        if self.fits(letter, SPAWN_ROW, SPAWN_COL, 0):
            self.piece = [letter, SPAWN_ROW, SPAWN_COL, 0]
            self.state = "PLAYING"
        else:
            self.piece = None
            self.state = "OVER"

    def _lock(self):
        letter, row, col, state = self.piece
        for dr, dc in PIECES[letter][state]:
            self.board[row + dr][col + dc] = letter
        self.piece = None
        self._clear_lines()
        self._spawn()

    def _clear_lines(self):
        kept = [line for line in self.board if any(cell is None for cell in line)]
        cleared = ROWS - len(kept)
        if cleared:
            self.board = [[None] * COLS for _ in range(cleared)] + kept
            self.lines += cleared
            self.score += LINE_SCORES[cleared]

    def _rotate(self, new_state):
        letter, row, col, _ = self.piece
        for dc in (0, -1, 1, -2, 2):
            if self.fits(letter, row, col + dc, new_state):
                self.piece = [letter, row, col + dc, new_state]
                return

    def run(self, token):
        if token not in KNOWN_COMMANDS:
            print("error: unknown command " + token, file=sys.stderr)
            return
        if token == "P":
            self.dump()
            return
        if self.piece is None:  # game over or done: every command but P is ignored
            return
        letter, row, col, state = self.piece
        if token == "L":
            if self.fits(letter, row, col - 1, state):
                self.piece[2] = col - 1
        elif token == "R":
            if self.fits(letter, row, col + 1, state):
                self.piece[2] = col + 1
        elif token == "D":
            if self.fits(letter, row + 1, col, state):
                self.piece[1] = row + 1
                self.score += 1
            else:
                self._lock()
        elif token == "H":
            drop = 0
            while self.fits(letter, row + drop + 1, col, state):
                drop += 1
            self.piece[1] = row + drop
            self.score += 2 * drop
            self._lock()
        elif token == "CW":
            self._rotate((state + 1) % 4)
        elif token == "CCW":
            self._rotate((state + 3) % 4)

    def dump(self):
        blocks = set()
        lower = ""
        if self.piece is not None:
            letter, row, col, state = self.piece
            blocks = {(row + dr, col + dc) for dr, dc in PIECES[letter][state]}
            lower = letter.lower()
        out = []
        for r in range(ROWS):
            line = []
            for c in range(COLS):
                cell = self.board[r][c]
                if cell is not None:
                    line.append(cell)
                elif (r, c) in blocks:
                    line.append(lower)
                else:
                    line.append(".")
            out.append("".join(line))
        out.append("SCORE %d LINES %d %s" % (self.score, self.lines, self.state))
        sys.stdout.write("\n".join(out) + "\n")


def main():
    data = sys.stdin.read()
    first_line, _, rest = data.partition("\n")
    sequence = "".join(first_line.split())
    game = Game(sequence)
    for token in rest.split():
        game.run(token)
    game.dump()


if __name__ == "__main__":
    main()
