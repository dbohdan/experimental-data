# svc

The API client service. Each deployment environment (`deploy/*.env`) has its own
configuration, assembled by `svc/config.py`.
