from svc import config


class Client:
    def __init__(self, env):
        cfg = config.load(env)
        self.timeout = cfg["request_timeout"]
        self.retries = cfg["retries"]
        self.endpoint = cfg.get("endpoint", "http://localhost:8080")
