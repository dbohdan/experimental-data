"""Configuration for one deployment environment.

Settings come in layers, and a later layer wins over an earlier one.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _read(path):
    values = {}
    for line in path.read_text().splitlines():
        line = line.split("#", 1)[0].strip()
        if line:
            key, value = (part.strip() for part in line.split("=", 1))
            values[key] = int(value) if value.isdigit() else value
    return values


def layers(env):
    """The files that make up env's configuration, in the order they apply."""
    profile = _read(ROOT / "deploy" / f"{env}.env")["APP_PROFILE"]
    files = [ROOT / "config" / "base.conf"]
    if "-" in profile:
        region, size = profile.split("-", 1)
        files.append(ROOT / "config" / "sizes" / f"{size}.conf")
        files.append(ROOT / "config" / "regions" / f"{region}.conf")
    files.append(ROOT / "overrides" / f"{profile}.conf")
    return [f for f in files if f.exists()]


def load(env):
    values = {}
    for f in layers(env):
        values.update(_read(f))
    return values
