package stats

import "testing"

func TestMean(t *testing.T) {
	if got := Mean([]float64{1, 2, 3, 4}); got != 2.5 {
		t.Errorf("Mean = %v, want 2.5", got)
	}
}

func TestMedian(t *testing.T) {
	if got := Median([]float64{3, 1, 2, 4, 5}); got != 3 {
		t.Errorf("Median = %v, want 3", got)
	}
	if got := Median([]float64{4, 1, 3, 2}); got != 2.5 {
		t.Errorf("Median = %v, want 2.5", got)
	}
	if got := Median([]float64{}); got != 0 {
		t.Errorf("Median = %v, want 0", got)
	}
}
