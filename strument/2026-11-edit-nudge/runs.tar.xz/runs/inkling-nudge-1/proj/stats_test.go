package stats

import "testing"

func TestMean(t *testing.T) {
	if got := Mean([]float64{1, 2, 3, 4}); got != 2.5 {
		t.Errorf("Mean = %v, want 2.5", got)
	}
}

func TestMedian(t *testing.T) {
	cases := []struct {
		name string
		xs   []float64
		want float64
	}{
		{"empty", []float64{}, 0},
		{"odd", []float64{3, 1, 2}, 2},
		{"even", []float64{4, 1, 3, 2}, 2.5},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			if got := Median(c.xs); got != c.want {
				t.Errorf("Median = %v, want %v", got, c.want)
			}
		})
	}
}
