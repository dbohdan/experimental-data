package stats

import "testing"

func TestMean(t *testing.T) {
	if got := Mean([]float64{1, 2, 3, 4}); got != 2.5 {
		t.Errorf("Mean = %v, want 2.5", got)
	}
}

func TestMedian(t *testing.T) {
	tests := []struct {
		name string
		xs   []float64
		want float64
	}{
		{"empty", nil, 0},
		{"single", []float64{5}, 5},
		{"odd", []float64{3, 1, 2}, 2},
		{"even", []float64{4, 1, 3, 2}, 2.5},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := Median(tt.xs); got != tt.want {
				t.Errorf("Median(%v) = %v, want %v", tt.xs, got, tt.want)
			}
		})
	}
}

func TestMedianDoesNotModifyInput(t *testing.T) {
	xs := []float64{3, 1, 2}
	Median(xs)
	if xs[0] != 3 || xs[1] != 1 || xs[2] != 2 {
		t.Errorf("Median modified its input: %v", xs)
	}
}
