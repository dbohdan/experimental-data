package stats

import "testing"

func TestMean(t *testing.T) {
	if got := Mean([]float64{1, 2, 3, 4}); got != 2.5 {
		t.Errorf("Mean = %v, want 2.5", got)
	}
}

func TestMedian(t *testing.T) {
	tests := []struct {
		name string
		xs   []float64
		want float64
	}{
		{"empty", []float64{}, 0},
		{"odd", []float64{1, 3, 2}, 2},
		{"even", []float64{1, 2, 3, 4}, 2.5},
		{"unsorted", []float64{5, 1, 4, 2, 3}, 3},
	}
	for _, tt := range tests {
		if got := Median(tt.xs); got != tt.want {
			t.Errorf("%s: Median = %v, want %v", tt.name, got, tt.want)
		}
	}
}
