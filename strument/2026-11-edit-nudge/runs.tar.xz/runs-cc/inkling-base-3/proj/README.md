# stats

Small numeric helpers. Currently it provides the arithmetic mean and median.
