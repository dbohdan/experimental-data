package stats

import "testing"

func TestMean(t *testing.T) {
	if got := Mean([]float64{1, 2, 3, 4}); got != 2.5 {
		t.Errorf("Mean = %v, want 2.5", got)
	}
}

func TestMedian(t *testing.T) {
	if got := Median([]float64{1, 5, 2, 4, 3}); got != 3 {
		t.Errorf("Median odd = %v, want 3", got)
	}
	if got := Median([]float64{1, 2, 3, 4}); got != 2.5 {
		t.Errorf("Median even = %v, want 2.5", got)
	}
	if got := Median([]float64{}); got != 0 {
		t.Errorf("Median empty = %v, want 0", got)
	}
}
