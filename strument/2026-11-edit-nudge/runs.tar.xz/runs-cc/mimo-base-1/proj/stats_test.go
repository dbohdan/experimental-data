package stats

import "testing"

func TestMean(t *testing.T) {
	if got := Mean([]float64{1, 2, 3, 4}); got != 2.5 {
		t.Errorf("Mean = %v, want 2.5", got)
	}
}

func TestMedian(t *testing.T) {
	tests := []struct {
		name string
		xs   []float64
		want float64
	}{
		{"odd length", []float64{3, 1, 2}, 2},
		{"even length", []float64{4, 1, 3, 2}, 2.5},
		{"single element", []float64{7}, 7},
		{"empty", []float64{}, 0},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := Median(tt.xs); got != tt.want {
				t.Errorf("Median(%v) = %v, want %v", tt.xs, got, tt.want)
			}
		})
	}
}

func TestMedianDoesNotModifyInput(t *testing.T) {
	xs := []float64{3, 1, 2}
	Median(xs)
	want := []float64{3, 1, 2}
	for i, x := range xs {
		if x != want[i] {
			t.Errorf("Median modified input: got %v, want %v", xs, want)
			break
		}
	}
}
