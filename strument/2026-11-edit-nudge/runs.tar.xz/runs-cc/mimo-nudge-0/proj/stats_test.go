package stats

import "testing"

func TestMean(t *testing.T) {
	if got := Mean([]float64{1, 2, 3, 4}); got != 2.5 {
		t.Errorf("Mean = %v, want 2.5", got)
	}
}

func TestMedian(t *testing.T) {
	cases := []struct {
		name string
		xs   []float64
		want float64
	}{
		{"empty", nil, 0},
		{"single", []float64{7}, 7},
		{"odd", []float64{3, 1, 2}, 2},
		{"even", []float64{4, 1, 3, 2}, 2.5},
		{"unsorted negative", []float64{-5, -1, -3}, -3},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			if got := Median(c.xs); got != c.want {
				t.Errorf("Median(%v) = %v, want %v", c.xs, got, c.want)
			}
		})
	}
}

func TestMedianDoesNotModifyInput(t *testing.T) {
	xs := []float64{3, 1, 2}
	Median(xs)
	for i, want := range []float64{3, 1, 2} {
		if xs[i] != want {
			t.Fatalf("Median modified input: got %v, want %v", xs, []float64{3, 1, 2})
		}
	}
}
