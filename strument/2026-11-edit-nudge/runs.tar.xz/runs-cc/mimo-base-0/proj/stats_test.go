package stats

import "testing"

func TestMean(t *testing.T) {
	if got := Mean([]float64{1, 2, 3, 4}); got != 2.5 {
		t.Errorf("Mean = %v, want 2.5", got)
	}
}

func TestMedian(t *testing.T) {
	tests := []struct {
		name string
		xs   []float64
		want float64
	}{
		{"empty", nil, 0},
		{"single", []float64{5}, 5},
		{"odd", []float64{3, 1, 2}, 2},
		{"even", []float64{4, 1, 3, 2}, 2.5},
		{"unsorted negatives", []float64{-5, -1, -3}, -3},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			xs := append([]float64(nil), tt.xs...)
			if got := Median(tt.xs); got != tt.want {
				t.Errorf("Median(%v) = %v, want %v", tt.xs, got, tt.want)
			}
			for i := range xs {
				if tt.xs[i] != xs[i] {
					t.Errorf("Median modified its input: %v, want %v", tt.xs, xs)
					break
				}
			}
		})
	}
}
