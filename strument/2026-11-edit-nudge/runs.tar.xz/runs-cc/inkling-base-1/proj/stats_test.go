package stats

import "testing"

func TestMean(t *testing.T) {
	if got := Mean([]float64{1, 2, 3, 4}); got != 2.5 {
		t.Errorf("Mean = %v, want 2.5", got)
	}
}

func TestMedian(t *testing.T) {
	tests := []struct {
		name string
		xs   []float64
		want float64
	}{
		{"empty", []float64{}, 0},
		{"odd", []float64{3, 1, 2}, 2},
		{"even", []float64{4, 1, 3, 2}, 2.5},
		{"single", []float64{5}, 5},
	}
	for _, tt := range tests {
		if got := Median(tt.xs); got != tt.want {
			t.Errorf("Median(%v) = %v, want %v (%s)", tt.xs, got, tt.want, tt.name)
		}
	}
}
