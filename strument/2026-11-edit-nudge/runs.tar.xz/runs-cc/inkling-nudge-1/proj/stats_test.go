package stats

import "testing"

func TestMean(t *testing.T) {
	if got := Mean([]float64{1, 2, 3, 4}); got != 2.5 {
		t.Errorf("Mean = %v, want 2.5", got)
	}
}

func TestMedian(t *testing.T) {
	for _, tc := range []struct {
		name string
		xs   []float64
		want float64
	}{
		{"odd", []float64{3, 1, 2}, 2},
		{"even", []float64{4, 1, 3, 2}, 2.5},
		{"empty", []float64{}, 0},
	} {
		if got := Median(tc.xs); got != tc.want {
			t.Errorf("Median(%v) = %v, want %v", tc.xs, got, tc.want)
		}
	}
}
