package stats

import "testing"

func TestMean(t *testing.T) {
	if got := Mean([]float64{1, 2, 3, 4}); got != 2.5 {
		t.Errorf("Mean = %v, want 2.5", got)
	}
}

func TestMedian(t *testing.T) {
	tests := []struct {
		name string
		xs   []float64
		want float64
	}{
		{name: "empty", xs: nil, want: 0},
		{name: "single", xs: []float64{7}, want: 7},
		{name: "odd length", xs: []float64{5, 1, 3}, want: 3},
		{name: "even length", xs: []float64{4, 1, 3, 2}, want: 2.5},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := Median(tt.xs); got != tt.want {
				t.Errorf("Median(%v) = %v, want %v", tt.xs, got, tt.want)
			}
		})
	}
}
