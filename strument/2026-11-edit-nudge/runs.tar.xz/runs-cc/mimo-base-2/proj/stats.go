// Package stats has small numeric helpers.
package stats

import "sort"

// Mean returns the arithmetic mean of xs, or 0 for an empty slice.
func Mean(xs []float64) float64 {
	if len(xs) == 0 {
		return 0
	}
	var sum float64
	for _, x := range xs {
		sum += x
	}
	return sum / float64(len(xs))
}

// Median returns the median of xs, or 0 for an empty slice.
// The input slice is not modified.
func Median(xs []float64) float64 {
	if len(xs) == 0 {
		return 0
	}
	ordered := make([]float64, len(xs))
	copy(ordered, xs)
	sort.Float64s(ordered)
	mid := len(ordered) / 2
	if len(ordered)%2 == 1 {
		return ordered[mid]
	}
	return (ordered[mid-1] + ordered[mid]) / 2
}
