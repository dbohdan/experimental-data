# stats

Small numeric helpers. It provides the arithmetic mean and median.
