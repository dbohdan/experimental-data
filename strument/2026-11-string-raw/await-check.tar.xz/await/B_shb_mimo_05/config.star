orr = provider("openrouter", base_url = "http://127.0.0.1:24006/api/v1", api_key = env("OPENROUTER_API_KEY"))
default = "mimo"
retry_timeout = 600
models = {"mimo": model(orr, "xiaomi/mimo-v2.6-flash", context = 131072, reasoning = "low", cache = True, extra_params = {"provider": {"only": ["xiaomi"], "allow_fallbacks": False}})}
