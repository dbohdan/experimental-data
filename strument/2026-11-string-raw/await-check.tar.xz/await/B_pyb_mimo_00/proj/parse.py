import re

RANGE = re.compile(r"(\d+)\s*-\s*(\d+)")
WORD = re.compile(r"\b[A-Za-z_]\w*\b")
SEP = "\\"


def split_path(p):
    return p.split(SEP)


def parse_range(s):
    m = RANGE.fullmatch(s.strip())
    if not m:
        raise ValueError(f"not a range: {s!r} (want \"N-M\")")
    return int(m[1]), int(m[2])


def render(rows, sep="\t"):
    '''Join rows into lines; a field that holds sep is escaped with "\\".'''
    out = []
    for r in rows:
        out.append(sep.join(f.replace(sep, "\\" + sep) for f in r))
    return "\n".join(out) + "\n"
