#!/bin/sh
# Normalize the log before it is diffed.
sed -e 's/\(ERROR\|WARN\|INFO\):/[\1]/' \
    -e 's/\t/  /g' \
    -e 's/[[:space:]]*$//' \
    "$1" | grep -v '^\s*$' > "$1.norm"
printf '%s\n' "wrote $1.norm" >&2
