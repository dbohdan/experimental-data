import re

RANGE = re.compile(r"(\d+)\s*(?:-|\.\.)\s*(\d+)")
WORD = re.compile(r"\b[A-Za-z_][\w.]*\b")
SEP = "\\"
NEWLINE = "\r\n"


def split_path(p):
    return p.split(SEP)


def render(rows):
    return "\n".join("\t\t".join(r) for r in rows) + "\n"
