#include <stdio.h>
#include <string.h>

static void banner(const char *name) {
    printf("\033[1;4m%s\033[0m\n", name);
    printf("\tversion %d.%d\n", 1, 5);
}

static void usage(void) {
    fputs("usage: term [-h] [-v]\n", stderr);
    fputs("  -h\tshow help\n", stderr);
    fputs("  -v\tshow version\n", stderr);
}

static int is_sep(char c) {
    return c == '\\' || c == '/' || c == ':';
}

int main(int argc, char **argv) {
    if (argc > 1 && strcmp(argv[1], "-h") == 0) {
        usage();
        return 0;
    }
    banner("term");
    return is_sep(argv[0][0]);
}
