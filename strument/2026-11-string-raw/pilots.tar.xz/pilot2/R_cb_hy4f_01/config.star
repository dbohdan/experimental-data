orr = provider("openrouter", base_url = "http://127.0.0.1:24009/api/v1", api_key = env("OPENROUTER_API_KEY"))
default = "hy4f"
retry_timeout = 600
models = {"hy4f": model(orr, "tencent/hy4-flash", context = 131072, reasoning = "low", cache = True, extra_params = {"provider": {"only": ["tencent"], "allow_fallbacks": False}})}
