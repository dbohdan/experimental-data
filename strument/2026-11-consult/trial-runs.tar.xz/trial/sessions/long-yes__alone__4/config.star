orr = provider("openrouter", base_url = "http://127.0.0.1:26012/api/v1", api_key = env("OPENROUTER_API_KEY"))
default = "mimo"
retry_timeout = 600
models = {
    "mimo": model(orr, "xiaomi/mimo-v2.6-flash", context = 131072, reasoning = "low", cache = True,
                  extra_params = {"provider": {"only": ["xiaomi"], "allow_fallbacks": False}}),
    "terra": model(orr, "openai/gpt-6.1-terra", context = 272000, reasoning = "low",
                   extra_params = {"provider": {"only": ["openai"], "allow_fallbacks": False}}),
}
consult_models = {"terra": "documentation and user-facing prose"}
